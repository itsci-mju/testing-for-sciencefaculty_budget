package com.springmvc.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

@Controller
public class UploadController {
	
	@RequestMapping(value="/loadUploadFilePage", method = RequestMethod.GET)
	public ModelAndView loadUploadFilePage(HttpServletRequest request, Model md, HttpSession session) {	
		ModelAndView mav = new ModelAndView("UploadFile");
		
				
				
		return mav;
	}
	
	@RequestMapping(value="/do_loadUploadPage",method = RequestMethod.GET)
	public ModelAndView load_uploadPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("UploadFile");
		try {
			request.setCharacterEncoding("UTF-8");
		}catch(UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
			String bid = request.getParameter("bid");
			String doc = request.getParameter("doc");
			ListManager listm = new ListManager();
			if(doc.equals("budgetRequest")) {
				mav.addObject("budgetRequest",bid);
				
				String bg = "เอกสารประสงค์ใช้งบประมาณ";
				mav.addObject("document",bg);
				
				
			}else if(doc.equals("requestingPermission")) {
				mav.addObject("requestingPermission" , "r");
				RequestingPermission rp = listm.getrpIDFormBudgetRequestId(bid);
				String k = rp.getRequestPerID();
				
				mav.addObject("id",k);
				
				String rpd = "เอกสารขออนุญาต";
				mav.addObject("document",rpd);
				
				/*
				 * RequestingPermission rpnull = listm.getrpIDNullFormBudgetRequestId(bid);
				 * 
				 * if(rpnull == null) { mav = new ModelAndView("ListDocument");
				 * 
				 * return mav; }
				 */
				
				/*
				 * check id  ก่อนหน้าว่าเป็น null ไม ถ้าเป็น ให้กลับไปหน้า list
				 * เเล้วเเจ้งให้อัพโหลดเอกสารใบเเรก
				 */
				
			}else if(doc.equals("travelRequest")) {
				mav.addObject("travelRequest" , "t");
				TravelRequest travel = listm.getTravelIDFormBudgetRequestId(bid);
				String tid = travel.getTravelID();
				mav.addObject("id", tid);
				
				String t = "เอกสารขออนุมัติการเดินทาง";
				mav.addObject("document",t);
				
			}else if(doc.equals("registrationBudgetRequest")) {
				mav.addObject("registrationBudgetRequest" , "reg");
				RegistrationBudgetRequest reg = listm.getRegIDFormBudgetRequestId(bid);
				String rid = reg.getRegistrationID();
				mav.addObject("id", rid);
				
				String regd = "เอกสารขออนุมัติค่าลงทะเบียน";
				mav.addObject("document",regd);
				
			}else {
				mav.addObject("travelReport" , "tr");
				TravelReport report = listm.getReortIDFormBudgetRequestId(bid);
				String reportid = report.getTravelReportID();
				
				mav.addObject("id", reportid);
				
				String port = "เอกสารรายงานการเดินทาง";
				mav.addObject("document",port);
			}
			
			mav.addObject("bid",bid);
			mav.addObject("doc",doc);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
	
	
	
	/* uploadfile */
	
	@RequestMapping(value = "/doUploadFile", method = RequestMethod.POST)
	public ModelAndView do_uploadFile(HttpServletRequest request, Model md, HttpSession session) {		
		ModelAndView mav = new ModelAndView("ListDocument");
				
		String message = "" ;

						
		if(ServletFileUpload.isMultipartContent(request)) {
			try {
				UploadManager upm = new UploadManager();
				
				request.setCharacterEncoding("UTF-8");	
				List<FileItem> data = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);				
				String path = request.getSession().getServletContext().getRealPath("/") + "resources/document/pdf/";
				
				String doc_id = data.get(0).getString("UTF-8");
				String id = data.get(1).getString("UTF-8");
				
				String documentName = data.get(2).getString("UTF-8");
				System.out.println("บวก บวก : " + documentName);
				
				
				
				if(documentName.equals("เอกสารประสงค์ใช้งบประมาณ")) {
					
					int result = 0;
					String filename = new BudgetRequest(data.get(3).getName()).getFileName();
					filename = doc_id + ".pdf";
					filename = filename.replaceAll("/", "_");
					
					result = upm.isUploadBudgetRequestDocument(filename , doc_id);
					data.get(3).write(new File(path + File.separator + filename));
					//String filename = new ListFile(data.get(3).getName()).getFilename();				
					//upm.isUploadBudgetRequestDocument(filename , doc_id);
					//data.get(3).write(new File(path + File.separator + filename));
					
					
					
				}else if(documentName.equals("เอกสารขออนุญาต")) {
					
					int result = 0;
					//String filename = new ListFile(data.get(3).getName()).getFilename();	
					String filename = new RequestingPermission(data.get(3).getName()).getFileName();
					filename = id + ".pdf";
					filename = filename.replaceAll("/", "_");
					
					System.out.println("บวก บวก : " + id);
					
					result = upm.isUploadRequestingPerDocument(filename, id);
					data.get(3).write(new File(path + File.separator + filename));
					
					
					if(result == 1) {
						String mg = "อัพโหลดสำเร็จ";
						mav.addObject("mg", mg);
					}else {
						String mg = "อัพโหลดไม่สำเร็จ";
						mav.addObject("mg", mg);
					}
					
					
				}else if(documentName.equals("เอกสารขออนุมัติการเดินทาง")) {
					
					int result = 0;
					//String filename = new ListFile(data.get(3).getName()).getFilename();	
					String filename = new TravelRequest(data.get(3).getName()).getFileName();
					filename = id + ".pdf";
					filename = filename.replaceAll("/", "_");
					
					result = upm.isUploadTravelDocument(filename , id);
					data.get(3).write(new File(path + File.separator + filename));
					
					if(result == 1) {
						String mg = "อัพโหลดสำเร็จ";
						mav.addObject("mg", mg);
					}else {
						String mg = "อัพโหลดไม่สำเร็จ";
						mav.addObject("mg", mg);
					}
					
					
				}else if(documentName.equals("เอกสารขออนุมัติค่าลงทะเบียน")) {
					
					int result = 0;
					//String filename = new ListFile(data.get(3).getName()).getFilename();
					String filename = new RegistrationBudgetRequest(data.get(3).getName()).getFileName();
					filename = id + ".pdf";
					filename = filename.replaceAll("/", "_");
					
					result = upm.isUploadRegDocument(filename, id);
					data.get(3).write(new File(path + File.separator + filename));
					
					if(result == 1) {
						String mg = "อัพโหลดสำเร็จ";
						mav.addObject("mg", mg);
					}else {
						String mg = "อัพโหลดไม่สำเร็จ";
						mav.addObject("mg", mg);
					}
					
					
				}else {
					
					int result = 0;
					//String filename = new ListFile(data.get(3).getName()).getFilename();	
					String filename = new TravelReport(data.get(3).getName()).getFileName();
					filename = id + ".pdf";
					filename = filename.replaceAll("/", "_");
					
					result = upm.isUploadReportDocument(filename, id);
					data.get(3).write(new File(path + File.separator + filename));
					
					if(result == 1) {
						String mg = "อัพโหลดสำเร็จ";
						mav.addObject("mg", mg);
					}else {
						String mg = "อัพโหลดไม่สำเร็จ";
						mav.addObject("mg", mg);
					}
					
					
					
				}
				
				
				System.out.println(path);
				System.out.println("id ใบเเรก : " + doc_id);
				System.out.println("id เอกสารเเต่ละใบ : " + id);
			
				message = "อัพโหลดสำเร็จ";
				
				ListManager lm = new ListManager();
				Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
				
				System.out.println();
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
				mav.addObject("budgetRequest", br);
				
				
			} catch (Exception e) {
				e.printStackTrace();
				message = "อัพโหลดไม่สำเร็จ";
			}
		}
		
		mav.addObject("message", message);
		return mav;
		
		
	}
	
	
	//viewUpload
	@RequestMapping(value="/loadViewUploadFilePage", method = RequestMethod.GET)
	public ModelAndView loadViewUploadFilePage(HttpServletRequest request, Model md, HttpSession session) {	
		ModelAndView mav = new ModelAndView("ViewFileUpload");
		
		String bid = request.getParameter("bid");
			
		try {
			
			UploadManager upm = new UploadManager();
			
			BudgetRequest b = new BudgetRequest();
			RequestingPermission rq = new RequestingPermission();
			TravelRequest tr = new TravelRequest();
			RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
			TravelReport report = new TravelReport();
			
			//budgetName
			b = upm.getBudgetRequestIDName(bid);
			String budgetname = b.getRequestName();
			
			//rq id
			rq = upm.getRequestingID(bid);
			
			//travel
			tr = upm.getTravelRequestID(bid);
			
			
			//reg
			reg = upm.getRegistrationID(bid);
			
			//travelreport
			report = upm.getTravelReportID(bid);
			
//			FileBudgetRequest fbr = new FileBudgetRequest();
//			FileRequestingPermission frq = new FileRequestingPermission();
//			FileTravelRequest ftr = new FileTravelRequest();
//			FileRegistrationBudget freg = new FileRegistrationBudget();
//			FileTravelReport freport = new FileTravelReport();
			
			
//			fbr = upm.getViewBudgetRequestFile(bid);			
//			System.out.println("BID " + fbr.getFileName());
//			
//			
//			frq = upm.getViewRequestingPermissionFile(rid);
//			System.out.println("RID " + frq.getFileName());
//			
//			
//			ftr = upm.getViewTravelFile(tid);
//			System.out.println("TID " + ftr.getFileName());
//			
//			freg = upm.getViewRegFile(regis);
//			System.out.println("REGID " + freg.getFileName());
//			
//			freport = upm.getViewTravelReportFile(re);
//			System.out.println("REPORTID " + freport.getFileName());
			String m = "ยังไม่ได้อัพโหลด";		
			
			mav.addObject("fbr", b);
			mav.addObject("frq", rq);
			mav.addObject("ftr", tr);
			mav.addObject("freg", reg);
			mav.addObject("freport", report);
			mav.addObject("m", m);
			
			mav.addObject("budgetname", budgetname);
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		mav.addObject("bid", bid);
		
		return mav;
	}
	
	
	@RequestMapping(value="/downloadFile", method = RequestMethod.GET)
	public void downloadFile(ServletResponse response, HttpSession session, Model md, HttpServletRequest request) {
		
		String file_name = request.getParameter("fileName");
		String path = request.getServletContext().getRealPath("/") ;
		
		System.out.println(path+"resources/document/pdf/"+file_name);
		
		try (BufferedInputStream inputStream = new BufferedInputStream(new URL(path+"resources/document/pdf/"+file_name).openStream());
				FileOutputStream fileOS = new FileOutputStream(file_name)) {
			 byte data[] = new byte[1024];
			    int byteContent;
			    while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
			        fileOS.write(data, 0, byteContent);
			    }
				    
				} catch (IOException e) {
				    // handle exception
				}
		
		
	}
	
	
	
	
	

}
