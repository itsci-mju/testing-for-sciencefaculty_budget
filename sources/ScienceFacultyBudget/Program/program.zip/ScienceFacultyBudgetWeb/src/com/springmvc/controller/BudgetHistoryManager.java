package com.springmvc.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;
import com.springmvc.model.TravelRequest;

import conn.ConnectionDB;

public class BudgetHistoryManager {
	
	public List<BudgetRequest> getBudgetHistory(String perid)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , chooseRequest , requestDate , requestName , status , title , firstname , lastname , position from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID where Personnel_personnelID ='"+perid+"' order by requestDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel p = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				budget.setStatus(rs.getString(5));
				p.setTitle(rs.getString(6));
				p.setFirstname(rs.getString(7));
				p.setLastname(rs.getString(8));
				p.setPosition(rs.getString(9));
				budget.setPersonnel(p);
				
				
				
				
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	
	public List<BudgetRequest> getBudgetHistoryByYear(String year , String perId)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , chooseRequest , requestDate , requestName , status , title , firstname , lastname , position , personnelID from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID where year(requestDate)='"+year+"' and personnelID = '"+perId+"' order by requestDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel p = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				budget.setStatus(rs.getString(5));
				p.setTitle(rs.getString(6));
				p.setFirstname(rs.getString(7));
				p.setLastname(rs.getString(8));
				p.setPosition(rs.getString(9));
				p.setPersonnelID(rs.getString(10));
				budget.setPersonnel(p);
				
				
				
				
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	
		//ผลรวม
		//ดึงผลรวมเอกสารอยยุมัติการเดินทาง
		public TravelRequest getTotalTravel(String bid)throws SQLException{
			TravelRequest travel = new TravelRequest();
			BudgetRequest budget = new BudgetRequest();
			ConnectionDB condb = new ConnectionDB();
			Connection conn = condb.getConnection();
			try {			
				Statement stmt = conn.createStatement();
				String sql = "Select travelID , totalBudget from TravelRequest where BudgetRequest_budgetRequestID = '"+ bid +"' ";
				ResultSet rs = stmt.executeQuery(sql);
				System.out.println(sql);
				
				while(rs.next()) {	
					travel.setTravelID(rs.getString(1));
					travel.setTotalBudget(rs.getDouble(2));
									
					
				} 
			}catch(SQLException e) {
				e.printStackTrace();
			}
			conn.close();
			return travel;		
		}
		
		//ดึงผลรวมเอกสารขออนุมัติค่าลงทะเบียน
		public RegistrationBudgetRequest getTotalRegis(String bid)throws SQLException{
			RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
			BudgetRequest budget = new BudgetRequest();
			ConnectionDB condb = new ConnectionDB();
			Connection conn = condb.getConnection();
			try {			
				Statement stmt = conn.createStatement();
				String sql = "Select registrationID , requestBudget from RegistrationBudgetRequest where BudgetRequest_budgetRequestID = '"+ bid +"' ";
				ResultSet rs = stmt.executeQuery(sql);
				System.out.println(sql);
				
				while(rs.next()) {	
					reg.setRegistrationID(rs.getString(1));
					reg.setRequestBudget(rs.getDouble(2));
									
					
				} 
			}catch(SQLException e) {
				e.printStackTrace();
			}
			conn.close();
			return reg;		
		}

}
