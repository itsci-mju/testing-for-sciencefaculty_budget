package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;

@Controller
public class ViewController {

	
	@RequestMapping(value="/loadViewBudgetRequestPage", method = RequestMethod.GET)
	public ModelAndView loadViewBudgetRequestPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ViewBudgetRequest");
		
		ViewManager vmg = new ViewManager();
		
		try {
			List<BudgetRequest> vbr = vmg.getViewBudgetRequest();
			List<String> date = new ArrayList<>();
			
			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			
			for(BudgetRequest b : vbr) {								
				date.add(sdf.format(b.getRequestDate()));
			}
			
			mav.addObject("date", date);
			mav.addObject("viewbudgetRequest", vbr);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			
		return mav;
	}
	
	@RequestMapping(value="/loadViewRequestingPermissionPage", method = RequestMethod.GET)
	public ModelAndView loadViewRequestingPermissionPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ViewRequestingPermission");
		ViewManager vmg = new ViewManager();
		
		try {
			List<RequestingPermission> vrp = vmg.getViewRequestingPermission();
			List<String> date = new ArrayList<>();
			
			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			for(RequestingPermission r : vrp) {								
				date.add(sdf.format(r.getRequestingPerDate()));
			}
			
			mav.addObject("date", date);			
			mav.addObject("viewrequestingpermission", vrp);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return mav;
	}
	
	
	@RequestMapping(value="/loadViewTravelRequestPage", method = RequestMethod.GET)
	public ModelAndView loadViewTravelRequestPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ViewTravelRequest");
		ViewManager vmg = new ViewManager();
		
		try {
			List<TravelRequest> travel = vmg.getViewTravelRequest();
//			ListManager lm = new ListManager();
//			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
//			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
			
			List<String> sDate = new ArrayList<>();
			List<String> eDate = new ArrayList<>();
			List<String> rDate = new ArrayList<>();

			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			for(TravelRequest t : travel) {								
				sDate.add(sdf.format(t.getStartDate()));
				eDate.add(edf.format(t.getEndDate()));
				rDate.add(rdf.format(t.getTravelDate()));
							
			}
			
			mav.addObject("viewtravelrequest", travel);
			mav.addObject("sDate", sDate);
			mav.addObject("eDate", eDate);
			mav.addObject("rDate", rDate);
//			mav.addObject("budgetRequest", br);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			
		return mav;
	}
	
	@RequestMapping(value="/loadViewRegistrationBudgetRequestPage", method = RequestMethod.GET)
	public ModelAndView loadViewRegistrationBudgetRequestPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ViewRegistrationBudgetRequest");
		ViewManager vmg = new ViewManager();
		
		try {
			List<RegistrationBudgetRequest> reg = vmg.getViewRegistrationBudgetRequest();
			List<String> sDate = new ArrayList<>();
			List<String> eDate = new ArrayList<>();
			List<String> rDate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			for(RegistrationBudgetRequest r : reg) {								
				sDate.add(sdf.format(r.getRegisStartDate()));
				eDate.add(edf.format(r.getRegisEndDate()));
				rDate.add(rdf.format(r.getRegisDate()));
				
			}
			
			mav.addObject("viewregistration", reg);
			mav.addObject("sDate", sDate);
			mav.addObject("eDate", eDate);
			mav.addObject("rDate", rDate);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			
		return mav;
	}
	
	
	@RequestMapping(value="/ViewBudgetRequest", method = RequestMethod.GET)
	public ModelAndView ViewBudgetRequest(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();	
		String bid = request.getParameter("bid");
		ViewManager vmg = new ViewManager();
		
		try {
			BudgetRequest budget = vmg.getViewBudgetRequestID(bid);
			
			String statusButton = "adminipersonnel";
			
			mav = new ModelAndView("BudgetRequestDocument");
			System.out.println("เอกสารประสงค์ใช้งบประมาณ");
			mav.addObject("budget" , budget);
			mav.addObject("statusButton" , statusButton);
			
		}catch (SQLException e) {
			e.printStackTrace();
		}				
		return mav;
	}
	
	
	@RequestMapping(value="/ViewRequestingPermission", method = RequestMethod.GET)
	public ModelAndView ViewRequestingPermission(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();	
		
		try {			
			ViewManager vmg = new ViewManager();
			String rid = request.getParameter("rid");
			RequestingPermission vrp = vmg.getViewRequestingPermissionID(rid);
			
			String statusButton = "adminipersonnel";
					
			mav = new ModelAndView("RequestingPermissionDocument");

			mav.addObject("statusButton" , statusButton);
			mav.addObject("permission" , vrp);
		}catch (SQLException e) {
			e.printStackTrace();
		}	
		
		return mav;
	}
	
	
	@RequestMapping(value="/ViewTravelRequest", method = RequestMethod.GET)
	public ModelAndView ViewTravelRequest(HttpServletRequest request, Model md, HttpSession session, String tids) {
		ModelAndView mav = new ModelAndView("TravelRequestDocument");	
		
		try {			
			ViewManager vmg = new ViewManager();
			String statusButton = "FinacialOfficer";
			
			String tid = request.getParameter("tid");
			if(tids != null) {
				tid = tids;
			}
			TravelRequest travel = vmg.getViewTravelRequestID(tid);
			
			List<CommentTravel> cmt = vmg.getListCommentTravelByFinance(tid);
			System.out.println("size = " + cmt.size());
//			CommentTravel cmt = vmg.getViewCommentTravelByFinance(tid);

			mav.addObject("statusButton" , statusButton);
			mav.addObject("travel" , travel);
			mav.addObject("cmt" , cmt);
			
			
		}catch (SQLException e) {
			e.printStackTrace();
		}			
		return mav;
	}
	
	
	@RequestMapping(value="/ViewRegistrationBudgetRequest", method = RequestMethod.GET)
	public ModelAndView ViewRegistrationBudgetRequest(HttpServletRequest request, Model md, HttpSession session , String rids) {
		ModelAndView mav = new ModelAndView("RegistrationBudgetRequestDocument");	
		
		try {			
			ViewManager vmg = new ViewManager();
			String statusButton = "FinacialOfficer";
			
			String regid = request.getParameter("regid");
			if(rids != null) {
				regid = rids;
			}
			
			RegistrationBudgetRequest reg = vmg.getViewRegistrationBudgetRequestID(regid);
			
			List<CommentRegistrationBudget> cmr = vmg.getListCommentRegisByFinance(regid);
			
			mav.addObject("statusButton" , statusButton);
			mav.addObject("reg" , reg);
			mav.addObject("cmr" , cmr);
			
		}catch (SQLException e) {
			e.printStackTrace();
		}	
	
			
		return mav;
	}
	
	
	//searchBudgetPersonnel
	@RequestMapping(value="/searchBudgetPersonnel", method = RequestMethod.POST)
	public ModelAndView searchBudgetPersonnel(HttpServletRequest request, Model md, HttpSession session) throws UnsupportedEncodingException {
		ModelAndView mav = new ModelAndView("ViewBudgetRequest");	
		
		try {
			request.setCharacterEncoding("UTF-8");
			
			List<BudgetRequest> br = null;
			ViewManager vm = new ViewManager();
			String fname = request.getParameter("firstname");
			String lname = request.getParameter("lastname");
			
			if(lname == "" || lname == null) {
				
				br = vm.getViewBudgetRequestSearchFname(fname);
				
				if(br.size() == 0 ) {
					 br = vm.getViewBudgetRequest();
					 
					 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
					 
					 mav.addObject("pmsgg", pmsgg);
					 mav.addObject("viewbudgetRequest", br);
					 
				}
				
				if(br.size() != 0) {
					
					List<String> date = new ArrayList<>();
					
					String DATE_FORMAT = "dd MMMM yyyy";
					SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
					
					
					for(BudgetRequest b : br) {								
						date.add(sdf.format(b.getRequestDate()));
					}
					
					mav.addObject("date", date);
					
					 mav.addObject("viewbudgetRequest", br);
				 }
				
			}else if(fname == "" || fname == null) {
				
				br = vm.getViewBudgetRequestSearchLname(lname);
				
				if(br.size() == 0 ) {
					 br = vm.getViewBudgetRequest();
					 
					 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
					 
					 mav.addObject("pmsgg", pmsgg);
					 mav.addObject("viewbudgetRequest", br);
					 
				}
				
				if(br.size() != 0) {
					List<String> date = new ArrayList<>();
					
					String DATE_FORMAT = "dd MMMM yyyy";
					SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
					
					
					for(BudgetRequest b : br) {								
						date.add(sdf.format(b.getRequestDate()));
					}
					
					mav.addObject("date", date);
					
					 mav.addObject("viewbudgetRequest", br);
				 }
				
			}else {
				br = vm.getViewBudgetRequestSearchFullName(fname, lname);
				
				if(br.size() == 0 ) {
					 br = vm.getViewBudgetRequest();
					 
					 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
					 
					 mav.addObject("pmsgg", pmsgg);
					 mav.addObject("viewbudgetRequest", br);
					 
				}
				
				if(br.size() != 0) {
					List<String> date = new ArrayList<>();
					
					String DATE_FORMAT = "dd MMMM yyyy";
					SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
					
					
					for(BudgetRequest b : br) {								
						date.add(sdf.format(b.getRequestDate()));
					}
					
					mav.addObject("date", date);
					 mav.addObject("viewbudgetRequest", br);
				 }
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		return mav;
	}
	
	
		//searchRequestingPersonnel
		@RequestMapping(value="/searchRequestingPersonnel", method = RequestMethod.POST)
		public ModelAndView searchRequestingPersonnel(HttpServletRequest request, Model md, HttpSession session) throws UnsupportedEncodingException {
			ModelAndView mav = new ModelAndView("ViewRequestingPermission");
			
			try {
				request.setCharacterEncoding("UTF-8");
				
				List<RequestingPermission> rq = null;
				ViewManager vm = new ViewManager();
				String fname = request.getParameter("firstname");
				String lname = request.getParameter("lastname");
				
				if(lname == "" || lname == null) {
					
					rq = vm.getViewRequestingSearchFName(fname);
					
					if(rq.size() == 0 ) {
						 rq = vm.getViewRequestingPermission();
						 
						 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
						 
						 mav.addObject("pmsgg", pmsgg);
						 mav.addObject("viewrequestingpermission", rq);
						 
					}
					
					if(rq.size() != 0) {
						
						List<String> date = new ArrayList<>();
						
						String DATE_FORMAT = "dd MMMM yyyy";
						SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
						
						for(RequestingPermission r : rq) {								
							date.add(sdf.format(r.getRequestingPerDate()));
						}
						
						mav.addObject("date", date);
						
						 mav.addObject("viewrequestingpermission", rq);
					 }
					
				}else if(fname == "" || fname == null) {
					
					rq = vm.getViewRequestingSearchLName(lname);
					
					if(rq.size() == 0 ) {
						rq = vm.getViewRequestingPermission();
						 
						 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
						 
						 mav.addObject("pmsgg", pmsgg);
						 mav.addObject("viewrequestingpermission", rq);
						 
					}
					
					if(rq.size() != 0) {
						List<String> date = new ArrayList<>();
						
						String DATE_FORMAT = "dd MMMM yyyy";
						SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
						
						for(RequestingPermission r : rq) {								
							date.add(sdf.format(r.getRequestingPerDate()));
						}
						
						mav.addObject("date", date);
						
						mav.addObject("viewrequestingpermission", rq);
					 }
					
				}else {
					rq = vm.getViewRequestingSearchFullName(fname, lname);
					
					if(rq.size() == 0 ) {
						rq = vm.getViewRequestingPermission();
						 
						 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
						 
						 mav.addObject("pmsgg", pmsgg);
						 mav.addObject("viewrequestingpermission", rq);
						 
					}
					
					if(rq.size() != 0) {
						List<String> date = new ArrayList<>();
						
						String DATE_FORMAT = "dd MMMM yyyy";
						SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
						
						for(RequestingPermission r : rq) {								
							date.add(sdf.format(r.getRequestingPerDate()));
						}
						
						mav.addObject("date", date);
						mav.addObject("viewrequestingpermission", rq);
					 }
					
				}			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return mav;
		}
	
}
