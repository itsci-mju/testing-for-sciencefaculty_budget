package com.springmvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="RequestingPermission")
public class RequestingPermission {
	
	@Id
	@Column(name="requestPerID" , length = 20)
	private String requestPerID;
	
	@Column(name="requestPerName" , nullable=false , length = 100)
	private String requestPerName;
	
	
	@Column(name="requestingPerDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date requestingPerDate;	
	
	@Column(name="requestingPerText" , columnDefinition = "LONGTEXT" , nullable=false)
	private String requestingPerText;
	
	@Column(name="fileName" , nullable=false , length = 50)
	private String fileName;

	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "BudgetRequest_budgetRequestID" , nullable=false)
	private BudgetRequest budgetRequest;

	

	public RequestingPermission() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public RequestingPermission(String fileName) {
		super();
		this.fileName = fileName;
	}



	public RequestingPermission(String requestPerID, String requestPerName, Date requestingPerDate,
			String requestingPerText) {
		super();
		this.requestPerID = requestPerID;
		this.requestPerName = requestPerName;
		this.requestingPerDate = requestingPerDate;
		this.requestingPerText = requestingPerText;
	}


	public String getRequestPerID() {
		return requestPerID;
	}


	public void setRequestPerID(String requestPerID) {
		this.requestPerID = requestPerID;
	}


	public String getRequestPerName() {
		return requestPerName;
	}


	public void setRequestPerName(String requestPerName) {
		this.requestPerName = requestPerName;
	}


	public Date getRequestingPerDate() {
		return requestingPerDate;
	}


	public void setRequestingPerDate(Date requestingPerDate) {
		this.requestingPerDate = requestingPerDate;
	}


	public String getRequestingPerText() {
		return requestingPerText;
	}
	
	


	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}






	public void setRequestingPerText(String requestingPerText) {
		this.requestingPerText = requestingPerText;
	}


	public BudgetRequest getBudgetRequest() {
		return budgetRequest;
	}


	public void setBudgetRequest(BudgetRequest budgetRequest) {
		this.budgetRequest = budgetRequest;
	}
	
	

	

}
