package com.springmvc.controller;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.springmvc.model.BudgetRequest;

import conn.ConnectionDB;

public class CancelManager {
	
	public int isCancleBudgetRequest(String status , String bid) throws SQLException{
		int result = 0;
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call cancelBudgetRequest_Procedure(?,?)}");
			cstmt.setString(1 , status);
			cstmt.setString(2 , bid);
			
			
			
			
			
			System.out.println(cstmt);
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}

}
