package com.springmvc.controller;

import java.io.File;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import conn.*;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;

import net.sf.jasperreports.engine.DefaultJasperReportsContext;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRPropertiesUtil;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperReportsContext;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

@Controller
public class ReportController {
	
	
	@RequestMapping(value = "/loadReportPage", method = RequestMethod.GET)
	public ModelAndView loadReportPage(HttpServletRequest request, Model md, HttpSession session, ServletResponse response) {
		ModelAndView mav = new ModelAndView();
		ReportManager rm = new ReportManager();
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		
		try {
			String bid = request.getParameter("bid");
			String document = request.getParameter("doc");
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
			
			if (document.equals("budgetRequest")) {
				
				
				try {
										
					Connection conn = null;
					try {
						Class.forName("com.mysql.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sciencefacultybudget?characterEncoding=UTF-8", "root", "12345678");
						
						
						String report = request.getServletContext().getRealPath("/") ;
						System.out.println(""+report);
						
						
						
						Map<String, Object> map = new HashMap<>();
						map.put("bid", bid);
						
						
						File file = ResourceUtils.getFile(report+ "resources/report/CreateBudgetRequest.jrxml");
						System.out.println( file + " !!!!");
						//String report = "/Users/krisadakornchaiwong/eclipse-workspace/ScienceFacultyBudgetWeb/WebContent/resources/report/reportTest.jrxml";
						
						
						//JasperExportManager.exportReportToPdf(jp, response.getOutputStream());
						
						JasperReportsContext jrContext = DefaultJasperReportsContext.getInstance();
						
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "Identity-H");
												
//						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "UTF-8");
//						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.embedded", "true");
												
//						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitASBold.ttf");
//						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitASBoldItalic.ttf");
//						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitASItalic.ttf");

						JasperReport jasperreport = JasperCompileManager.compileReport(file.getAbsolutePath());						
						JasperPrint jp = JasperFillManager.fillReport(jasperreport, map, conn);
						
												
						JasperExportManager.exportReportToPdf(jp);					
						response.setContentType("application/pdf");
						
						JasperExportManager.exportReportToPdfStream(jp, response.getOutputStream());						
						response.getOutputStream().flush();
						response.getOutputStream().close();												
						
					} catch (Exception e) {
						System.out.println(e);
					}
					
					
				}catch (Exception e) { //sql
					e.printStackTrace();
				}			
				
				return mav;
			
			
			
			}else if(document.equals("requestingPermission")) {
				
				
				
				try {
					
					Connection conn = null;
					try {
						Class.forName("com.mysql.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sciencefacultybudget?characterEncoding=UTF-8", "root", "12345678");
						
						
						String report = request.getServletContext().getRealPath("/") ;
						System.out.println(""+report);
						
						RequestingPermission id = rm.getrpIDFormBudgetRequestId(bid);
						
						String rid = id.getRequestPerID();
						
						System.out.println(rid);
						
						Map<String, Object> map = new HashMap<>();
						map.put("rid", rid);
						
						
						File file = ResourceUtils.getFile(report + "resources/report/CreateRequestingPermission.jrxml");
						//String report = "/Users/krisadakornchaiwong/eclipse-workspace/ScienceFacultyBudgetWeb/WebContent/resources/report/reportTest.jrxml";
						
						
						//JasperExportManager.exportReportToPdf(jp, response.getOutputStream());
						
						JasperReportsContext jrContext = DefaultJasperReportsContext.getInstance();
						
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "Identity-H");

						JasperReport jasperreport = JasperCompileManager.compileReport(file.getAbsolutePath());
						
						JasperPrint jp = JasperFillManager.fillReport(jasperreport, map, conn);
						JasperExportManager.exportReportToPdf(jp);					
						response.setContentType("application/pdf");
						JasperExportManager.exportReportToPdfStream(jp, response.getOutputStream());						
						response.getOutputStream().flush();
						response.getOutputStream().close();	
						
					} catch (Exception e) {
						System.out.println(e);
					}
					
					
					
					
//					
//					  BudgetRequest budget = rm.getBudgetRequestDocumentID(bid);
//					  
//					  
//					  System.out.println("เอกสารประสงค์ใช้งบประมาณ"); mav.addObject("budget" ,
//					  budget);
//					 
//					
//					mav = new ModelAndView("ViewRemainingBudgetPage");
					
				}catch (Exception e) {
					e.printStackTrace();
				}			
				
				return mav;
				
				
				
				
			}else if(document.equals("travelRequest")) {
				
				try {
					
					Connection conn = null;
					try {
						Class.forName("com.mysql.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sciencefacultybudget?characterEncoding=UTF-8", "root", "12345678");
						
						
						String report = request.getServletContext().getRealPath("/") ;
						System.out.println(""+report);
						
						TravelRequest id = rm.getTravelIDFormBudgetRequestId(bid);
						
						String tid = id.getTravelID();
						
						
						
						System.out.println(tid);
						
						Map<String, Object> map = new HashMap<>();
						map.put("tid", tid);
						
						
						File file = ResourceUtils.getFile(report + "resources/report/CreateTravelRequest.jrxml");
						//String report = "/Users/krisadakornchaiwong/eclipse-workspace/ScienceFacultyBudgetWeb/WebContent/resources/report/reportTest.jrxml";
						
						
						//JasperExportManager.exportReportToPdf(jp, response.getOutputStream());
						
						JasperReportsContext jrContext = DefaultJasperReportsContext.getInstance();
						
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "Identity-H");
						

						JasperReport jasperreport = JasperCompileManager.compileReport(file.getAbsolutePath());
						
						JasperPrint jp = JasperFillManager.fillReport(jasperreport, map, conn);
						JasperExportManager.exportReportToPdf(jp);					
						response.setContentType("application/pdf");
						JasperExportManager.exportReportToPdfStream(jp, response.getOutputStream());						
						response.getOutputStream().flush();
						response.getOutputStream().close();		
						
					} catch (Exception e) {
						System.out.println(e);
					}
					
					
					
					
					
					
//					mav = new ModelAndView("ViewRemainingBudgetPage");
					
				}catch (Exception e) {
					e.printStackTrace();
				}			
				
				return mav;
				
				
				
			}else if(document.equals("registrationBudgetRequest")) {
				
				
				try {
					
					Connection conn = null;
					try {
						Class.forName("com.mysql.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sciencefacultybudget?characterEncoding=UTF-8", "root", "12345678");
						
						
						String report = request.getServletContext().getRealPath("/");
						System.out.println(""+report);
						
						RegistrationBudgetRequest id = rm.getRegIDFormBudgetRequestId(bid);																	
						String regid = id.getRegistrationID(); //id budget rq
						
						String perid = personnel.getPersonnelID();
												
						
						System.out.println(regid);
						
						Map<String, Object> map = new HashMap<>();
						map.put("regid", regid);
						map.put("perid", perid);
						
						
						
						File file = ResourceUtils.getFile(report + "resources/report/CreateRegistrationBudget.jrxml");
						
						JasperReportsContext jrContext = DefaultJasperReportsContext.getInstance();
						
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "Identity-H");
						

						JasperReport jasperreport = JasperCompileManager.compileReport(file.getAbsolutePath());
						
						JasperPrint jp = JasperFillManager.fillReport(jasperreport, map, conn);
						JasperExportManager.exportReportToPdf(jp);					
						response.setContentType("application/pdf");
						JasperExportManager.exportReportToPdfStream(jp, response.getOutputStream());						
						response.getOutputStream().flush();
						response.getOutputStream().close();		
						
					} catch (Exception e) {
						System.out.println(e);
					}
										
					//mav = new ModelAndView("ViewRemainingBudgetPage");
					
					
				}catch (Exception e) {
					e.printStackTrace();
				}			
				
				return mav;
				
				
				
			}else {
				
				try {
					
					Connection conn = null;
					try {
						Class.forName("com.mysql.jdbc.Driver");
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sciencefacultybudget?characterEncoding=UTF-8", "root", "12345678");
						
						
						String report = request.getServletContext().getRealPath("/");
						System.out.println(""+report);
						
						TravelReport id = rm.getReortIDFormBudgetRequestId(bid);
						
						
						String reportId = id.getTravelReportID();
						
						System.out.println(reportId);
						
						Map<String, Object> map = new HashMap<>();
						map.put("reportId", reportId);
						
						
						File file = ResourceUtils.getFile(report + "resources/report/CreateTravelReport.jrxml");
						//String report = "/Users/krisadakornchaiwong/eclipse-workspace/ScienceFacultyBudgetWeb/WebContent/resources/report/reportTest.jrxml";
						
						
						//JasperExportManager.exportReportToPdf(jp, response.getOutputStream());
						
						JasperReportsContext jrContext = DefaultJasperReportsContext.getInstance();
						
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.font.name",report+"resources/fonts/THNiramitAS.ttf");
						JRPropertiesUtil.getInstance(jrContext).setProperty("net.sf.jasperreports.default.pdf.encoding", "Identity-H");

						JasperReport jasperreport = JasperCompileManager.compileReport(file.getAbsolutePath());
						
						JasperPrint jp = JasperFillManager.fillReport(jasperreport, map, conn);
						JasperExportManager.exportReportToPdf(jp);					
						response.setContentType("application/pdf");
						JasperExportManager.exportReportToPdfStream(jp, response.getOutputStream());						
						response.getOutputStream().flush();
						response.getOutputStream().close();		
						
					} catch (Exception e) {
						System.out.println(e);
					}
										
					//mav = new ModelAndView("ViewRemainingBudgetPage");
					
					
				}catch (Exception e) {
					e.printStackTrace();
				}			
				
				return mav;				
				
				
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		

		return mav;
	}

}
