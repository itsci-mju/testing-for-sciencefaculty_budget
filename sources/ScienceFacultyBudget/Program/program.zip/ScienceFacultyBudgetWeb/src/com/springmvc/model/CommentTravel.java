package com.springmvc.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="CommentTravel")
public class CommentTravel {
	
	@Id
	@Column(name="commentId" , length = 20)
	private String commentId;
	
	@Column(name="commentTravelDate" , nullable=false)
	@Temporal(TemporalType.DATE )
	private Date commentTravelDate;
	
	@Column(name="commentTravelText" , nullable=false , length = 100)
	private String commentTravelText;
	
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "TravelRequest_travelID" , nullable=false)
	private TravelRequest travelRequest;
	
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "Personnel_personnelID" , nullable=false)
	private Personnel personnel;



	public CommentTravel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	



	public CommentTravel(String commentId, Date commentTravelDate, String commentTravelText) {
		super();
		this.commentId = commentId;
		this.commentTravelDate = commentTravelDate;
		this.commentTravelText = commentTravelText;
	}


	


	public String getCommentId() {
		return commentId;
	}





	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}





	public Date getCommentTravelDate() {
		return commentTravelDate;
	}





	public void setCommentTravelDate(Date commentTravelDate) {
		this.commentTravelDate = commentTravelDate;
	}





	public String getCommentTravelText() {
		return commentTravelText;
	}





	public void setCommentTravelText(String commentTravelText) {
		this.commentTravelText = commentTravelText;
	}





	public TravelRequest getTravelRequest() {
		return travelRequest;
	}



	public void setTravelRequest(TravelRequest travelRequest) {
		this.travelRequest = travelRequest;
	}



	public Personnel getPersonnel() {
		return personnel;
	}



	public void setPersonnel(Personnel personnel) {
		this.personnel = personnel;
	}
	
	
	
	
	
	
	
	
	

}
