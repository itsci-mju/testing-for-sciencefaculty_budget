package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;


@Controller
public class CreateController {
	
	@RequestMapping(value="/loadViewRemainingBudgetPage", method = RequestMethod.GET)
	public ModelAndView loadViewRemainingBudgetPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ViewRemainingBudgetPage");
		
		PersonnelManager mg = new PersonnelManager();
		Personnel p = (Personnel) session.getAttribute("personnel_detail");
		
		try {
			Personnel personnelDetail = new Personnel();
			personnelDetail = mg.isRemainingBudget(p.getPersonnelID());
			//quuery ปีงบประมาณ
			List<BudgetYear> byear = mg.isBudgetYear();
			
			
			mav.addObject("personnel_detail",personnelDetail);
			mav.addObject("byear", byear); //ปีงบประมาณ
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
				
		return mav;
	}
	
	
	
	@RequestMapping(value="/loadCreateBudgetRequestPage", method = RequestMethod.GET)
	public ModelAndView loadCreateBudgetPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("CreateBudgetRequest");
			
		try {
			
			CreateManager cmg = new CreateManager();
			Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
			List<BudgetRequest> budget = new ArrayList<>();
			Personnel p = new Personnel();
			PersonnelManager mg = new PersonnelManager();
			
			String pid = personnelDetail.getPersonnelID();
			
			
			//quuery ปีงบประมาณ
			List<BudgetYear> byear = mg.isBudgetYear();
			
			
			budget = cmg.getStatusBudgetByDateDESC(pid);
			p = cmg.getBudgetCheck(pid);
			
			for(BudgetRequest b : budget) {
				
				System.out.println("รหัสเอกสารล่าสุด : " + b.getbudgetRequestID());
				System.out.println("สถานะล่าสุด : " + b.getStatus());
				System.out.println("ของบุคลากรหัสที่ : " + b.getPersonnel().getPersonnelID());

				if(b.getStatus().equals("ทำเอกสารรายงานการเดินทางแล้ว")) {
					mav = new ModelAndView("CreateBudgetRequest");
					
					if(p.getBudget() == 0) {
						mav = new ModelAndView("ViewRemainingBudgetPage");
						String checkStatus = "งบประมาณคงเหลือไม่พอ";		
						mav.addObject("byear", byear); //ปีงบประมาณ
						mav.addObject("checkStatus", checkStatus);
						return mav;
					}
					
					return mav;
					
				}else if(b.getStatus().equals("ยกเลิกการทำเอกสารแล้ว")) {
					mav = new ModelAndView("CreateBudgetRequest");
				
					
					return mav;
					
				}else {
					mav = new ModelAndView("ViewRemainingBudgetPage");
					String checkStatus = "กรุณาทำเอกสารก่อนหน้าให้เสร็จก่อน";
					
					
					mav.addObject("byear", byear);
					mav.addObject("checkStatus", checkStatus);
					return mav;
				}
				
				
			}
	
			
			
			
			/*
			 * System.out.println("pppp : " + p.getBudget()); if(p.getBudget() == 0) { mav =
			 * new ModelAndView("ViewRemainingBudgetPage"); String checkStatus =
			 * "งบประมาณคงเหลือไม่พอ";
			 * 
			 * 
			 * 
			 * 
			 * mav.addObject("byear", byear); //ปีงบประมาณ mav.addObject("checkStatus",
			 * checkStatus); return mav; }else { mav = new
			 * ModelAndView("CreateBudgetRequest");
			 * 
			 * // String checkStatus = "ทำต่อได้"; // // // // mav.addObject("checkStatus",
			 * checkStatus);
			 * 
			 * return mav; }
			 */
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
			
		return mav;
	}
	
	
	@RequestMapping(value="/loadCreateRequestingPermissionPage", method = RequestMethod.GET)
	public ModelAndView loadCreateRequestingPermissionPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("CreateRequestingPermission");
		return mav;
	}
	
	
	@RequestMapping(value="/loadCreateTravelRequestPage", method = RequestMethod.GET)
	public ModelAndView loadCreateTravelRequestPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("CreateTravelRequest");
		
		String bid = request.getParameter("bid");
		Personnel p = new Personnel();
		Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
		CreateManager cm = new CreateManager();
		
		try {
			p = cm.getBudgetCheck(personnelDetail.getPersonnelID());
			
			
			
			mav.addObject("p", p);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		session.setAttribute("bid", bid);
		
		
		return mav;
	}
	
	
	@RequestMapping(value="/loadCreateRegistrationBudgetRequestPage", method = RequestMethod.GET)
	public ModelAndView loadCreateRegistrationBudgetRequestPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("CreateRegistrationBudgetRequest");
		
		String bid = request.getParameter("bid");
		Personnel p = new Personnel();
		Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
		
		CreateManager cm = new CreateManager();
		try {
		p = cm.getBudgetCheck(personnelDetail.getPersonnelID());
			
		RequestingPermission rq = cm.getRequestingByID(bid);
		TravelRequest tr = cm.getTravelRequestByID(bid);
		
		double b = p.getBudget();
		double t =tr.getTotalBudget();
		double bt = 0.0;
		
		bt = b - t;
		
		
		mav.addObject("rq", rq);
		mav.addObject("tr", tr);
		mav.addObject("bt", bt);
		
		session.setAttribute("bid", bid);
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	
	@RequestMapping(value="/loadCreateTravelReportPage", method = RequestMethod.GET)
	public ModelAndView loadCreateTravelReportPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("CreateTravelReport");
		CreateManager manager = new CreateManager();
		
		
		String bid = request.getParameter("bid");
		session.setAttribute("bid", bid);
		
		try {
			
		Personnel p = new Personnel();
		Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
			
		p = manager.getBudgetCheck(personnelDetail.getPersonnelID());
			
		TravelRequest travel = new TravelRequest();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		
		//ผลรวมการเดินทาง
		travel = manager.getTotalTravel(bid);
		double traveltotal  = travel.getTotalBudget();
		
		//ผลรวมค่าลงทะเบียน
		reg = manager.getTotalRegis(bid);				
		double requestBudget = reg.getRequestBudget();
		
		mav.addObject("traveltotal", traveltotal);
		mav.addObject("requestBudget", requestBudget);
		mav.addObject("p", p);
		
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
	}
	
	
	@RequestMapping(value="/doAddBudgetRequest", method = RequestMethod.POST)
	public ModelAndView do_addBudgetRequest(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;		
		String msg = "";
		ModelAndView mav = new ModelAndView("CreateRequestingPermission");
		try {
			request.setCharacterEncoding("UTF-8");
		}catch(UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
		Personnel p = (Personnel) session.getAttribute("personnel_detail");
		
		CreateManager manager = new CreateManager();
		
		String pId = p.getPersonnelID(); 
		String budgetReqtestID = request.getParameter("budgetReqtestID");
		int numberOfDepart = Integer.parseInt(request.getParameter("numberOfDepart"));
		
		
		int bidtoInt = Integer.parseInt(budgetReqtestID);
		
		
		
		NumberFormat nf = NumberFormat.getNumberInstance(new Locale("th" , "TH" ,"TH"));
		nf.format(bidtoInt);
		nf.format(numberOfDepart);
		
		String numberToString = nf.format(numberOfDepart);
		String bidToString = nf.format(bidtoInt);
		
		String biddd = "อว.๖๙.๕." + numberToString +"/" + bidToString;
		
		String requestName = request.getParameter("requestName");
		String requestDate = request.getParameter("requestDate");
		
		String year[] = requestDate.split("-" );
		int cal = Integer.parseInt(year[0]) - 543;
		String dateYear = cal + "-" + year[1] + "-" + year[2];
		
		
 		Date date =  new Date();
	
		try {
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");			
			date = dateFormat.parse(dateYear);
			
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String chooseRequest =  request.getParameter("chooseRequest");		
		String status = "ทำเอกสารประสงค์ใช้งบประมาณแล้ว";	
		BudgetRequest budget = new BudgetRequest(biddd , requestName , date  , chooseRequest , status);		
		result = manager.isBudgetRequest(budget , dateYear , pId);		
		session.setAttribute("budgetId", biddd);
		
		System.out.println(result);
		if(result == 1) {
			msg = "บันทึกสำเร็จ";
			System.out.println(msg);
			
		}else{
			mav = new ModelAndView("CreateBudgetRequest");
			msg = "บันทึกไม่สำเร็จ";
			System.out.println(msg);
		}
		
		mav.addObject("msg", msg);
		
	}catch(SQLException e) {
		e.printStackTrace();
	}
		
		return mav;
	}
	
	@RequestMapping(value="/doAddRequestingPermission", method = RequestMethod.POST)
	public ModelAndView do_addRequestingPermission(HttpServletRequest request, Model md, HttpSession session) {	
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
			CreateManager manager = new CreateManager();
			
			String requestPerID = request.getParameter("requestPerID");
			
			int ridtoInt = Integer.parseInt(requestPerID);
			int numberOfDepart = Integer.parseInt(request.getParameter("numberOfDepart"));
			
			NumberFormat nf = NumberFormat.getNumberInstance(new Locale("th" , "TH" ,"TH"));
			nf.format(ridtoInt);
			nf.format(numberOfDepart);
			
			String numberToString = nf.format(numberOfDepart);
			String ridToString = nf.format(ridtoInt);
			
			String riddd = "อว.๖๙.๕." + numberToString + "/" + ridToString;
			
			
			String requestPermissionDate = request.getParameter("requestPermissionDate");
			
			String year[] = requestPermissionDate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			Date date =  new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String requestingName = request.getParameter("requestingName");
			String requestingText = request.getParameter("requestingText");
			
			String budgetId = (String) session.getAttribute("budgetId");

			RequestingPermission permission = new RequestingPermission(riddd , requestingName , date  , requestingText);

			result = manager.isRequestingPermision(permission , dateYear , budgetId);
			
			if (result == 1) {
				msg = "บันทึกสำเร็จ";
				System.out.println(msg);
			} else {
				mav = new ModelAndView("CreateRequestingPermission");
				msg = "บันทึกไม่สำเร็จ";
				System.out.println(msg);
			}
			
			mav.addObject("msg", msg);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		ListManager lm = new ListManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
		try {
			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(syf.format(b.getRequestDate()));
			}
			
			if(br.size() != 0) {
				
				session.setAttribute("budgetRequest", br);
				mav.addObject("rDate", rdate);
				mav.addObject("budgetRequest", br);
				mav.addObject("yDate", ydate);
				
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	

		return mav;
	}
		
	
	@RequestMapping(value="/doAddTravelRequest", method = RequestMethod.POST)
	public ModelAndView do_addTravelRequest(HttpServletRequest request, Model md, HttpSession session) {	
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");		
		String bid = (String) session.getAttribute("bid");
		
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		try {
			CreateManager manager = new CreateManager();
			
			String travelID = request.getParameter("travelID");
			int tidtoInt = Integer.parseInt(travelID);
			int numberOfDepart = Integer.parseInt(request.getParameter("numberOfDepart"));
			
			NumberFormat nf = NumberFormat.getNumberInstance(new Locale("th" , "TH" ,"TH"));
			nf.format(tidtoInt);
			nf.format(numberOfDepart);
			
			String numberToString = nf.format(numberOfDepart);
			String tidToString = nf.format(tidtoInt);
			
			String tiddd = "อว.๖๙.๕." + numberToString + "/" + tidToString;
			
			String travelDate = request.getParameter("travelDate");
			String year[] = travelDate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			Date date = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			String level = request.getParameter("level");
			String grade = request.getParameter("grade");
			String location = request.getParameter("location");
			String withName = request.getParameter("withName");
			String totalDate = request.getParameter("totalDate");

			String startDate = request.getParameter("startDate");
			String syear[] = startDate.split("-" );
			int scal = Integer.parseInt(syear[0]) - 543;
			String sdateYear = scal + "-" + syear[1] + "-" + syear[2];
			
			Date sdate = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dyyyy-MM-dd");
				sdate = dateFormat.parse(sdateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String endDate = request.getParameter("endDate");
			String eyear[] = endDate.split("-" );
			int ecal = Integer.parseInt(eyear[0]) - 543;
			String edateYear = ecal + "-" + eyear[1] + "-" + eyear[2];
			
			Date edate = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				edate = dateFormat.parse(edateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String titleName = request.getParameter("titleName");
			String travelVehicle = request.getParameter("travelVehicle");
			
			String allowance = request.getParameter("allowance");
			String vehicleBudget = request.getParameter("vehicleBudget");
			String rentalRoom = request.getParameter("rentalRoom");
			String otherBudget = request.getParameter("otherBudget");
			String totalBudget = request.getParameter("totalBudget");
			
			String payType = request.getParameter("payType");
			String msgg = "";
			if("1".equals(payType)) {
				msgg = "จะจ่ายเงินส่วนตัวทดรองไปก่อน";
			}else {
				msgg = "จะขอยืมเงินทดรองจ่ายไปก่อน";
			}
			
			TravelRequest travel = new TravelRequest(tiddd ,  date , level , grade , location , withName , totalDate , sdate , edate , titleName , travelVehicle ,
					Double.parseDouble(allowance) , Double.parseDouble(vehicleBudget) , Double.parseDouble(rentalRoom) ,
					Double.parseDouble(otherBudget) , Double.parseDouble(totalBudget) , msgg);
						
			result = manager.isTravelRequest(travel , dateYear , sdateYear , edateYear , bid);
			
			
			if (result == 1) {
				msg = "บันทึกสำเร็จ";
				System.out.println(msg);
			} else {
				mav = new ModelAndView("CreateTravelRequest");
				
				msg = "บันทึกไม่สำเร็จ";
				System.out.println(msg);
			}
			
			mav.addObject("msg", msg);
			
			session.removeAttribute("bid");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ListManager lm = new ListManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
		try {
			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));

			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(syf.format(b.getRequestDate()));
			}
			if(br.size() != 0) {
				
				session.setAttribute("budgetRequest", br);
				mav.addObject("rDate", rdate);
				mav.addObject("budgetRequest", br);
				mav.addObject("yDate", ydate);
				
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		
		
		
		return mav;
	}
	
	
	@RequestMapping(value="/doAddRegistrationBudgetRequest", method = RequestMethod.POST)
	public ModelAndView do_addRegistrationBudgetRequest(HttpServletRequest request, Model md, HttpSession session) {		
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");
		
		String bid = (String) session.getAttribute("bid");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		
	try {	
		CreateManager manager = new CreateManager();
		
		
		String registrationID = request.getParameter("registrationID");
		int numberOfDepart = Integer.parseInt(request.getParameter("numberOfDepart"));
		
		int regidtoInt = Integer.parseInt(registrationID);
		
		NumberFormat nf = NumberFormat.getNumberInstance(new Locale("th" , "TH" ,"TH"));
		nf.format(regidtoInt);
		nf.format(numberOfDepart);
		
		String regidToString = nf.format(regidtoInt);
		String numberToString = nf.format(numberOfDepart);
		
		String regidd = "อว.๖๙.๕." + numberToString + "/"  + regidToString;
		
		String regisDate = request.getParameter("regisDate");
		String year[] = regisDate.split("-" );
		int cal = Integer.parseInt(year[0]) - 543;
		String dateYear = cal + "-" + year[1] + "-" + year[2];
		
		Date date = new Date();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(dateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String textTo = request.getParameter("textTo");
		
		String beforeDate = request.getParameter("beforeDate");
		String beYear[] = beforeDate.split("-" );
		int beCal = Integer.parseInt(beYear[0]) - 543;
		String bedateYear = beCal + "-" + beYear[1] + "-" + beYear[2];
		
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(bedateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String titleName = request.getParameter("titleName");
		
		String regisStartDate = request.getParameter("regisStartDate");
		String rsYear[] = regisStartDate.split("-" );
		int rsCal = Integer.parseInt(rsYear[0]) - 543;
		String rdateYear = rsCal + "-" + rsYear[1] + "-" + rsYear[2];
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(rdateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		String regisEndDate = request.getParameter("regisEndDate");
		String eYear[] = regisEndDate.split("-" );
		int eCal = Integer.parseInt(rsYear[0]) - 543;
		String edateYear = eCal + "-" + eYear[1] + "-" + eYear[2];
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(edateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String location = request.getParameter("location");
		String cost = request.getParameter("cost");
		String requestBudget = request.getParameter("requestBudget");
		String budgetText = request.getParameter("budgetText");
		
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest(regidd , date ,textTo ,
				date , titleName , date , date , location , Double.parseDouble(cost) ,
				Double.parseDouble(requestBudget) , budgetText);
				
		result = manager.isRegistrationBudgetRequest(reg, dateYear, bedateYear , rdateYear, edateYear , bid);
		
		
		if (result == 1) {
			msg = "บันทึกสำเร็จ";
			System.out.println(msg);
		} else {
			mav = new ModelAndView("CreateRegistrationBudgetRequest");
			CreateManager cm = new CreateManager();
			RequestingPermission rq = cm.getRequestingByID(bid);
			TravelRequest tr = cm.getTravelRequestByID(bid);
			
			System.out.println("ddd" + rq.getRequestingPerDate());
			mav.addObject("rq", rq);
			mav.addObject("tr", tr);
			
			session.setAttribute("bid", bid);
			msg = "บันทึกไม่สำเร็จ";
			System.out.println(msg);
		}
		
		mav.addObject("msg", msg);
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	ListManager lm = new ListManager();
	Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
	try {
		List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
		List<String> rdate = new ArrayList<>();
		List<String> ydate = new ArrayList<>();
		String DATE_FORMAT = "dd MMMM yyyy";
		String YEAR_FORMAT = "yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
		SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
		
		for(BudgetRequest b : br) {								
			rdate.add(sdf.format(b.getRequestDate()));
			ydate.add(syf.format(b.getRequestDate()));
		}
		if(br.size() != 0) {
			
			session.setAttribute("budgetRequest", br);
			mav.addObject("rDate", rdate);
			mav.addObject("budgetRequest", br);
			mav.addObject("yDate", ydate);
			
			
		}
		
	} catch (SQLException e) {
		e.printStackTrace();
	}	
		
		return mav;
	}
	
		
	@RequestMapping(value = "/doAddTravelReport", method = RequestMethod.POST)
	public ModelAndView do_addTravelReport(HttpServletRequest request, Model md, HttpSession session) {	
		int result = 0;
		String msg = "";
		String bid = (String) session.getAttribute("bid");
		ModelAndView mav = new ModelAndView();
		CreateManager manager = new CreateManager();
		
		try {
			
			try {
				request.setCharacterEncoding("UTF-8");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
			
			String travelReportDate = request.getParameter("travelReportDate");
			
			TravelRequest travel = new TravelRequest();
			RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
					
			//ผลรวมการเดินทาง
			travel = manager.getTotalTravel(bid);
			double traveltotal  = travel.getTotalBudget();
			
			//ผลรวมค่าลงทะเบียน
			reg = manager.getTotalRegis(bid);				
			double requestBudget = reg.getRequestBudget();
			
			double sum = 0;
			sum = traveltotal + requestBudget;
			
			String year = "";
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
				year = dateFormat.format(dateFormat.parse(travelReportDate).getTime());
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			Personnel p = (Personnel) session.getAttribute("personnel_detail");				
			String status = p.getPersonnelTypeName();
			System.out.println("Status ::: " + status);
			
			BudgetYear byear = new BudgetYear();
			
			//query สถานะและปีมาคำนวน
			byear = manager.getStatusAndYearBudget(status, year);
			System.out.println("สถานะ : " + byear.getBudgetyeatid().getPersonnelType());
			System.out.println("เงิน : " + byear.getBudgetBath()); //เงินในตาราง budget year
			
			//หาผลลัพธ์
			double totalall = 0;				
			double getBudgetYear = 0;
			double personnelBudget = 0;
			
			Personnel per = new Personnel();
			per = manager.getBudgetById(p.getPersonnelID());
			//ตัวแปร
			getBudgetYear = byear.getBudgetBath(); //3000
			personnelBudget = per.getBudget(); //10000 //session ต้องเปลี่ยน session เป็นตัวแปลจริง
			getBudgetYear = personnelBudget; //คงเหลือ = 3000 = คงเหลือ
			
			
			
			Double total = Double.parseDouble(request.getParameter("total"));
			
						
			if(getBudgetYear >= total) { //1000 > 5000   1000 - 500
				
				Double realBudget = Double.parseDouble(request.getParameter("realBudget"));
				
				
				sum = realBudget + requestBudget;	//จริง
				
				System.out.println("sum : " + realBudget + " " +  requestBudget + " = " + sum);
				
				
				totalall = getBudgetYear - sum; //ผลรวม = คงเหลือ - ผลรวมทั้งหมดของเอกสาร
				
				String travelReportID = request.getParameter("travelReportID");
				int treport = Integer.parseInt(travelReportID);
				
				int numberOfDepart = Integer.parseInt(request.getParameter("numberOfDepart"));
				
				
				NumberFormat nf = NumberFormat.getNumberInstance(new Locale("th" , "TH" ,"TH"));
				nf.format(treport);
				nf.format(numberOfDepart);
				
				String numberToString = nf.format(numberOfDepart);
				String rportToString = nf.format(treport);
				
				
				String rportid = "อว.๖๙.๕." + numberToString + "/"  + rportToString;
				
				
				String reYear[] = travelReportDate.split("-" );
				int reCal = Integer.parseInt(reYear[0]) - 543;
				String reDateYear = reCal + "-" + reYear[1] + "-" + reYear[2];
				
				Date date = new Date();
				try {
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					date = dateFormat.parse(reDateYear);
				} catch (ParseException e) {
					e.printStackTrace();
				}

				String travelReportText = request.getParameter("travelReportText");

				TravelReport report = new TravelReport(rportid , date, travelReportText);

				
				result = manager.isTravelReport(report, reDateYear , bid , realBudget);

				if (result == 1) {
					mav = new ModelAndView("ListDocument");
					msg = "บันทึกสำเร็จ";
					System.out.println(msg);
					mav.addObject("msg", msg);
					mav.addObject("traveltotal", traveltotal);
					mav.addObject("requestBudget", requestBudget);
					
				} else {
					mav = new ModelAndView("CreateTravelReport");
					msg = "บันทึกไม่สำเร็จ";
					System.out.println(msg);
				}
				
				
				//ผลรวมทั้งหมดส่งไปอัพเดทใน procedure
				int resultUpdatePersonnel = 0;
				String statusUpdate = "";
				String pid = p.getPersonnelID();
				
				resultUpdatePersonnel = manager.isUpdateBudgetTotalInPersonnel(pid, totalall);
				
				if(resultUpdatePersonnel == 1) {
					statusUpdate = "อัพเดทสำเร็จ";
					System.out.println(statusUpdate);
				}else {
					statusUpdate = "อัพเดทไม่สำเร็จ";
					System.out.println(statusUpdate);
				}
				
				
				
			}else {
				mav = new ModelAndView("CreateTravelReport");
				String m = "ผลรวมของเอกสารเกินงบที่ให้ไว้กรุณาแก้ไขใหม่";
				msg = "บันทึกไม่สำเร็จ";
				
				mav.addObject("msg", msg);
				mav.addObject("m", m);
				mav.addObject("traveltotal", traveltotal);
				mav.addObject("requestBudget", requestBudget);
			}	
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		
		ListManager lm = new ListManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
		try {
			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(syf.format(b.getRequestDate()));
			}
			if(br.size() != 0) {
				
				session.setAttribute("budgetRequest", br);
				mav.addObject("rDate", rdate);
				mav.addObject("budgetRequest", br);
				mav.addObject("yDate", ydate);
				
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		
		
		
		
		
		
		return mav;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	

	
	
	
	
	
	

}
