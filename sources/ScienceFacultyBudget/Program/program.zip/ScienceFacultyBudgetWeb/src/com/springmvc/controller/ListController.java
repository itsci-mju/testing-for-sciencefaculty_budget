package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.CommentRegistrationBudget;
import com.springmvc.model.CommentTravel;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;
import com.springmvc.model.RequestingPermission;
import com.springmvc.model.TravelReport;
import com.springmvc.model.TravelRequest;

@Controller
public class ListController {
	
	@RequestMapping(value = "/back", method = RequestMethod.POST)
	public ModelAndView back(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		mav = loadViewRemainingBudgetPage(request, md, session);
		return mav;
	}
	

	@RequestMapping(value = "/loadListDocumentPage", method = RequestMethod.GET)
	public ModelAndView loadViewRemainingBudgetPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ListDocument");
		ListManager lm = new ListManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
				
		try {
			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
						
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(syf.format(b.getRequestDate()));
				System.out.println("BB : " + b.getStatus());
			}

			if(br.size() != 0) {							
				session.setAttribute("budgetRequest", br);				
				mav.addObject("budgetRequest", br);
				mav.addObject("rDate", rdate);
				mav.addObject("yDate", ydate);
			}
			
			mav.addObject("budgetRequest", br);
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mav;
	}

	@RequestMapping(value = "/doListDocument", method = RequestMethod.GET)
	public ModelAndView do_ListDocument(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView();
		ListManager lm = new ListManager();
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		try {
			String bid = request.getParameter("bid");
			String document = request.getParameter("doc");
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");			
			System.out.println(document);
			
			if (document.equals("budgetRequest")) {
				
				
				try {
					String statusButton = "user";
					
					BudgetRequest budget = lm.getBudgetRequestID(bid);
					mav = new ModelAndView("BudgetRequestDocument");
					System.out.println("เอกสารประสงค์ใช้งบประมาณ");
					mav.addObject("budget" , budget);
					mav.addObject("statusButton" , statusButton);
					
				}catch (SQLException e) {
					e.printStackTrace();
				}			
				
				return mav;
			} else if (document.equals("requestingPermission")) {
			
				try {
					RequestingPermission rp = lm.getRequestingPermission(bid);
					if(rp.getRequestPerID() != null) {
						String statusButton = "user";
						
						System.out.println(rp.getRequestPerID());
						mav = new ModelAndView("RequestingPermissionDocument");
						mav.addObject("statusButton" , statusButton);
						mav.addObject("permission", rp);
					}else {
						List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
						mav = new ModelAndView("ListDocument");
						mav.addObject("budgetRequest",br);
					}
					
					System.out.println("เอกสารขออนุญาต");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return mav;
			} else if (document.equals("travelRequest")) {
				
				try {
					
					TravelRequest travel = lm.getTravelRequest(bid);
					if(travel.getTravelID() != null) {
						System.out.println("เอกสารขออนุมัติการเดินทาง");						
						mav = new ModelAndView("TravelRequestDocument");
						
						String statusButton = "user";
						
						CommentManager cmg = new CommentManager();
						
						String tid = travel.getTravelID();
						List<CommentTravel> cmt = cmg.getListCommentTravelByID(tid);						
						
						
						
						mav.addObject("statusButton" , statusButton);
						mav.addObject("commentTravel", cmt);
						mav.addObject("travel", travel);
					}else {
						List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());						
						mav = new ModelAndView("ListDocument");						
						mav.addObject("budgetRequest", br);						
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return mav;
			} else if (document.equals("registrationBudgetRequest")) {				
				try {
					RegistrationBudgetRequest reg = lm.getRegistrationBudgetRequest(bid);
					
					if(reg.getRegistrationID() != null) {
						System.out.println("เอกสารขออนุมัติค่าลงทะเบียน");
						String statusButton = "user";
						
						mav = new ModelAndView("RegistrationBudgetRequestDocument");
						
						CommentManager cmg = new CommentManager();
						
						String rid = reg.getRegistrationID();
						List<CommentRegistrationBudget> cmr = cmg.getListCommentRegByID(rid);
						
//						CommentRegistrationBudget cmr = cmg.getCommentRegByID(rid);
								
						mav.addObject("statusButton" , statusButton);
						mav.addObject("cmr", cmr);
						
						mav.addObject("reg", reg);
					}else {
						List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());						
						mav = new ModelAndView("ListDocument");						
						mav.addObject("budgetRequest", br);
						
					}
					
					
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return mav;
			} else if (document.equals("travelReport")) {
				
				CreateManager manager = new CreateManager();
				TravelReport report = lm.getTravelReport(bid);
				TravelRequest travel = new TravelRequest();
				RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
				
				try {
					if(report.getTravelReportID() != null) {
						String statusButton = "user";
						
						//ผลรวมการเดินทาง
						travel = manager.getTotalTravelReal(bid);
						double traveltotal  = travel.getTotalBudget();
						double realBudget = travel.getRealBudget();
						
						//ผลรวมค่าลงทะเบียน
						reg = manager.getTotalRegis(bid);				
						double requestBudget = reg.getRequestBudget();
						
						double sum = requestBudget + realBudget;
						
						System.out.println("เอกสารรายงานการเดินทาง");
						mav = new ModelAndView("TravelReportDocument");
						
						mav.addObject("report", report);
						mav.addObject("traveltotal", traveltotal);
						mav.addObject("realBudget", realBudget);
						mav.addObject("requestBudget", requestBudget);
						mav.addObject("sum", sum);
						mav.addObject("statusButton" , statusButton);
						
					}else {
						List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
						
						
						mav = new ModelAndView("ListDocument");
						mav.addObject("budgetRequest", br);
						
					}
					
						
				
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return mav;
			} else {
				System.out.println("error");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
	
	
	
	
	

}
