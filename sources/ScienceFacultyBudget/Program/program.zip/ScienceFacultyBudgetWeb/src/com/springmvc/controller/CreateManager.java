package com.springmvc.controller;

import java.sql.*;
import java.util.*;
import com.springmvc.model.*;

import conn.ConnectionDB;

public class CreateManager {
	
	public int isBudgetRequest(BudgetRequest budget, String date, String pId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call addBudgetRequest_Procudure(?,?,?,?,?,?,?)}");
			ccstmt.setString(1, budget.getbudgetRequestID());
			ccstmt.setString(2, budget.getRequestName());
			ccstmt.setString(3, date);
			ccstmt.setString(4, budget.getChooseRequest());
			ccstmt.setString(5, budget.getStatus());
			ccstmt.setString(6, "");
			ccstmt.setString(7, pId);
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isRequestingPermision(RequestingPermission permission , String date , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call addRequestingPermisison_Procedure(?,?,?,?,?,?)}");
			ccstmt.setString(1, permission.getRequestPerID());
			ccstmt.setString(2, permission.getRequestPerName());
			ccstmt.setString(3, date);
			ccstmt.setString(4, permission.getRequestingPerText());
			ccstmt.setString(5, "");
			ccstmt.setString(6, budgetId);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public int isTravelRequest(TravelRequest travel , String Date , String stratDate , String endDate , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call addTravelRequest_Procedure(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			cstmt.setString(1, travel.getTravelID());
			cstmt.setDouble(2, travel.getAllowance());
			cstmt.setString(3, endDate);
			cstmt.setString(4, travel.getGrade());
			cstmt.setString(5, travel.getLevel());			
			cstmt.setString(6, travel.getLocation());
			cstmt.setDouble(7, travel.getOtherBudget());
			cstmt.setString(8, travel.getPayType());
			cstmt.setDouble(9, travel.getRentalRoom());
			cstmt.setString(10, stratDate);
			cstmt.setString(11, travel.getTitleName());
			cstmt.setDouble(12, travel.getTotalBudget());		
			cstmt.setString(13, travel.getTotalDate());			
			cstmt.setString(14, Date);
			cstmt.setString(15, travel.getTravelVehicle());			
			cstmt.setDouble(16, travel.getVehicleBudget());			
			cstmt.setString(17, travel.getWithName());	
			cstmt.setDouble(18, 0);
			cstmt.setString(19, "");
			cstmt.setString(20, budgetId);
			
			System.out.println("budgetId :" +budgetId);
			
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public int isRegistrationBudgetRequest(RegistrationBudgetRequest budgetRe , String regisDate , String beforeDate , String regisStartDate , String regisEndDate , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call addRegistrationBudget_Procedure(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			cstmt.setString(1, budgetRe.getRegistrationID());
			cstmt.setString(2, beforeDate); 
			cstmt.setString(3, budgetRe.getBudgetText());			
			cstmt.setDouble(4, budgetRe.getCost());
			cstmt.setString(5, budgetRe.getLocation());					
			cstmt.setString(6, regisDate);
			cstmt.setString(7, regisEndDate);
			cstmt.setString(8, regisStartDate);
			cstmt.setDouble(9, budgetRe.getRequestBudget());			
			cstmt.setString(10, budgetRe.getTextTo());
			cstmt.setString(11, budgetRe.getTitleName());
			cstmt.setString(12, "");
			cstmt.setString(13, budgetId);
			
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public int isTravelReport(TravelReport report , String travelReportDate , String budgetId , double realBudget) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call addTravelReport_Procedure(?,?,?,?,?,?)}");
			cstmt.setString(1, report.getTravelReportID());
			cstmt.setString(2, travelReportDate);
			cstmt.setString(3, report.getTravelReportText());
			cstmt.setString(4, budgetId);
			cstmt.setString(5, "");
			cstmt.setDouble(6, realBudget);
			
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	
	//ดึงค่า reg
	public RequestingPermission getRequestingByID(String bid)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		RequestingPermission permission = new RequestingPermission();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID , requestPerName , requestingPerDate , requestingPerText , BudgetRequest_budgetRequestID from requestingpermission where BudgetRequest_budgetRequestID = '"+ bid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return permission;		
	}
	
	public TravelRequest getTravelRequestByID(String bid)throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , allowance , endDate , grade , level , location , otherBudget , payType , rentalRoom , startDate , titleName , totalBudget , totalDate , travelDate , travelVehicle , vehicleBudget , withName , BudgetRequest_budgetRequestID from travelrequest  where BudgetRequest_budgetRequestID = '" + bid + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {					
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));				
				list.add(travel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return travel;		
	}
	
	
	//คำนวนหักค่าใช้จ่าย
	//ดึงสถานะ
	public BudgetRequest getStatusBudget(String bid)throws SQLException{
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , status from BudgetRequest where budgetRequestID = '"+ bid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				budget.setbudgetRequestID(rs.getString(1));
				budget.setStatus(rs.getString(2));
				
								
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return budget;		
	}
	
	//ดึงผลรวมเอกสารอยยุมัติการเดินทาง
	public TravelRequest getTotalTravel(String bid)throws SQLException{
		TravelRequest travel = new TravelRequest();
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , totalBudget from TravelRequest where BudgetRequest_budgetRequestID = '"+ bid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				travel.setTravelID(rs.getString(1));
				travel.setTotalBudget(rs.getDouble(2));
								
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return travel;		
	}
	//get เงินจริงตอน viewReport
	public TravelRequest getTotalTravelReal(String bid)throws SQLException{
		TravelRequest travel = new TravelRequest();
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , totalBudget , realBudget from TravelRequest where BudgetRequest_budgetRequestID = '"+ bid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				travel.setTravelID(rs.getString(1));
				travel.setTotalBudget(rs.getDouble(2));
				travel.setRealBudget(rs.getDouble(3));
								
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return travel;		
	}
	
	//ดึงผลรวมเอกสารขออนุมัติค่าลงทะเบียน
	public RegistrationBudgetRequest getTotalRegis(String bid)throws SQLException{
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID , requestBudget from RegistrationBudgetRequest where BudgetRequest_budgetRequestID = '"+ bid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				reg.setRegistrationID(rs.getString(1));
				reg.setRequestBudget(rs.getDouble(2));
								
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return reg;		
	}
	
	//query สถานะและปีเพื่อหางบประมาณ
	public BudgetYear getStatusAndYearBudget(String status , String year)throws SQLException{
		BudgetYear by = new  BudgetYear();
		BudgetYearId byid = new  BudgetYearId();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.personnelType, b.year , b.budgetBath from budgetYear b  where b.personnelType = (select p.personnelTypeName from Personnel p where p.personnelTypeName ='"+ status +"' group by p.personnelTypeName) and b.year = '"+ year +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				byid.setPersonnelType(rs.getString(1));
				byid.setYear(rs.getString(2));
				by.setBudgetBath(rs.getDouble(3));
				by.setBudgetyeatid(byid);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return by;		
	}
	
	//อัพเดทเงินในตาราง personnel
	public int isUpdateBudgetTotalInPersonnel(String pid, double budget) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call update_budget(?,?)}");
			ccstmt.setString(1, pid);
			ccstmt.setDouble(2, budget);
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	//select budgetById
	public Personnel getBudgetById(String pid)throws SQLException{
		Personnel p = new  Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , budget from personnel where personnelID = '"+pid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				p.setPersonnelID(rs.getString(1));
				p.setBudget(rs.getDouble(2));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return p;		
	}
	
		
	//check เงินก่อนทำเอกสารใบแรก
	public List<BudgetRequest> getStatusBudgetByDateDESC(String pid)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , status , requestDate , Personnel_personnelID from BudgetRequest where Personnel_personnelID = '"+pid+"' order by requestDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel p = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setStatus(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				p.setPersonnelID(rs.getString(4));
				budget.setPersonnel(p);
				
				
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	//check เงิน
	public Personnel getBudgetCheck(String pid)throws SQLException{
		Personnel p = new Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , budget from Personnel where personnelID = '"+pid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {
				
				p.setPersonnelID(rs.getString(1));
				p.setBudget(rs.getDouble(2));
				
											
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return p;		
	}

	 

}
