package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.Personnel;

@Controller
public class ListRemainingBudgetController {
	
	@RequestMapping(value = "/loadListRemainingBudgetPage", method = RequestMethod.GET)
	public ModelAndView loadListRemainingBudgetPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ListRemainingBudget");
		
		ListRemainingBudgetManager lm = new ListRemainingBudgetManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
		
		try {
			
			List<Personnel> br = lm.getListRemainingBudget();
			int f = br.size();
			
			
			
//			List<String> rdate = new ArrayList<>();
//			List<String> ydate = new ArrayList<>();
//			String DATE_FORMAT = "dd MMMM yyyy";
//			String YEAR_FORMAT = "yyyy";
//			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//			SimpleDateFormat ydf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
//			
//			
//			for(BudgetRequest b : br) {								
//				rdate.add(sdf.format(b.getRequestDate()));
//				ydate.add(ydf.format(b.getRequestDate()));
//			}

//			mav.addObject("rdate", rdate);
//			mav.addObject("ydate", ydate);
			mav.addObject("list", br);
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	
		
		
		return mav;
	}
	
	
	@RequestMapping(value = "/searchPersonnelName", method = RequestMethod.POST)
	public ModelAndView searchPersonnelName(HttpServletRequest request, Model md, HttpSession session) throws UnsupportedEncodingException {
		ModelAndView mav = new ModelAndView("ListRemainingBudget");
		
		ListRemainingBudgetManager lm = new ListRemainingBudgetManager();
		
		try {
			
		request.setCharacterEncoding("UTF-8");
			
		String firstname = request.getParameter("firstname");
			
		String lastname = request.getParameter("lastname");
		
		List<Personnel> p = null;
		
		if(lastname == "") {
			 
			 p = lm.getPersonnelBySearchFirstName(firstname);
			 
			 if(p.size() == 0) {
				 List<Personnel> br = lm.getListRemainingBudget();
				 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
				 
				 mav.addObject("pmsgg", pmsgg);
				 mav.addObject("list", br);
			 }
			 
			 if(p.size() != 0) {
				 mav.addObject("list", p);
			 }
			 
		}else if(firstname == ""){
			
			 p = lm.getPersonnelBySearchLastName(lastname);
			 if(p.size() == 0) {
				 List<Personnel> br = lm.getListRemainingBudget();
				 String pmsgg = "ค้นหานามสกุลที่คุณต้องการไม่เจอ";
					
				 mav.addObject("pmsgg", pmsgg);
				 mav.addObject("list", br);
			 }
			 
			 if(p.size() != 0) {
				 mav.addObject("list", p);
			 }
		}else {
			 p = lm.getPersonnelBySearchFirstLastName(firstname,lastname);
			 
			 if(p.size() == 0) {
				 List<Personnel> br = lm.getListRemainingBudget();
				 String pmsgg = "ค้นหาชื่อที่คุณต้องการไม่เจอ";
					
				 mav.addObject("pmsgg", pmsgg);
				 mav.addObject("list", br);
			 }
			 
			 if(p.size() != 0) {
				 mav.addObject("list", p);
			 }

		}
				
		/*
		 * List<String> rdate = new ArrayList<>(); List<String> ydate = new
		 * ArrayList<>(); String DATE_FORMAT = "dd MMMM yyyy"; String YEAR_FORMAT =
		 * "yyyy"; SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new
		 * Locale("th", "TH")); SimpleDateFormat ydf = new SimpleDateFormat(YEAR_FORMAT,
		 * new Locale("th", "TH"));
		 * 
		 * for(BudgetRequest b : br) { rdate.add(sdf.format(b.getRequestDate()));
		 * ydate.add(ydf.format(b.getRequestDate())); }
		 * 
		 * 
		 * mav.addObject("rdate", rdate); mav.addObject("ydate", ydate);
		 */
		
	
		
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
		
	}
	
}
