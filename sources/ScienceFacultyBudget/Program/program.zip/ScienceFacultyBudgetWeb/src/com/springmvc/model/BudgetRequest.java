package com.springmvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="BudgetRequest")
public class BudgetRequest {
	
	@Id
	@Column(name="budgetRequestID" , length = 20)
	private String budgetRequestID;
	
	@Column(name="requestName" , nullable=false , length = 255)
	private String requestName;
	
	
	@Column(name="requestDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date requestDate;
	
	@Column(name="chooseRequest" , nullable=false , length = 10)
	private String chooseRequest;
	
	@Column(name="status" , nullable=false , length = 50)
	private String status;
	
	@Column(name="fileName" , nullable=false , length = 50)
	private String fileName;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "Personnel_personnelID" , nullable=false)
	private Personnel personnel;
	
	
	@OneToOne(cascade = CascadeType.ALL , mappedBy = "budgetRequest")
	private RequestingPermission requestPer;
	
	@OneToOne(cascade = CascadeType.ALL , mappedBy = "budgetRequest")
	private TravelRequest travelRequest;
	
	@OneToOne(cascade = CascadeType.ALL , mappedBy = "budgetRequest")
	private RegistrationBudgetRequest registrationBudgetRequest;
	
	@OneToOne(cascade = CascadeType.ALL , mappedBy = "budgetRequest")
	private TravelReport travelReport;
	
	


	public BudgetRequest() {
		super();
	}

	
	


	public BudgetRequest(String fileName) {
		super();
		this.fileName = fileName;
	}





	public BudgetRequest(String budgetRequestID, String requestName, Date requestDate, String chooseRequest , String status) {
		super();
		this.budgetRequestID = budgetRequestID;
		this.requestName = requestName;
		this.requestDate = requestDate;
		this.chooseRequest = chooseRequest;
		this.status = status;
	}
	
	public BudgetRequest(String budgetRequestID, String requestName , String chooseRequest , String status) {
		super();
		this.budgetRequestID = budgetRequestID;
		this.requestName = requestName;
		this.chooseRequest = chooseRequest;
		this.status = status;
	}


	public String getbudgetRequestID() {
		return budgetRequestID;
	}


	public void setbudgetRequestID(String budgetRequestID) {
		this.budgetRequestID = budgetRequestID;
	}


	public String getRequestName() {
		return requestName;
	}


	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}


	public Date getRequestDate() {
		return requestDate;
	}


	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}


	public String getChooseRequest() {
		return chooseRequest;
	}


	public void setChooseRequest(String chooseRequest) {
		this.chooseRequest = chooseRequest;
	}
	
	


	public String getBudgetRequestID() {
		return budgetRequestID;
	}


	public void setBudgetRequestID(String budgetRequestID) {
		this.budgetRequestID = budgetRequestID;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

	public String getFileName() {
		return fileName;
	}





	public void setFileName(String fileName) {
		this.fileName = fileName;
	}





	public Personnel getPersonnel() {
		return personnel;
	}


	public void setPersonnel(Personnel personnel) {
		this.personnel = personnel;
	}


	public RequestingPermission getRequestPer() {
		return requestPer;
	}


	public void setRequestPer(RequestingPermission requestPer) {
		this.requestPer = requestPer;
	}


	public TravelRequest getTravelRequest() {
		return travelRequest;
	}


	public void setTravelRequest(TravelRequest travelRequest) {
		this.travelRequest = travelRequest;
	}


	public RegistrationBudgetRequest getRegistrationBudgetRequest() {
		return registrationBudgetRequest;
	}


	public void setRegistrationBudgetRequest(RegistrationBudgetRequest registrationBudgetRequest) {
		this.registrationBudgetRequest = registrationBudgetRequest;
	}


	public TravelReport getTravelReport() {
		return travelReport;
	}


	public void setTravelReport(TravelReport travelReport) {
		this.travelReport = travelReport;
	}


	
	
	



	
	
	
	
	
	
	
	

	

	
	


}
