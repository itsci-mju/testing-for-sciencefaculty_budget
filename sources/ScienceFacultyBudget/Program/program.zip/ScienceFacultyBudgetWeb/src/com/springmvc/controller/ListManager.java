package com.springmvc.controller;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;


public class ListManager {
	
	
	public List<BudgetRequest> getBudgetRequest(String username)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , chooseRequest , requestDate , requestName , status from budgetrequest where Personnel_personnelID ='"+username+"' order by requestDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				budget.setStatus(rs.getString(5));
				
				
				
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	} 
	
	
	
	public BudgetRequest getBudgetRequestID(String bid)throws SQLException{
		BudgetRequest budget = new BudgetRequest();
		Personnel personnel = new Personnel();
		Department d = new Department();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.title ,  p.firstname , p.lastname , p.position , d.departmentName from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where budgetRequestID =  '" + bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				personnel.setPosition(rs.getString(8));
				d.setDepartmentName(rs.getString(9));
				personnel.setDepartment(d);
				budget.setPersonnel(personnel);
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return budget;		
	} 
	
	
	public RequestingPermission getRequestingPermission(String budgetId)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		RequestingPermission permission = new RequestingPermission();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID , requestPerName , requestingPerDate , requestingPerText , BudgetRequest_budgetRequestID from requestingpermission where BudgetRequest_budgetRequestID = '"+ budgetId +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				
				list.add(permission);

			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return permission;		
	} 
	
	
	public TravelRequest getTravelRequest(String budgetId)throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		TravelRequest travel = new TravelRequest();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , allowance , endDate , grade , level , location , otherBudget , payType , rentalRoom , startDate , titleName , totalBudget , totalDate , travelDate , travelVehicle , vehicleBudget , withName , BudgetRequest_budgetRequestID from travelrequest where BudgetRequest_budgetRequestID = '" + budgetId + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);

			
			while(rs.next()) {				
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return travel;		
	} 
	
	
	public RegistrationBudgetRequest getRegistrationBudgetRequest(String budgetId)throws SQLException{

		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID , beforeDate , budgetText , cost , location , regisDate , regisEndDate , regisStartDate , requestBudget , textTo , titleName , BudgetRequest_budgetRequestID from registrationbudgetrequest where BudgetRequest_budgetRequestID = '" + budgetId + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				
				reg.setRegistrationID(rs.getString(1));
				reg.setBeforeDate(rs.getDate(2));
				reg.setBudgetText(rs.getString(3));
				reg.setCost(rs.getDouble(4));
				reg.setLocation(rs.getString(5));
				reg.setRegisDate(rs.getDate(6));
				reg.setRegisEndDate(rs.getDate(7));
				reg.setRegisStartDate(rs.getDate(8));
				reg.setRequestBudget(rs.getDouble(9));
				reg.setTextTo(rs.getString(10));
				reg.setTitleName(rs.getString(11));
				

				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return reg;		
	} 
	
	public TravelReport getTravelReport(String budgetId)throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		TravelReport report = new TravelReport();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelReportID , travelReportDate , travelReportText , BudgetRequest_budgetRequestID  from travelreport where BudgetRequest_budgetRequestID = '" + budgetId + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				
				report.setTravelReportID(rs.getString(1));
				report.setTravelReportDate(rs.getDate(2));
				report.setTravelReportText(rs.getString(3));

				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return report;		
	} 
	
	
	/* upload */
	
	
	public RequestingPermission getrpIDFormBudgetRequestId(String bid) {
		RequestingPermission rp = new RequestingPermission();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID from RequestingPermission where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				rp.setRequestPerID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return rp;
	}
	
	public TravelRequest getTravelIDFormBudgetRequestId(String bid) {
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select travelID from TravelRequest where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				travel.setTravelID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return travel;
	}
	
	public RegistrationBudgetRequest getRegIDFormBudgetRequestId(String bid) {
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID from RegistrationBudgetRequest where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				reg.setRegistrationID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return reg;
	}
	
	
	public TravelReport getReortIDFormBudgetRequestId(String bid) {
		TravelReport report = new TravelReport();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select travelReportID from TravelReport where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				report.setTravelReportID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return report;
	}
	
	
	
//	check unckeck listjsp
		
	public List<TravelRequest> getTravelRequestCheck(String budgetId)throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , allowance , endDate , grade , level , location , otherBudget , payType , rentalRoom , startDate , titleName , totalBudget , totalDate , travelDate , travelVehicle , vehicleBudget , withName , BudgetRequest_budgetRequestID from travelrequest where BudgetRequest_budgetRequestID = '" + budgetId + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				TravelRequest travel = new TravelRequest();
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));			
				
				list.add(travel);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	} 
	
	
	/* upload check null */
	
	
	public RequestingPermission getrpIDNullFormBudgetRequestId(String bid) {
		RequestingPermission rp = new RequestingPermission();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select BudgetRequest_budgetRequestID from File";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				rp.setRequestPerID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return rp;
	}
	
	
	/* check ทำเอกสารแล้ว */
	
	public List<BudgetRequest> getTravelRequestCheckStatus(String status)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select t.travelID , b.status from budgetrequest b inner join TravelRequest t on b.budgetRequestID = t.BudgetRequest_budgetRequestID where b.status =  '" + status + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				TravelRequest travel = new TravelRequest();
				travel.setTravelID(rs.getString(1));
				budget.setStatus(rs.getString(2));
				
				budget.setTravelRequest(travel);
				
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	} 
	
//	public TravelRequest getTravelRequestCheckStatus(String status) {
//		TravelRequest travel = new TravelRequest();
//		BudgetRequest budget = new BudgetRequest();
//		ConnectionDB condb = new ConnectionDB();
//		Connection conn = condb.getConnection();
//		try {
//			Statement stmt = conn.createStatement();
//			String sql = "Select t.travelID , b.status from budgetrequest b inner join TravelRequest t on b.budgetRequestID = t.BudgetRequest_budgetRequestID where b.status ='" + status + "'";
//			ResultSet rs = stmt.executeQuery(sql);
//			System.out.println(sql);
//			while(rs.next()) {
//				travel.setTravelID(rs.getString(1));
//				budget.setStatus(rs.getString(2));
//				budget.setTravelRequest(travel);
//				System.out.println("" + rs.getString(1));
//				System.out.println("" + rs.getString(2));
//				
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		return travel;
//	}
	
	
	public List<TravelRequest> getTravelRequestCheckPass()throws SQLException{
	List<TravelRequest> list = new ArrayList<>();
	ConnectionDB condb = new ConnectionDB();
	Connection conn = condb.getConnection();
	try {			
		Statement stmt = conn.createStatement();
		String sql = "Select t.travelID , t.BudgetRequest_budgetRequestID , b.status from budgetrequest b inner join TravelRequest t on b.budgetRequestID = t.BudgetRequest_budgetRequestID";
		ResultSet rs = stmt.executeQuery(sql);
		System.out.println(sql);
		
		while(rs.next()) {				
			BudgetRequest budget = new BudgetRequest();
			TravelRequest travel = new TravelRequest();
			
			travel.setTravelID(rs.getString(1));
			budget.setbudgetRequestID(rs.getString(2));
			budget.setStatus(rs.getString(3));
			travel.setBudgetRequest(budget);
			
			System.out.println(rs.getString(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			
			list.add(travel);
		} 
	}catch(SQLException e) {
		e.printStackTrace();
	}
	conn.close();
	return list;		
} 
	
	public List<RegistrationBudgetRequest> getRegCheckPass()throws SQLException{
		List<RegistrationBudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.registrationID , r.BudgetRequest_budgetRequestID , b.status from budgetrequest b inner join RegistrationBudgetRequest r on b.budgetRequestID = r.BudgetRequest_budgetRequestID";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
				
				reg.setRegistrationID(rs.getString(1));
				budget.setbudgetRequestID(rs.getString(2));
				budget.setStatus(rs.getString(3));
				reg.setBudgetRequest(budget);
				
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				
				list.add(reg);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	} 
	
		
	
	
	
	
	
	
	
	
	
	
	

}
