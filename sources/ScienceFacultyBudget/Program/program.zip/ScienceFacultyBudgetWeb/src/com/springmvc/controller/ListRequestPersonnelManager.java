package com.springmvc.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.Personnel;
import com.springmvc.model.TravelRequest;

import conn.ConnectionDB;

public class ListRequestPersonnelManager {
	
	public List<TravelRequest> getListRequestPersonnel()throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select t.travelID , t.allowance , t.endDate , t.grade , t.level , t.location , t.otherBudget , t.payType , t.rentalRoom , t.startDate , t.titleName , t.totalBudget , t.totalDate , t.travelDate , t.travelVehicle , t.vehicleBudget , t.withName , p.firstname , p.lastname from travelrequest t inner join budgetrequest b on t.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				TravelRequest travel = new TravelRequest();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));				
				p.setFirstname(rs.getString(18));
				p.setLastname(rs.getString(19));
				budgetRequest.setPersonnel(p);
				travel.setBudgetRequest(budgetRequest);
				
				
				
				list.add(travel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	public List<TravelRequest> getListRequestPersonnelTest()throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select month(startDate) , year(startDate) , location , count(BudgetRequest_budgetRequestID) from travelrequest group by month(startDate) , year(startDate) , location order by year(startDate) DESC , month(startDate) DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				TravelRequest travel = new TravelRequest();
				BudgetRequest budgetRequest = new BudgetRequest();
				travel.setStartDate(rs.getDate(1));
				travel.setStartDate(rs.getDate(2));
				travel.setLocation(rs.getString(3));
				
				budgetRequest.setbudgetRequestID(rs.getString(4));
				travel.setBudgetRequest(budgetRequest);
				
				if(Integer.parseInt(budgetRequest.getbudgetRequestID()) > 1) {
					list.add(travel);
				}
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	public List<TravelRequest> getRequestPersonnel(String location , String d)throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select t.travelID , t.allowance , t.endDate , t.grade , t.level , t.location , t.otherBudget , "
					+ "t.payType , t.rentalRoom , t.startDate , t.titleName , t.totalBudget , t.totalDate , t.travelDate , "
					+ "t.travelVehicle , t.vehicleBudget , t.withName , p.firstname , p.lastname , p.title "
					+ "from travelrequest t inner join budgetrequest b on t.BudgetRequest_budgetRequestID = b.budgetRequestID "
					+ "inner join personnel p on b.Personnel_personnelID = p.personnelID "
					+ "where t.location ='" + location + "' and year(t.startDate)='"+d+"' order by day(startDate) DESC" ;
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);

			
			while(rs.next()) {				
				TravelRequest travel = new TravelRequest();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));				
				p.setFirstname(rs.getString(18));
				p.setLastname(rs.getString(19));
				p.setTitle(rs.getString(20));
				budgetRequest.setPersonnel(p);
				travel.setBudgetRequest(budgetRequest);
				
				
				
				
				
				
				list.add(travel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	

}
