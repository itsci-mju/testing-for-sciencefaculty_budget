package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;
import com.springmvc.model.RequestingPermission;
import com.springmvc.model.TravelReport;
import com.springmvc.model.TravelRequest;

@Controller
public class EditDocumentController {

	@RequestMapping(value = "/doEditDocument", method = RequestMethod.GET)
	public ModelAndView do_EditDocument(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		ListManager lm = new ListManager();
		String msg = "";

		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
		String bid = request.getParameter("bid");
		String document = request.getParameter("doc");
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

		if (document.equals("budgetRequest")) {

			try {
				BudgetRequest budget = lm.getBudgetRequestID(bid);
				
				mav = new ModelAndView("EditBudgetRequest");
				String requestname = budget.getRequestName();
				System.out.println(requestname + " : requestname");
				
				mav.addObject("requestname", requestname);
				mav.addObject("budget", budget);
				

			} catch (SQLException e) {
				e.printStackTrace();
			}

			return mav;
		} else if (document.equals("requestingPermission")) {
			
			try {
				RequestingPermission rp = lm.getRequestingPermission(bid);
				if(rp.getRequestPerID() != null) {
					System.out.println(rp.getRequestPerID());
					
					session.setAttribute("bid", bid);
					mav = new ModelAndView("EditRequestingPermission");
					mav.addObject("permission", rp);
				}else {
					List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
					mav = new ModelAndView("ListDocument");
					mav.addObject("budgetRequest",br);
				}
				
				System.out.println("เอกสารขออนุญาต");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return mav;
		}else if (document.equals("travelRequest")) {
			
			try {
				
				TravelRequest travel = lm.getTravelRequest(bid);
				if(travel.getTravelID() != null) {
					System.out.println("เอกสารขออนุมัติการเดินทาง");
					
					Personnel p = new Personnel();
					Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
					CreateManager cm = new CreateManager();	
					p = cm.getBudgetCheck(personnelDetail.getPersonnelID());
						
					
										
					session.setAttribute("bid", bid);
					mav = new ModelAndView("EditTravelRequest");
					mav.addObject("p", p);
					mav.addObject("travel", travel);
				}else {
					List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
					mav = new ModelAndView("ListDocument");
					mav.addObject("budgetRequest", br);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return mav;
		} else if (document.equals("registrationBudgetRequest")) {

			try {
				RegistrationBudgetRequest reg = lm.getRegistrationBudgetRequest(bid);
				
				if(reg.getRegistrationID() != null) {
					System.out.println("เอกสารขออนุมัติค่าลงทะเบียน");
					Personnel p = new Personnel();
					Personnel personnelDetail = (Personnel) session.getAttribute("personnel_detail");
					
					CreateManager cm = new CreateManager();
					
					p = cm.getBudgetCheck(personnelDetail.getPersonnelID());
					
					RequestingPermission rq = cm.getRequestingByID(bid);
					TravelRequest tr = cm.getTravelRequestByID(bid);
					
					double b = p.getBudget();
					double t =tr.getTotalBudget();
					double bt = 0.0;
					
					bt = b - t;
					
					
					session.setAttribute("bid", bid);
					mav = new ModelAndView("EditRegistrationBudgetRequest");
					mav.addObject("bt", bt);
					mav.addObject("reg", reg);
				}else {
					List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
					mav = new ModelAndView("ListDocument");
					mav.addObject("budgetRequest", br);
				}
				
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return mav;
		} else if (document.equals("travelReport")) {
			
			TravelReport report = lm.getTravelReport(bid);
			try {
				if(report.getTravelReportID() != null) {
					System.out.println("เอกสารรายงานการเดินทาง");
					session.setAttribute("bid", bid);
					mav = new ModelAndView("EditTravelReport");
					
					mav.addObject("report", report);	
				}else {
					List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
					mav = new ModelAndView("ListDocument");
					mav.addObject("budgetRequest", br);
				}
				
					
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return mav;
		} else {
			System.out.println("error");
		}
			
		}catch(Exception e) {
			e.printStackTrace();
		}

		return mav;
	}

	@RequestMapping(value = "/doEditBudgetRequest", method = RequestMethod.POST)
	public ModelAndView do_EditBudgetRequest(HttpServletRequest request, Model md, HttpSession session) {	
		int result = 0;		
		ModelAndView mav = new ModelAndView("ListDocument");
		
		String msg = "";
		
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
			
			Personnel p = (Personnel) session.getAttribute("personnel_detail");
			EditDocumentManager em = new EditDocumentManager();
			
			String pId = p.getPersonnelID();
			String budgetReqtestID = request.getParameter("budgetReqtestID");
			String requestName = request.getParameter("requestName");
			String requestDate = request.getParameter("requestDate");
			
			String year[] = requestDate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			Date date = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}

			String chooseRequest = request.getParameter("chooseRequest");
			String status = "ทำเอกสารแล้ว";

			BudgetRequest budget = new BudgetRequest(budgetReqtestID, requestName, date, chooseRequest , status);

			result = em.isEditBudgetRequest(budget, dateYear, pId);

			if (result == 1) {
				msg = "แก้ไขสำเร็จ";
				System.out.println(msg);
			} else {
				msg = "แก้ไขไม่สำเร็จ";
				System.out.println(msg);
			}
			
			ListManager lm = new ListManager();
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

			try {
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			mav.addObject("msg", msg);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mav;

	}
	
	
	
	
	@RequestMapping(value = "/doEditRequestingPermission", method = RequestMethod.POST)
	public ModelAndView do_EditRequestingPermission(HttpServletRequest request, Model md, HttpSession session) {	
		int result = 0;		
		ModelAndView mav = new ModelAndView("ListDocument");
		String msg = "";
		
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
			
			Personnel p = (Personnel) session.getAttribute("personnel_detail");
			EditDocumentManager em = new EditDocumentManager();
			
			
			String requestPerID = request.getParameter("requestPerID");
			String requestPermissionDate = request.getParameter("requestPermissionDate");
			
			String year[] = requestPermissionDate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			
			Date date =  new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			
			String requestingName = request.getParameter("requestingName");
			String requestingText = request.getParameter("requestingText");
			
			String budgetId = (String) session.getAttribute("budgetId");

			RequestingPermission permission = new RequestingPermission(requestPerID , requestingName , date  , requestingText);

			result = em.isEditRequestingPermission(permission , dateYear , budgetId);

			if (result == 1) {
				msg = "แก้ไขสำเร็จ";
				System.out.println(msg);
			} else {
				msg = "แก้ไขไม่สำเร็จ";
				System.out.println(msg);
			}
			
			ListManager lm = new ListManager();
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

			try {
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}


			mav.addObject("msg", msg);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mav;

	}
	
	
	@RequestMapping(value = "/doEditTravelRequest", method = RequestMethod.POST)
	public ModelAndView do_EditTravelRequest(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");
		
		
		
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		try {
			EditDocumentManager em = new EditDocumentManager();
			
			String travelID = request.getParameter("travelID");
			String travelDate = request.getParameter("travelDate");			
			String year[] = travelDate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			Date date = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			String level = request.getParameter("level");
			String grade = request.getParameter("grade");
			String location = request.getParameter("location");
			String withName = request.getParameter("withName");
			String totalDate = request.getParameter("totalDate");

			String startDate = request.getParameter("startDate");
			String syear[] = startDate.split("-" );
			int scal = Integer.parseInt(syear[0]) - 543;
			String sdateYear = scal + "-" + syear[1] + "-" + syear[2];
			
			Date sdate = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				sdate = dateFormat.parse(sdateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String endDate = request.getParameter("endDate");
			String eyear[] = endDate.split("-" );
			int ecal = Integer.parseInt(eyear[0]) - 543;
			String edateYear = ecal + "-" + eyear[1] + "-" + eyear[2];
			
			Date edate = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				edate = dateFormat.parse(edateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String titleName = request.getParameter("titleName");
			String travelVehicle = request.getParameter("travelVehicle");
			
			String allowance = request.getParameter("allowance");
			String vehicleBudget = request.getParameter("vehicleBudget");
			String rentalRoom = request.getParameter("rentalRoom");
			String otherBudget = request.getParameter("otherBudget");
			String totalBudget = request.getParameter("totalBudget");
			
			String payType = request.getParameter("payType");
			String msgg = "";
			if("1".equals(payType)) {
				msgg = "จะจ่ายเงินส่วนตัวทดรองไปก่อน";
			}else {
				msgg = "จะขอยืมเงินทดรองจ่ายไปก่อน";
			}
			
			String bid = (String) session.getAttribute("bid");
			
			TravelRequest travel = new TravelRequest(travelID ,  date , level , grade , location , withName , totalDate , sdate , edate , titleName , travelVehicle ,
					Double.parseDouble(allowance) , Double.parseDouble(vehicleBudget) , Double.parseDouble(rentalRoom) ,
					Double.parseDouble(otherBudget) , Double.parseDouble(totalBudget) , msgg);
			
			
			
			result = em.isEditTravelRequest(travel , dateYear , sdateYear , edateYear , bid);
			
			
			if (result == 1) {
				msg = "แก้ไขสำเร็จ";
				System.out.println(msg);
			} else {
				msg = "แก้ไขไม่สำเร็จ";
				System.out.println(msg);
			}
			
			mav.addObject("msg", msg);
			
			ListManager lm = new ListManager();
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

			try {
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			session.removeAttribute("bid");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
	}
	
	@RequestMapping(value = "/doEditRegistrationBudgetRequest", method = RequestMethod.POST)
	public ModelAndView do_EditRegistrationBudgetRequest(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");
		
		
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		
	try {	
		EditDocumentManager em = new EditDocumentManager();
		
		
		String registrationID = request.getParameter("registrationID");		
		String regisDate = request.getParameter("regisDate");
		String year[] = regisDate.split("-" );
		int cal = Integer.parseInt(year[0]) - 543;
		String dateYear = cal + "-" + year[1] + "-" + year[2];
		
		Date date = new Date();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(dateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String textTo = request.getParameter("textTo");
		
		String beforeDate = request.getParameter("beforeDate");
		String beYear[] = beforeDate.split("-" );
		int beCal = Integer.parseInt(beYear[0]) - 543;
		String bedateYear = beCal + "-" + beYear[1] + "-" + beYear[2];
		
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(bedateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String titleName = request.getParameter("titleName");
		
		String regisStartDate = request.getParameter("regisStartDate");
		String rsYear[] = regisStartDate.split("-" );
		int rsCal = Integer.parseInt(rsYear[0]) - 543;
		String rdateYear = rsCal + "-" + rsYear[1] + "-" + rsYear[2];
		
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(rdateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		String regisEndDate = request.getParameter("regisEndDate");
		String eYear[] = regisEndDate.split("-" );
		int eCal = Integer.parseInt(rsYear[0]) - 543;
		String edateYear = eCal + "-" + eYear[1] + "-" + eYear[2];
		
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(edateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String location = request.getParameter("location");
		String cost = request.getParameter("cost");
		String requestBudget = request.getParameter("requestBudget");
		String budgetText = request.getParameter("budgetText");
		
		String bid = (String) session.getAttribute("bid");
		
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest(registrationID , date ,textTo ,
				date , titleName , date , date , location , Double.parseDouble(cost) ,
				Double.parseDouble(requestBudget) , budgetText);
		
		
		result = em.isEditRegistrationBudgetRequest(reg, dateYear , bedateYear , rdateYear, edateYear , bid);
		
		ListManager lm = new ListManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

		try {
			List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(syf.format(b.getRequestDate()));
			}

			if(br.size() != 0) {							
				session.setAttribute("budgetRequest", br);				
				mav.addObject("budgetRequest", br);
				mav.addObject("rDate", rdate);
				mav.addObject("yDate", ydate);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		if (result == 1) {
			msg = "แก้ไขสำเร็จ";
			System.out.println(msg);
		} else {
			msg = "แก้ไขไม่สำเร็จ";
			System.out.println(msg);
		}
		
		mav.addObject("msg", msg);
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
		
		return mav;
	}
	
	@RequestMapping(value = "/doEditTravelReport", method = RequestMethod.POST)
	public ModelAndView do_EditTravelReport(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;
		String msg = "";
		ModelAndView mav = new ModelAndView("ListDocument");

		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		try {
			EditDocumentManager em = new EditDocumentManager();

			
			String travelReportID = request.getParameter("travelReportID");
			String travelReportDate = request.getParameter("travelReportDate");
			Date date = new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(travelReportDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}

			String travelReportText = request.getParameter("travelReportText");

			String bid = (String) session.getAttribute("bid");
			
			TravelReport report = new TravelReport(travelReportID , date, travelReportText);

			
			result = em.isEditTravelReport(report, travelReportDate , bid);
			
			ListManager lm = new ListManager();
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");

			try {
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}

			if (result == 1) {
				msg = "อัพเดทสำเร็จ";
				System.out.println(msg);
			} else {
				msg = "อัพเดทไม่สำเร็จ";
				System.out.println(msg);
			}
			
			mav.addObject("msg", msg);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return mav;
	}

}
