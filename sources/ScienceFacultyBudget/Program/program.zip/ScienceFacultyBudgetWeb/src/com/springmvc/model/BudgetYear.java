package com.springmvc.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="BudgetYear")
public class BudgetYear implements Serializable{
	
	@EmbeddedId
	private BudgetYearId budgetyeatid;
	
	
	@Column(name="budgetBath" , nullable=false , length = 10)
	private double budgetBath;
	
	
	public BudgetYear() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BudgetYear(double budgetBath) {
		super();
		this.budgetBath = budgetBath;
	}

	
	public double getBudgetBath() {
		return budgetBath;
	}

	public void setBudgetBath(double budgetBath) {
		this.budgetBath = budgetBath;
	}

	public BudgetYearId getBudgetyeatid() {
		return budgetyeatid;
	}

	public void setBudgetyeatid(BudgetYearId budgetyeatid) {
		this.budgetyeatid = budgetyeatid;
	}
	
	
	
	

	

	

	
	
	

}
