package com.springmvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="RegistrationBudgetRequest")
public class RegistrationBudgetRequest {
	
	@Id
	@Column(name="registrationID" , length = 20)
	private String registrationID;
			
	
	@Column(name="regisDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date regisDate;
	
	@Column(name="textTo" , nullable=false , length = 45)
	private String textTo;
	
	@Column(name="beforeDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date beforeDate;
	
	@Column(name="titleName" , nullable=false , length = 100)
	private String titleName;
	
	
	
	@Column(name="regisStartDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date regisStartDate;
	
	@Column(name="regisEndDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date regisEndDate;
	
	@Column(name="location" , nullable=false , length = 50)
	private String location;
	
	
	@Column(name="cost" , nullable=false)
	private double cost;
	
	@Column(name="requestBudget" , nullable=false)
	private double requestBudget;
	
	@Column(name="budgetText" , nullable=false , length = 45)
	private String budgetText;
	
	@Column(name="fileName" , nullable=false , length = 50)
	private String fileName;
	
		
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "BudgetRequest_budgetRequestID" , nullable=false)
	private BudgetRequest budgetRequest;
	
	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "registrationBudgetRequest")
	private List<CommentRegistrationBudget> commentReg = new ArrayList<>();
	
	
	
	
	
	public RegistrationBudgetRequest() {
		super();
	}

	
	

	public RegistrationBudgetRequest(String fileName) {
		super();
		this.fileName = fileName;
	}




	public RegistrationBudgetRequest(String registrationID, Date regisDate, String textTo, Date beforeDate,
			String titleName, Date regisStartDate, Date regisEndDate, String location, double cost,
			double requestBudget, String budgetText) {
		super();
		this.registrationID = registrationID;
		this.regisDate = regisDate;
		this.textTo = textTo;
		this.beforeDate = beforeDate;
		this.titleName = titleName;
		this.regisStartDate = regisStartDate;
		this.regisEndDate = regisEndDate;
		this.location = location;
		this.cost = cost;
		this.requestBudget = requestBudget;
		this.budgetText = budgetText;
	}



	public String getRegistrationID() {
		return registrationID;
	}



	public Date getRegisDate() {
		return regisDate;
	}



	public String getTextTo() {
		return textTo;
	}



	public Date getBeforeDate() {
		return beforeDate;
	}



	public String getTitleName() {
		return titleName;
	}



	public Date getRegisStartDate() {
		return regisStartDate;
	}



	public Date getRegisEndDate() {
		return regisEndDate;
	}



	public String getLocation() {
		return location;
	}



	public double getCost() {
		return cost;
	}



	public double getRequestBudget() {
		return requestBudget;
	}



	public String getBudgetText() {
		return budgetText;
	}



	public BudgetRequest getBudgetRequest() {
		return budgetRequest;
	}



	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}



	public void setRegisDate(Date regisDate) {
		this.regisDate = regisDate;
	}



	public void setTextTo(String textTo) {
		this.textTo = textTo;
	}



	public void setBeforeDate(Date beforeDate) {
		this.beforeDate = beforeDate;
	}



	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}



	public void setRegisStartDate(Date regisStartDate) {
		this.regisStartDate = regisStartDate;
	}



	public void setRegisEndDate(Date regisEndDate) {
		this.regisEndDate = regisEndDate;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public void setCost(double cost) {
		this.cost = cost;
	}



	public void setRequestBudget(double requestBudget) {
		this.requestBudget = requestBudget;
	}



	public void setBudgetText(String budgetText) {
		this.budgetText = budgetText;
	}



	public void setBudgetRequest(BudgetRequest budgetRequest) {
		this.budgetRequest = budgetRequest;
	}




	public String getFileName() {
		return fileName;
	}




	public void setFileName(String fileName) {
		this.fileName = fileName;
	}




	public List<CommentRegistrationBudget> getCommentReg() {
		return commentReg;
	}




	public void setCommentReg(List<CommentRegistrationBudget> commentReg) {
		this.commentReg = commentReg;
	}
	
	
	



}
