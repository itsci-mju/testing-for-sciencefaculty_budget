package com.springmvc.controller;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class EditDocumentManager {
	
	public int isEditBudgetRequest(BudgetRequest budget, String date, String pId) throws SQLException{
		int result = 0;
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call updateBudgetRequest_Procedure(?,?,?,?,?)}");
			cstmt.setString(1, budget.getbudgetRequestID());
			cstmt.setString(2, budget.getRequestName());
			cstmt.setString(3, date);
			cstmt.setString(4, budget.getChooseRequest());
			cstmt.setString(5, pId);
			
			
			System.out.println(cstmt);
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isEditRequestingPermission(RequestingPermission permission , String date , String budgetId) throws SQLException{
		int result = 0;
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call updateRequestingPermission_Procedure(?,?,?,?,?)}");
			cstmt.setString(1, permission.getRequestPerID());
			cstmt.setString(2, permission.getRequestPerName());
			cstmt.setString(3, date);
			cstmt.setString(4, permission.getRequestingPerText());
			cstmt.setString(5, budgetId);
			
			System.out.println(cstmt);
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public int isEditTravelRequest(TravelRequest travel , String Date , String stratDate , String endDate , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call updateTravelRequest_Procedure(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			cstmt.setString(1, travel.getTravelID());
			cstmt.setDouble(2, travel.getAllowance());
			cstmt.setString(3, endDate);
			cstmt.setString(4, travel.getGrade());
			cstmt.setString(5, travel.getLevel());			
			cstmt.setString(6, travel.getLocation());
			cstmt.setDouble(7, travel.getOtherBudget());
			cstmt.setString(8, travel.getPayType());
			cstmt.setDouble(9, travel.getRentalRoom());
			cstmt.setString(10, stratDate);
			cstmt.setString(11, travel.getTitleName());
			cstmt.setDouble(12, travel.getTotalBudget());		
			cstmt.setString(13, travel.getTotalDate());			
			cstmt.setString(14, Date);
			cstmt.setString(15, travel.getTravelVehicle());			
			cstmt.setDouble(16, travel.getVehicleBudget());			
			cstmt.setString(17, travel.getWithName());	
			cstmt.setString(18, budgetId);
			System.out.println(cstmt);
			
			
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isEditRegistrationBudgetRequest(RegistrationBudgetRequest budgetRe , String regisDate , String beforeDate , String regisStartDate , String regisEndDate , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call updateRegistrationBudget_Procedure(?,?,?,?,?,?,?,?,?,?,?,?)}");
			cstmt.setString(1, budgetRe.getRegistrationID());
			cstmt.setString(2, beforeDate); 
			cstmt.setString(3, budgetRe.getBudgetText());			
			cstmt.setDouble(4, budgetRe.getCost());
			cstmt.setString(5, budgetRe.getLocation());					
			cstmt.setString(6, regisDate);
			cstmt.setString(7, regisEndDate);
			cstmt.setString(8, regisStartDate);
			cstmt.setDouble(9, budgetRe.getRequestBudget());			
			cstmt.setString(10, budgetRe.getTextTo());
			cstmt.setString(11, budgetRe.getTitleName());
			cstmt.setString(12, budgetId);
			System.out.println(cstmt);
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public int isEditTravelReport(TravelReport report , String travelReportDate , String budgetId) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement cstmt = conn.prepareCall("{call updateTravelReport_Procedure(?,?,?,?)}");
			cstmt.setString(1, report.getTravelReportID());
			cstmt.setString(2, travelReportDate);
			cstmt.setString(3, report.getTravelReportText());
			cstmt.setString(4, budgetId);
			System.out.println(cstmt);
			cstmt.execute();
			result = cstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}

}
