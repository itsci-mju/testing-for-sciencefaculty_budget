package com.springmvc.controller;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;


import conn.ConnectionDB;

public class CommentManager {
	
	public int isCommentTravel(CommentTravel comment, String tid , String cDate , String pid) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call addCommentTravel_Procudure(?,?,?,?,?)}");
			ccstmt.setString(1, comment.getCommentId());
			ccstmt.setString(2, cDate);
			ccstmt.setString(3, comment.getCommentTravelText());
			ccstmt.setString(4, pid);
			ccstmt.setString(5, tid);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isUpdateTravel(CommentTravel comment, String tid , String cDate , String pid) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call UpdateCommentTravel_Procudure(?,?,?,?,?)}");
			ccstmt.setString(1, comment.getCommentId());
			ccstmt.setString(2, cDate);
			ccstmt.setString(3, comment.getCommentTravelText());
			ccstmt.setString(4, pid);
			ccstmt.setString(5, tid);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public CommentTravel getCommentTravelByID(String tid)throws SQLException{
		CommentTravel cTravel = new CommentTravel();
		Personnel personnel = new Personnel();
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentTravelDate , commentTravelText , Personnel_personnelID , TravelRequest_travelID , title , firstname , lastname from CommentTravel cmt left join personnel p on cmt.Personnel_personnelID = p.personnelID where TravelRequest_travelID = '" + tid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				cTravel.setCommentTravelDate(rs.getDate(1));
				cTravel.setCommentTravelText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				travel.setTravelID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				cTravel.setPersonnel(personnel);
				cTravel.setTravelRequest(travel);
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return cTravel;		
	}
	
	public List<CommentTravel> getListCommentTravelByID(String tid)throws SQLException{
		List<CommentTravel> list = new ArrayList<>();
		Personnel personnel = new Personnel();
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentTravelDate , commentTravelText , Personnel_personnelID , TravelRequest_travelID , title , firstname , lastname from CommentTravel cmt left join personnel p on cmt.Personnel_personnelID = p.personnelID where TravelRequest_travelID = '" + tid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				CommentTravel cTravel = new CommentTravel();
				cTravel.setCommentTravelDate(rs.getDate(1));
				cTravel.setCommentTravelText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				travel.setTravelID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				cTravel.setPersonnel(personnel);
				cTravel.setTravelRequest(travel);
				
				list.add(cTravel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	public int isCommentRegistration(CommentRegistrationBudget cReg, String rid , String cDate , String pid) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call addCommentReg_Procudure(?,?,?,?,?)}");
			ccstmt.setString(1, cReg.getCommentId());
			ccstmt.setString(2, cDate);
			ccstmt.setString(3, cReg.getCommentRegisText());
			ccstmt.setString(4, pid);
			ccstmt.setString(5, rid);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isUpdateRegis(CommentRegistrationBudget comment, String tid , String cDate , String pid) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call updateCommentRegis_Procudure(?,?,?,?,?)}");
			ccstmt.setString(1, comment.getCommentId());
			ccstmt.setString(2, cDate);
			ccstmt.setString(3, comment.getCommentRegisText());
			ccstmt.setString(4, pid);
			ccstmt.setString(5, tid);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	public CommentRegistrationBudget getCommentRegByID(String rid)throws SQLException{
		CommentRegistrationBudget cReg = new CommentRegistrationBudget();
		Personnel personnel = new Personnel();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select cmr.commentRegisDate , cmr.commentRegisText , cmr.Personnel_personnelID , cmr.RegistrationBudgetRequest_registrationID , p.title , p.firstname , p.lastname from CommentRegistrationBudget cmr left join personnel p on cmr.Personnel_personnelID = p.personnelID where cmr.RegistrationBudgetRequest_registrationID = '"+rid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				cReg.setCommentRegisDate(rs.getDate(1));
				cReg.setCommentRegisText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				reg.setRegistrationID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				
				cReg.setPersonnel(personnel);
				cReg.setRegistrationBudgetRequest(reg);
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return cReg;		
	}
	
	public List<CommentRegistrationBudget> getListCommentRegByID(String rid)throws SQLException{
		List<CommentRegistrationBudget> list = new ArrayList<>();
		Personnel personnel = new Personnel();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select cmr.commentRegisDate , cmr.commentRegisText , cmr.Personnel_personnelID , cmr.RegistrationBudgetRequest_registrationID , p.title , p.firstname , p.lastname from CommentRegistrationBudget cmr left join personnel p on cmr.Personnel_personnelID = p.personnelID where cmr.RegistrationBudgetRequest_registrationID = '"+rid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {		
				CommentRegistrationBudget cReg = new CommentRegistrationBudget();
				cReg.setCommentRegisDate(rs.getDate(1));
				cReg.setCommentRegisText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				reg.setRegistrationID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				
				cReg.setPersonnel(personnel);
				cReg.setRegistrationBudgetRequest(reg);
				
				list.add(cReg);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}

}
