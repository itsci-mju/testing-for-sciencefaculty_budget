package com.springmvc.controller;


import com.springmvc.controller.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import com.springmvc.controller.*;
import conn.ConnectionDB;

public class PersonnelManager {
	
	public Personnel isVerifyLogin(String personnelID) throws SQLException{
		Personnel per = null;
		
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
	
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , title , firstname , lastname , budget , salary , personnelType , position , Department_departmentID from Personnel "
					+ "where personnelID = " + personnelID;	
			
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				Department dp = new Department();
				per = new Personnel(rs.getString(1) , rs.getString(2) , rs.getString(3) , rs.getString(4) , rs.getDouble(5) , rs.getDouble(6) , rs.getInt(7) , rs.getString(8));				
				dp.setDepartmentID(rs.getInt(9));
				per.setDepartment(dp);
				
				System.out.println("1 :"+ rs.getString(1));
				System.out.println("2 :"+rs.getString(2));
				System.out.println("3 :"+rs.getString(3));
				System.out.println("4 :"+rs.getString(4));
				System.out.println("5 :"+rs.getDouble(5));
				System.out.println("6 :"+rs.getDouble(6));
				System.out.println("7 :"+rs.getInt(7));
				System.out.println("8 :"+rs.getString(8));
				System.out.println("9 :"+rs.getInt(9));
				
				
				
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		conn.close();
		return per;
	
	}
	
	
//	public Personnel isRemainingBudget(String budgetReqtestID) throws SQLException{
//		Personnel per = null;
//		Department dp = null;
//		ConnectionDB condb = new ConnectionDB();
//		Connection conn = condb.getConnection();
//	
//		try {
//			Statement stmt = conn.createStatement();
//			String sql = "Select p.personnelID , p.title , p.firstname , p.lastname , p.budget , p.salary , p.personnelType "
//					+ ", p.position , d.departmentID , d.departmentName from Department d inner join Personnel p on d.departmentID = p.Department_departmentID "
//					+ "where personnelID = " + budgetReqtestID;		
//			
//			ResultSet rs = stmt.executeQuery(sql);
//			if(rs.next()) {
//				per = new Personnel(rs.getString(1) , rs.getString(2) , rs.getString(3) , rs.getString(4) , rs.getDouble(5) , rs.getDouble(6) , rs.getInt(7) , rs.getString(8));
//				dp = new Department(rs.getInt(9), rs.getString(10));
//				per.setDepartment(dp);
//			}
//		}catch(SQLException e) {
//			e.printStackTrace();
//		}
//		
//		conn.close();
//		return per;
//	
//	}
	
	public Personnel isRemainingBudget(String perid)throws SQLException{
		Personnel per = new Personnel();
		Department dp = new Department();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select p.personnelID , p.title , p.firstname , p.lastname , p.budget , p.salary , p.personnelType , p.position , d.departmentID , d.departmentName , p.personnelTypeName , d.tel from Department d inner join Personnel p on d.departmentID = p.Department_departmentID where p.personnelID = '"+perid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				per.setPersonnelID(rs.getString(1));
				per.setTitle(rs.getString(2));
				per.setFirstname(rs.getString(3));
				per.setLastname(rs.getString(4));
				per.setBudget(rs.getDouble(5));
				per.setSalary(rs.getDouble(6));
				per.setPersonnelType(rs.getInt(7));
				per.setPosition(rs.getString(8));
				dp.setDepartmentID(rs.getInt(9));
				dp.setDepartmentName(rs.getString(10));
				per.setPersonnelTypeName(rs.getString(11));
				dp.setTel(rs.getString(12));
				per.setDepartment(dp);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return per;		
	}
	
	
	
	
	public List<BudgetYear> isBudgetYear()throws SQLException{
		List<BudgetYear> byyear = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelType , year , budgetBath from BudgetYear";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {
				BudgetYear by = new BudgetYear();
				BudgetYearId byid = new BudgetYearId();
				
				byid.setPersonnelType(rs.getString(1));
				byid.setYear(rs.getString(2));
				by.setBudgetBath(rs.getDouble(3));
				by.setBudgetyeatid(byid);
	
								
				byyear.add(by);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return byyear;		
	} 
	
	
	

}
