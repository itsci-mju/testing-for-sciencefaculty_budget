package com.springmvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="TravelRequest")
public class TravelRequest {
	
	@Id
	@Column(name="travelID" , length = 20)
	private String travelID;
		
	@Column(name="travelDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date travelDate;
	
	@Column(name="level" , nullable=false , length = 45)
	private String level;

	@Column(name="grade" , nullable=false , length = 45)
	private String grade;
	
	@Column(name="location" , nullable=false , length = 100)
	private String location;
	
	@Column(name="withName" , nullable=false , length = 45)
	private String withName;
	
	@Column(name="totalDate" , nullable=false , length = 45)
	private String totalDate;
	
	@Column(name="startDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name="endDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name="titleName" , nullable=false , length = 100)
	private String titleName;
	
	@Column(name="travelVehicle" , nullable=false , length = 45)
	private String travelVehicle;
	
	@Column(name="allowance" , nullable=false)
	private double allowance;
	
	@Column(name="vehicleBudget" , nullable=false)
	private double vehicleBudget;
	
	@Column(name="rentalRoom" , nullable=false)
	private double rentalRoom;
	
	@Column(name="otherBudget" , nullable=false)
	private double otherBudget;
	
	@Column(name="totalBudget" , nullable=false)
	private double totalBudget;
	
	@Column(name="payType", nullable=false , length = 45)
	private String payType;
	
	@Column(name="realBudget" , nullable=false)
	private double realBudget;
	
	@Column(name="fileName" , nullable=false , length = 50)
	private String fileName;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "BudgetRequest_budgetRequestID" , nullable=false)
	private BudgetRequest budgetRequest;
	

	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "travelRequest")
	private List<CommentTravel> commentTravel = new ArrayList<>();


	public TravelRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public TravelRequest(String fileName) {
		super();
		this.fileName = fileName;
	}



	public TravelRequest(String travelID, Date travelDate, String level, String grade, String location, String withName,
			String totalDate, Date startDate, Date endDate, String titleName, String travelVehicle, double allowance,
			double vehicleBudget, double rentalRoom, double otherBudget, double totalBudget, String payType , double realBudget) {
		super();
		this.travelID = travelID;
		this.travelDate = travelDate;
		this.level = level;
		this.grade = grade;
		this.location = location;
		this.withName = withName;
		this.totalDate = totalDate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.titleName = titleName;
		this.travelVehicle = travelVehicle;
		this.allowance = allowance;
		this.vehicleBudget = vehicleBudget;
		this.rentalRoom = rentalRoom;
		this.otherBudget = otherBudget;
		this.totalBudget = totalBudget;
		this.payType = payType;
		this.realBudget = realBudget;
	}


	public TravelRequest(String travelID, Date travelDate, String level, String grade, String location, String withName,
			String totalDate, Date startDate, Date endDate, String titleName, String travelVehicle, double allowance,
			double vehicleBudget, double rentalRoom, double otherBudget, double totalBudget, String payType) {
		super();
		this.travelID = travelID;
		this.travelDate = travelDate;
		this.level = level;
		this.grade = grade;
		this.location = location;
		this.withName = withName;
		this.totalDate = totalDate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.titleName = titleName;
		this.travelVehicle = travelVehicle;
		this.allowance = allowance;
		this.vehicleBudget = vehicleBudget;
		this.rentalRoom = rentalRoom;
		this.otherBudget = otherBudget;
		this.totalBudget = totalBudget;
		this.payType = payType;
	}



	public String getTravelID() {
		return travelID;
	}



	public Date getTravelDate() {
		return travelDate;
	}



	public String getLevel() {
		return level;
	}



	public String getGrade() {
		return grade;
	}



	public String getLocation() {
		return location;
	}



	public String getWithName() {
		return withName;
	}



	public String getTotalDate() {
		return totalDate;
	}



	public Date getStartDate() {
		return startDate;
	}



	public Date getEndDate() {
		return endDate;
	}



	public String getTitleName() {
		return titleName;
	}



	public String getTravelVehicle() {
		return travelVehicle;
	}



	public double getAllowance() {
		return allowance;
	}



	public double getVehicleBudget() {
		return vehicleBudget;
	}



	public double getRentalRoom() {
		return rentalRoom;
	}



	public double getOtherBudget() {
		return otherBudget;
	}



	public double getTotalBudget() {
		return totalBudget;
	}



	public String getPayType() {
		return payType;
	}



	public BudgetRequest getBudgetRequest() {
		return budgetRequest;
	}



	public void setTravelID(String travelID) {
		this.travelID = travelID;
	}



	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}



	public void setLevel(String level) {
		this.level = level;
	}



	public void setGrade(String grade) {
		this.grade = grade;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public void setWithName(String withName) {
		this.withName = withName;
	}



	public void setTotalDate(String totalDate) {
		this.totalDate = totalDate;
	}



	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}



	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}



	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}



	public void setTravelVehicle(String travelVehicle) {
		this.travelVehicle = travelVehicle;
	}



	public void setAllowance(double allowance) {
		this.allowance = allowance;
	}



	public void setVehicleBudget(double vehicleBudget) {
		this.vehicleBudget = vehicleBudget;
	}



	public void setRentalRoom(double rentalRoom) {
		this.rentalRoom = rentalRoom;
	}



	public void setOtherBudget(double otherBudget) {
		this.otherBudget = otherBudget;
	}



	public void setTotalBudget(double totalBudget) {
		this.totalBudget = totalBudget;
	}



	public void setPayType(String payType) {
		this.payType = payType;
	}



	public void setBudgetRequest(BudgetRequest budgetRequest) {
		this.budgetRequest = budgetRequest;
	}

	public double getRealBudget() {
		return realBudget;
	}

	public void setRealBudget(double realBudget) {
		this.realBudget = realBudget;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public List<CommentTravel> getCommentTravel() {
		return commentTravel;
	}



	public void setCommentTravel(List<CommentTravel> commentTravel) {
		this.commentTravel = commentTravel;
	}
	
	
	
	
	

	
	

}
