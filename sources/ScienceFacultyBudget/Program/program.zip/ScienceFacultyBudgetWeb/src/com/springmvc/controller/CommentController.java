package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.CommentRegistrationBudget;
import com.springmvc.model.CommentTravel;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;
import com.springmvc.model.TravelRequest;

@Controller
public class CommentController {
	
//	@RequestMapping(value="/doAddCommentTravel", method = RequestMethod.POST)
//	public ModelAndView doAddCommentTravel(HttpServletRequest request, Model md, HttpSession session) {	
//		int result = 0;		
//		String msg = "";
//		ViewController vc = new ViewController();
//		ModelAndView mav = new ModelAndView();
//		try {
//			request.setCharacterEncoding("UTF-8");
//		}catch(UnsupportedEncodingException e1) {
//			e1.printStackTrace();
//		}
//		
//		try {
//			Personnel p = (Personnel) session.getAttribute("personnel_detail");
//			String pid = p.getPersonnelID();
//			CommentManager cmg = new CommentManager();
//		
//			String tid = request.getParameter("tid");
//			String cdate = request.getParameter("cdate");
//			String commentText = request.getParameter("commentText");
//			String commentTextUpdate = request.getParameter("commentTextUpdate");
//			
//			String commentid = tid;
//			
//			String year[] = cdate.split("-" );
//			int cal = Integer.parseInt(year[0]) - 543;
//			String dateYear = cal + "-" + year[1] + "-" + year[2];
//			
//			
//			Date date =  new Date();
//			try {
//				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//				date = dateFormat.parse(dateYear);
//			} catch (ParseException e) {
//				e.printStackTrace();
//			}
//			
//			System.out.println("commentText : " + commentText);
//			System.out.println("commentTravelUpDate : " + commentTextUpdate);
////			if(commentText != null) {
////				CommentTravel comment = new CommentTravel(date , commentText);
////				result = cmg.isCommentTravel(comment, tid, cdate , pid);
////			}else if(commentTravelUpDate != null) {
////				CommentTravel commentupdate = new CommentTravel(date , commentTravelUpDate);
////				result = cmg.isUpdateTravel(commentupdate, tid, cdate , pid);
////			}
//			
//			
//			//ใส่ id comment
//			if(commentText != null) {
//				CommentTravel comment = new CommentTravel(commentid ,date , commentText);
//				result = cmg.isCommentTravel(comment, tid, dateYear , pid);
//			}
//			
//			if(commentTextUpdate != null) {
//				CommentTravel commentupdate = new CommentTravel(commentid , date , commentTextUpdate);
//				result = cmg.isUpdateTravel(commentupdate, tid, dateYear , pid);
//			}
//			
//			
//			
//			System.out.println(result);
//			if(result == 1) {
//				mav = new ModelAndView("ViewTravelRequest");
//				msg = "บันทึกสำเร็จ";
//				System.out.println(msg);
//			}else{
//				mav = vc.ViewTravelRequest(request, md, session, tid);
//				msg = "บันทึกไม่สำเร็จ";
//				System.out.println(msg);
//			}
//			
//			mav.addObject("msg", msg);
//			
//			//view
//			ViewManager vmg = new ViewManager();
//			
//			try {
//				List<TravelRequest> travel = vmg.getViewTravelRequest();
//				List<String> sDate = new ArrayList<>();
//				List<String> eDate = new ArrayList<>();
//				List<String> rDate = new ArrayList<>();
//
//				String DATE_FORMAT = "dd MMMM yyyy";
//				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				
//				for(TravelRequest t : travel) {								
//					sDate.add(sdf.format(t.getStartDate()));
//					eDate.add(edf.format(t.getEndDate()));
//					rDate.add(rdf.format(t.getTravelDate()));
//				}
//				
//				mav.addObject("viewtravelrequest", travel);
//				mav.addObject("sDate", sDate);
//				mav.addObject("eDate", eDate);
//				mav.addObject("rDate", rDate);
//				
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//			
//			
//			
//			
//			
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		
//		
//		return mav;
//	}
//	
//	
//	@RequestMapping(value="/doAddCommentRegistration", method = RequestMethod.POST)
//	public ModelAndView doAddCommentRegistration(HttpServletRequest request, Model md, HttpSession session) {	
//		int result = 0;		
//		String msg = "";
//		ModelAndView mav = new ModelAndView();
//		ViewController vc = new ViewController();
//		
//		try {
//			request.setCharacterEncoding("UTF-8");
//		}catch(UnsupportedEncodingException e1) {
//			e1.printStackTrace();
//		}
//		
//		try {
//			Personnel p = (Personnel) session.getAttribute("personnel_detail");
//			String pid = p.getPersonnelID();
//			CommentManager cmg = new CommentManager();
//		
//			String rid = request.getParameter("rid");
//			String cdate = request.getParameter("cdate");
//			String commentText = request.getParameter("commentText");
//			String commentTextUpdate = request.getParameter("commentTextUpdate");
//			
//			String year[] = cdate.split("-" );
//			int cal = Integer.parseInt(year[0]) - 543;
//			String dateYear = cal + "-" + year[1] + "-" + year[2];
//			
//			String commentid = rid;
//			
//			Date date =  new Date();
//			try {
//				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//				date = dateFormat.parse(dateYear);
//			} catch (ParseException e) {
//				e.printStackTrace();
//			}
//			
//			
//			//ใส่ id comment
//			if(commentText != null) {
//				CommentRegistrationBudget comment = new CommentRegistrationBudget(commentid ,date , commentText);
//				result = cmg.isCommentRegistration(comment, rid, cdate , pid);
//			}
//			
//			if(commentTextUpdate != null) {
//				CommentRegistrationBudget commentupdate = new CommentRegistrationBudget(commentid , date , commentTextUpdate);
//				result = cmg.isUpdateRegis(commentupdate, rid, dateYear , pid);
//			}
//
//			
//			System.out.println(result);
//			if(result == 1) {
//				mav = new ModelAndView("ViewRegistrationBudgetRequest");				
//				msg = "บันทึกสำเร็จ";
//				mav.addObject("msg", msg);
//				System.out.println(msg);
//			}else{
//				mav = vc.ViewTravelRequest(request, md, session, rid);
//				msg = "บันทึกไม่สำเร็จ";
//				System.out.println(msg);
//				mav.addObject("msg", msg);
//			}
//			
//			
//			
//			
//			//view
//			ViewManager vmg = new ViewManager();
//			
//			try {
//				List<RegistrationBudgetRequest> reg = vmg.getViewRegistrationBudgetRequest();
//				List<String> sDate = new ArrayList<>();
//				List<String> eDate = new ArrayList<>();
//				List<String> rDate = new ArrayList<>();
//				String DATE_FORMAT = "dd MMMM yyyy";
//				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
//				
//				for(RegistrationBudgetRequest r : reg) {								
//					sDate.add(sdf.format(r.getRegisStartDate()));
//					eDate.add(edf.format(r.getRegisEndDate()));
//					rDate.add(rdf.format(r.getRegisDate()));
//				}
//				
//				mav.addObject("viewregistration", reg);
//				mav.addObject("sDate", sDate);
//				mav.addObject("eDate", eDate);
//				mav.addObject("rDate", rDate);
//				
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//					
//			
//			mav.addObject("msg", msg);
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		
//		
//		return mav;
//	}
	
	@RequestMapping(value="/doAddCommentTravel", method = RequestMethod.POST)
	public ModelAndView doAddCommentTravelTest(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		int result = 0;		
		String msg = "";
		ViewController vc = new ViewController();
		try {
			request.setCharacterEncoding("UTF-8");
		}catch(UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
		Personnel p = (Personnel) session.getAttribute("personnel_detail");
		String pid = p.getPersonnelID();
		CommentManager cmg = new CommentManager();
	
		String tid = request.getParameter("tid");
		String size = request.getParameter("size");
		String commentid = size + "_" + tid;
		String cdate = request.getParameter("cdate");
		String commentText = request.getParameter("commentText");
		String year[] = cdate.split("-" );
		int cal = Integer.parseInt(year[0]) - 543;
		String dateYear = cal + "-" + year[1] + "-" + year[2];
		
		
		Date date =  new Date();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			date = dateFormat.parse(dateYear);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		CommentTravel comment = new CommentTravel(commentid ,date , commentText);
		result = cmg.isCommentTravel(comment, tid, dateYear , pid);
		
		
		if(result == 1) {
			mav = new ModelAndView("ViewTravelRequest");
			msg = "บันทึกสำเร็จ";
			System.out.println(msg);
		}else{
			mav = vc.ViewTravelRequest(request, md, session, tid);
			msg = "บันทึกไม่สำเร็จ";
			System.out.println(msg);
		}
		
		mav.addObject("msg", msg);
		
		//view
		ViewManager vmg = new ViewManager();
		
		try {
			List<TravelRequest> travel = vmg.getViewTravelRequest();
			List<String> sDate = new ArrayList<>();
			List<String> eDate = new ArrayList<>();
			List<String> rDate = new ArrayList<>();

			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			for(TravelRequest t : travel) {								
				sDate.add(sdf.format(t.getStartDate()));
				eDate.add(edf.format(t.getEndDate()));
				rDate.add(rdf.format(t.getTravelDate()));
			}
			
			mav.addObject("viewtravelrequest", travel);
			mav.addObject("sDate", sDate);
			mav.addObject("eDate", eDate);
			mav.addObject("rDate", rDate);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return mav;
	}
	
	@RequestMapping(value="/doAddCommentRegistration", method = RequestMethod.POST)
	public ModelAndView doAddCommentRegistrationTest(HttpServletRequest request, Model md, HttpSession session) {
		int result = 0;		
		String msg = "";
		ModelAndView mav = new ModelAndView();
		ViewController vc = new ViewController();
		
		try {
			request.setCharacterEncoding("UTF-8");
		}catch(UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		try {
			Personnel p = (Personnel) session.getAttribute("personnel_detail");
			String pid = p.getPersonnelID();
			CommentManager cmg = new CommentManager();
			
			String rid = request.getParameter("rid");
			String cdate = request.getParameter("cdate");
			String commentText = request.getParameter("commentText");
			String size = request.getParameter("size");
			String year[] = cdate.split("-" );
			int cal = Integer.parseInt(year[0]) - 543;
			String dateYear = cal + "-" + year[1] + "-" + year[2];
			
			String commentid = size + "_" + rid;
			
			Date date =  new Date();
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				date = dateFormat.parse(dateYear);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			CommentRegistrationBudget comment = new CommentRegistrationBudget(commentid ,date , commentText);
			result = cmg.isCommentRegistration(comment, rid, cdate , pid);
			
			if(result == 1) {
				mav = new ModelAndView("ViewRegistrationBudgetRequest");				
				msg = "บันทึกสำเร็จ";
				mav.addObject("msg", msg);
				System.out.println(msg);
			}else{
				mav = vc.ViewTravelRequest(request, md, session, rid);
				msg = "บันทึกไม่สำเร็จ";
				System.out.println(msg);
				mav.addObject("msg", msg);
			}
			
			
			
			
			//view
			ViewManager vmg = new ViewManager();
			
			try {
				List<RegistrationBudgetRequest> reg = vmg.getViewRegistrationBudgetRequest();
				List<String> sDate = new ArrayList<>();
				List<String> eDate = new ArrayList<>();
				List<String> rDate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat edf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat rdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				
				for(RegistrationBudgetRequest r : reg) {								
					sDate.add(sdf.format(r.getRegisStartDate()));
					eDate.add(edf.format(r.getRegisEndDate()));
					rDate.add(rdf.format(r.getRegisDate()));
				}
				
				mav.addObject("viewregistration", reg);
				mav.addObject("sDate", sDate);
				mav.addObject("eDate", eDate);
				mav.addObject("rDate", rDate);
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
					
			
			mav.addObject("msg", msg);
		
		}catch(Exception e) {
			e.printStackTrace();
		}
			
		return mav;
	}

}
