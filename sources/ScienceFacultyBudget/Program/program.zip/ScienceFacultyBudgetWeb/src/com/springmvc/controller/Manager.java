package com.springmvc.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class Manager {
	
	public List<Personnel> isRemainingBudget()throws SQLException{
		List<Personnel> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			String sql = "Select * from view_remainingbudget";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				Personnel personnel = new Personnel(rs.getString(1) , rs.getString(2) , rs.getString(3) , rs.getString(4) , rs.getDouble(5) , rs.getDouble(6) , rs.getInt(7) , rs.getString(8));
				personnel.getDepartment().setDepartmentID(rs.getInt(9));
				personnel.getDepartment().setDepartmentName(rs.getString(10));
				
				list.add(personnel);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	
	
	
	
	
	
	
	
	

	
	
	
	


}
