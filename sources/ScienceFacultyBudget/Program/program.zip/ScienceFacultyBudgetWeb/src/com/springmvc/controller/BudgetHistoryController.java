package com.springmvc.controller;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;

@Controller
public class BudgetHistoryController {
	
	@RequestMapping(value = "/loadRemainingBudgetHistroyPage", method = RequestMethod.GET)
	public ModelAndView loadRemainingBudgetHistroyPage(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		
		BudgetHistoryManager bhg = new BudgetHistoryManager();
		Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
		String perid = request.getParameter("perid");
		TravelRequest travel = new TravelRequest();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();		
		
		try {
			
			List<BudgetRequest> br = bhg.getBudgetHistory(perid);
			
			if(br.size() != 0) {
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				String title = br.get(0).getPersonnel().getTitle();
				String firstname = br.get(0).getPersonnel().getFirstname();
				String lastname = br.get(0).getPersonnel().getLastname();
				
				String name = title + firstname + " " + lastname ;
				
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat ydf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				
				List<Double> totalTravel = new ArrayList<>(); 
				List<Double> totalRegis = new ArrayList<>();
				List<Double> total = new ArrayList<>();
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(ydf.format(b.getRequestDate()));
					
					System.out.println("B.." + b.getbudgetRequestID());
					 //travel
					travel = bhg.getTotalTravel(b.getbudgetRequestID());
					totalTravel.add(travel.getTotalBudget());
					System.out.println(travel.getTotalBudget());
					
					//reg
					reg = bhg.getTotalRegis(b.getbudgetRequestID());
					totalRegis.add(reg.getRequestBudget());
					System.out.println(reg.getRequestBudget());
					
					total.add(travel.getTotalBudget() + reg.getRequestBudget());
					System.out.println("Total : " + total);
					
				}
				
				
				mav = new ModelAndView("RemainingBudgetHistory");
			
				mav.addObject("perid", perid);
				mav.addObject("rdate", rdate);
				mav.addObject("ydate", ydate);
				mav.addObject("History", br);
				mav.addObject("name" , name);
				mav.addObject("totalTravel", totalTravel);
				mav.addObject("totalRegis", totalRegis);
				mav.addObject("total", total);
				
				return mav;
				
			}else {
				
				mav = new ModelAndView("ListRemainingBudget");
				ListRemainingBudgetManager lm = new ListRemainingBudgetManager();
				
				List<Personnel> p = lm.getListRemainingBudget();
				
				String pmsg = "ยังไม่ได้ดำเนินการทำเอกสาร";
				
				
				mav.addObject("list", p);
				mav.addObject("pmsg", pmsg);
				
				return mav;
			
			
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
		
	}
	
	
	@RequestMapping(value = "/searchRemainingBudgetHistroyYear", method = RequestMethod.POST)
	public ModelAndView searchRemainingBudgetHistroyYear(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("RemainingBudgetHistory");
		
		BudgetHistoryManager bhg = new BudgetHistoryManager();
		
		try {
						
		String inputyear = request.getParameter("inputyear");
		String perid = request.getParameter("perid");
		
		int number = Integer.parseInt(inputyear);
		number = number - 543;		
		String year = Integer.toString(number);
		System.out.println(year);
		
		List<BudgetRequest> br = bhg.getBudgetHistoryByYear(year , perid);
		
		TravelRequest travel = new TravelRequest();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();		
		
		System.out.println("br.size : "+br.size());
		if(br.size() == 0) {
			List<BudgetRequest> brr = bhg.getBudgetHistory(perid);
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			String title = brr.get(0).getPersonnel().getTitle();
			String firstname = brr.get(0).getPersonnel().getFirstname();
			String lastname = brr.get(0).getPersonnel().getLastname();
			
			String name = title + firstname + " " + lastname ;
			
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat ydf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			
			List<Double> totalTravel = new ArrayList<>(); 
			List<Double> totalRegis = new ArrayList<>();
			List<Double> total = new ArrayList<>();
			
			for(BudgetRequest b : brr) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(ydf.format(b.getRequestDate()));
				
				System.out.println("B.." + b.getbudgetRequestID());
				 //travel
				travel = bhg.getTotalTravel(b.getbudgetRequestID());
				totalTravel.add(travel.getTotalBudget());
				System.out.println(travel.getTotalBudget());
				
				//reg
				reg = bhg.getTotalRegis(b.getbudgetRequestID());
				totalRegis.add(reg.getRequestBudget());
				System.out.println(reg.getRequestBudget());
				
				total.add(travel.getTotalBudget() + reg.getRequestBudget());
				System.out.println("Total : " + total);
				
			}
			String smsg = "ค้นหาปีที่คุณต้องการไม่เจอ";
			
			
			mav = new ModelAndView("RemainingBudgetHistory");
		
			mav.addObject("perid", perid);
			mav.addObject("rdate", rdate);
			mav.addObject("ydate", ydate);
			mav.addObject("History", brr);
			mav.addObject("name" , name);
			mav.addObject("totalTravel", totalTravel);
			mav.addObject("totalRegis", totalRegis);
			mav.addObject("total", total);
			mav.addObject("smsg", smsg);
			
			return mav;
			
		}
		
		if(br.size() != 0) {
			
			List<String> rdate = new ArrayList<>();
			List<String> ydate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			String YEAR_FORMAT = "yyyy";
			String title = br.get(0).getPersonnel().getTitle();
			String firstname = br.get(0).getPersonnel().getFirstname();
			String lastname = br.get(0).getPersonnel().getLastname();
			
			String name = title + firstname + " " + lastname ;
			
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			SimpleDateFormat ydf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
			
			
			List<Double> totalTravel = new ArrayList<>(); 
			List<Double> totalRegis = new ArrayList<>();
			List<Double> total = new ArrayList<>();
			
			for(BudgetRequest b : br) {								
				rdate.add(sdf.format(b.getRequestDate()));
				ydate.add(ydf.format(b.getRequestDate()));
				
				System.out.println("B.." + b.getbudgetRequestID());
				 //travel
				travel = bhg.getTotalTravel(b.getbudgetRequestID());
				totalTravel.add(travel.getTotalBudget());
				System.out.println(travel.getTotalBudget());
				
				//reg
				reg = bhg.getTotalRegis(b.getbudgetRequestID());
				totalRegis.add(reg.getRequestBudget());
				System.out.println(reg.getRequestBudget());
				
				total.add(travel.getTotalBudget() + reg.getRequestBudget());
				System.out.println("Total : " + total);
				
			}
			
			
			mav = new ModelAndView("RemainingBudgetHistory");
		
			mav.addObject("perid", perid);
			mav.addObject("rdate", rdate);
			mav.addObject("ydate", ydate);
			mav.addObject("History", br);
			mav.addObject("name" , name);
			mav.addObject("totalTravel", totalTravel);
			mav.addObject("totalRegis", totalRegis);
			mav.addObject("total", total);
			
			return mav;
		}
		
		
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
		
	}
	
	

}
