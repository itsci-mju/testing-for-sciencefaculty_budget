package com.springmvc.controller;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class UploadManager { 	 
		
	/* upload */
	public int isUploadBudgetRequestDocument(String name , String id) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call upload_BudgetRequest(?,?)}");
			ccstmt.setString(1, name);
			ccstmt.setString(2, id);
			
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	
	public int isUploadRequestingPerDocument(String name , String doc_id) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call upload_reqestingPermission(?,?)}");
			ccstmt.setString(1, name);
			ccstmt.setString(2, doc_id);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isUploadTravelDocument(String name , String doc_id) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call upload_travelRequest(?,?)}");
			ccstmt.setString(1, name);
			ccstmt.setString(2, doc_id);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isUploadRegDocument(String name , String doc_id) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call upload_RegistrationBudget(?,?)}");
			ccstmt.setString(1, name);
			ccstmt.setString(2, doc_id);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	public int isUploadReportDocument(String name , String doc_id) throws SQLException{
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		int result = 0;
		try {
			
			CallableStatement ccstmt = conn.prepareCall("{call upload_travelReport(?,?)}");
			ccstmt.setString(1, name);
			ccstmt.setString(2, doc_id);
			
			ccstmt.execute();
			result = ccstmt.getUpdateCount();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		conn.close();
		return result;
	}
	
	
	//idDocument
	
	public BudgetRequest getBudgetRequestIDName(String bid)throws SQLException{	
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , requestName , fileName from BudgetRequest where budgetRequestID ='"+bid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				budget.setbudgetRequestID(rs.getString(1));
				budget.setRequestName(rs.getString(2));
				budget.setFileName(rs.getString(3));
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return budget;		
	}
	
	
	public RequestingPermission getRequestingID(String bid)throws SQLException{	
		RequestingPermission rq = new RequestingPermission();
		BudgetRequest budget = new BudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID , BudgetRequest_budgetRequestID , fileName from RequestingPermission where BudgetRequest_budgetRequestID ='"+bid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				rq.setRequestPerID(rs.getString(1));
				budget.setbudgetRequestID(rs.getString(2));
				rq.setFileName(rs.getString(3));
				rq.setBudgetRequest(budget);
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return rq;		
	}
	
	public TravelRequest getTravelRequestID(String tid)throws SQLException{	
		TravelRequest t = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelID , fileName from TravelRequest where BudgetRequest_budgetRequestID ='"+tid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				t.setTravelID(rs.getString(1));
				t.setFileName(rs.getString(2));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return t;		
	}
	
	public RegistrationBudgetRequest getRegistrationID(String regid)throws SQLException{	
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID , fileName from RegistrationBudgetRequest where BudgetRequest_budgetRequestID ='"+regid+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				reg.setRegistrationID(rs.getString(1));
				reg.setFileName(rs.getString(2));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return reg;		
	}
	
	public TravelReport getTravelReportID(String reportTd)throws SQLException{	
		TravelReport report = new TravelReport();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select travelReportID , fileName from TravelReport where BudgetRequest_budgetRequestID ='"+reportTd+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				report.setTravelReportID(rs.getString(1));
				report.setFileName(rs.getString(2));
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return report;		
	}
	
	
	
	

	
}


