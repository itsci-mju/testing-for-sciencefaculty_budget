package com.springmvc.controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;

@Controller
public class ListRequestPersonnelController {
	
	@RequestMapping(value="/loadListRequestPersonnelPage", method = RequestMethod.GET)
	public ModelAndView loadListRequestPersonnelPage(HttpServletRequest request, Model md, HttpSession session) {		
		ModelAndView mav = new ModelAndView("ListRequestPersonnel");
		ListRequestPersonnelManager lrpm = new ListRequestPersonnelManager();
		
		try {
			List<TravelRequest> list = lrpm.getListRequestPersonnelTest();
			List<String> date = new ArrayList<>();
			List<String> count = new ArrayList<>();
			String DATE_FORMAT = "yyyy";
						
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			
			for(TravelRequest t : list) {								
				date.add(sdf.format(t.getStartDate()));	
				count.add(t.getBudgetRequest().getbudgetRequestID());
				
			}			
			mav.addObject("list", list);
			mav.addObject("date", date);
			mav.addObject("count", count);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return mav;
	}
	
	
	@RequestMapping(value="/loadRequestPersonnel", method = RequestMethod.GET)
	public ModelAndView loadRequrstPersonnel(HttpServletRequest request, Model md, HttpSession session) {		
		ModelAndView mav = new ModelAndView("RequestPersonnel");
		ListRequestPersonnelManager lrpm = new ListRequestPersonnelManager();
			
		try {
			String location = request.getParameter("location");
			String date = request.getParameter("sdate");
			int number = Integer.parseInt(date);
			number = number - 543;		
			String year = Integer.toString(number);
			
			System.out.println(date);
			System.out.println(year);
			
			List<TravelRequest> lo = lrpm.getRequestPersonnel(location , year);	
			List<String> sdate = new ArrayList<>();
			List<String> edate = new ArrayList<>();
			String DATE_FORMAT = "dd MMMM yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
			
			for(TravelRequest t : lo) {								
				sdate.add(sdf.format(t.getStartDate()));
				edate.add(sdf.format(t.getEndDate()));								
			}
			
			
			mav.addObject("sdate", sdate);
			mav.addObject("edate", edate);
			mav.addObject("lo", lo);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		return mav;
	}

}
