package com.springmvc.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class ReportManager {
	
	public List<BudgetRequest> getBudgetRequest(String username)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select budgetRequestID , chooseRequest , requestDate , requestName from budgetrequest where Personnel_personnelID =  '" + username + "' order by budgetRequestID";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				
				
				list.add(budget);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	} 
	
	public BudgetRequest getBudgetRequestDocumentID(String bid)throws SQLException{
		BudgetRequest budget = new BudgetRequest();
		Personnel personnel = new Personnel();
		Department d = new Department();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.title ,  p.firstname , p.lastname , p.position , d.departmentName from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where budgetRequestID =  '" + bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				personnel.setPosition(rs.getString(8));
				d.setDepartmentName(rs.getString(9));
				personnel.setDepartment(d);
				budget.setPersonnel(personnel);
				
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return budget;		
	} 
	
	public RequestingPermission getRequestingPermissionDocumentID(String budgetId)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		RequestingPermission permission = new RequestingPermission();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID , requestPerName , requestingPerDate , requestingPerText , BudgetRequest_budgetRequestID from requestingpermission where BudgetRequest_budgetRequestID = '"+ budgetId +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				
				list.add(permission);

			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return permission;		
	} 
	
	
	//id rp travel reg report
	
	public RequestingPermission getrpIDFormBudgetRequestId(String bid) {
		RequestingPermission rp = new RequestingPermission();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID from RequestingPermission where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				rp.setRequestPerID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return rp;
	}
	
	public TravelRequest getTravelIDFormBudgetRequestId(String bid) {
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select travelID from TravelRequest where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				travel.setTravelID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return travel;
	}
	
	public RegistrationBudgetRequest getRegIDFormBudgetRequestId(String bid) {
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID from RegistrationBudgetRequest where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				reg.setRegistrationID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return reg;
	}
	
	public TravelReport getReortIDFormBudgetRequestId(String bid) {
		TravelReport report = new TravelReport();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql = "Select travelReportID from TravelReport where BudgetRequest_budgetRequestID =  '"+ bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				report.setTravelReportID(rs.getString(1));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return report;
	}
	
	
	
	
	

	
	

}
