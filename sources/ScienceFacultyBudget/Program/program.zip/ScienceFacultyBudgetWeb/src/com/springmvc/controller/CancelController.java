package com.springmvc.controller;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.*;


@Controller
public class CancelController {
	
	@RequestMapping(value="/CancelDocument", method = RequestMethod.GET)
	public ModelAndView CancelDocument(HttpServletRequest request, Model md, HttpSession session) {
		ModelAndView mav = new ModelAndView("ListDocument");
		String bid = request.getParameter("bid");
		CancelManager cm = new CancelManager();
		
		try {
			int i = 0;
			String status = "ยกเลิกการทำเอกสารแล้ว";
			
			
			i = cm.isCancleBudgetRequest(status , bid);
			
			
			if(i == 1){
				String mm = "ยกเลิกสำเร็จ";
				
				mav.addObject("mm", mm);
			}else{
				String mm = "ยกเลิกไม่สำเร็จ";
				
				mav.addObject("mm", mm);
			}
			
			
			ListManager lm = new ListManager();
			Personnel personnel = (Personnel) session.getAttribute("personnel_detail");
			
			try {
				List<BudgetRequest> br = lm.getBudgetRequest(personnel.getPersonnelID());
							
				List<String> rdate = new ArrayList<>();
				List<String> ydate = new ArrayList<>();
				String DATE_FORMAT = "dd MMMM yyyy";
				String YEAR_FORMAT = "yyyy";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH"));
				SimpleDateFormat syf = new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
				
				for(BudgetRequest b : br) {								
					rdate.add(sdf.format(b.getRequestDate()));
					ydate.add(syf.format(b.getRequestDate()));
					System.out.println("BB : " + b.getStatus());
				}

				if(br.size() != 0) {							
					session.setAttribute("budgetRequest", br);				
					mav.addObject("budgetRequest", br);
					mav.addObject("rDate", rdate);
					mav.addObject("yDate", ydate);
				}
				
				mav.addObject("budgetRequest", br);
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
				
		return mav;
	}

}
