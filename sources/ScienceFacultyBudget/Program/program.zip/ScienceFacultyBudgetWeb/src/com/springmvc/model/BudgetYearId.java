package com.springmvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BudgetYearId implements Serializable{
	
	@Column(name="personnelType" , nullable=false , length = 50)
	private String personnelType;
	
	
	@Column(name="year" , nullable=false , length = 4)
	private String year;


	public BudgetYearId() {
		super();
		// TODO Auto-generated constructor stub
	}


	public BudgetYearId(String personnelType, String year) {
		super();
		this.personnelType = personnelType;
		this.year = year;
	}


	public String getPersonnelType() {
		return personnelType;
	}


	public void setPersonnelType(String personnelType) {
		this.personnelType = personnelType;
	}


	public String getYear() {
		return year;
	}


	public void setYear(String year) {
		this.year = year;
	}
	
	
	
	
	
	

}
