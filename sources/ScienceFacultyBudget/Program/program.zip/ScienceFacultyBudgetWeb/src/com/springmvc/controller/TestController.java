package com.springmvc.controller;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetRequest;
import com.springmvc.model.BudgetYear;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;
import com.springmvc.model.TravelReport;
import com.springmvc.model.TravelRequest;

@Controller
public class TestController {

	/*
	 * @RequestMapping(value = "/doAddTravelReport", method = RequestMethod.POST)
	 * public ModelAndView do_addTravelReport(HttpServletRequest request, Model md,
	 * HttpSession session) { int result = 0; String msg = ""; String bid = (String)
	 * session.getAttribute("bid"); ModelAndView mav = new ModelAndView();
	 * CreateManager manager = new CreateManager();
	 * 
	 * String travelReportDate = request.getParameter("travelReportDate");
	 * 
	 * try { request.setCharacterEncoding("UTF-8"); } catch
	 * (UnsupportedEncodingException e1) { e1.printStackTrace(); }
	 * 
	 * try {
	 * 
	 * TravelRequest travel = new TravelRequest(); RegistrationBudgetRequest reg =
	 * new RegistrationBudgetRequest();
	 * 
	 * //ผลรวมการเดินทาง travel = manager.getTotalTravel(bid); double traveltotal =
	 * travel.getTotalBudget();
	 * 
	 * //ผลรวมค่าลงทะเบียน reg = manager.getTotalRegis(bid); double requestBudget =
	 * reg.getRequestBudget();
	 * 
	 * double sum = 0; sum = traveltotal + requestBudget;
	 * 
	 * String year = ""; try { SimpleDateFormat dateFormat = new
	 * SimpleDateFormat("yyyy"); year =
	 * dateFormat.format(dateFormat.parse(travelReportDate).getTime());
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * Personnel p = (Personnel) session.getAttribute("personnel_detail"); String
	 * status = p.getPersonnelTypeName(); System.out.println("Status ::: " +
	 * status);
	 * 
	 * BudgetYear byear = new BudgetYear();
	 * 
	 * //query สถานะและปีมาคำนวน byear = manager.getStatusAndYearBudget(status,
	 * year); System.out.println("สถานะ : " +
	 * byear.getBudgetyeatid().getPersonnelType()); System.out.println("เงิน : " +
	 * byear.getBudgetBath()); //เงินในตาราง budget year
	 * 
	 * //หาผลลัพธ์ double totalall = 0; double getBudgetYear = 0; double
	 * personnelBudget = 0;
	 * 
	 * Personnel per = new Personnel(); per =
	 * manager.getBudgetById(p.getPersonnelID()); //ตัวแปร getBudgetYear =
	 * byear.getBudgetBath(); //3000 personnelBudget = per.getBudget(); //10000
	 * //session ต้องเปลี่ยน session เป็นตัวแปลจริง getBudgetYear = personnelBudget;
	 * //คงเหลือ = 3000 = คงเหลือ
	 * 
	 * 
	 * if(getBudgetYear > sum) { //1000 > 5000 1000 - 500 totalall = getBudgetYear -
	 * sum; //ผลรวม = คงเหลือ - ผลรวมทั้งหมดของเอกสาร
	 * 
	 * String travelReportID = request.getParameter("travelReportID"); String
	 * reYear[] = travelReportDate.split("-" ); int reCal =
	 * Integer.parseInt(reYear[0]) - 543; String reDateYear = reCal + "-" +
	 * reYear[1] + "-" + reYear[2];
	 * 
	 * Date date = new Date(); try { SimpleDateFormat dateFormat = new
	 * SimpleDateFormat("yyyy-MM-dd"); date = dateFormat.parse(reDateYear); } catch
	 * (ParseException e) { e.printStackTrace(); }
	 * 
	 * String travelReportText = request.getParameter("travelReportText");
	 * 
	 * TravelReport report = new TravelReport(travelReportID , date,
	 * travelReportText);
	 * 
	 * 
	 * result = manager.isTravelReport(report, reDateYear , bid);
	 * 
	 * if (result == 1) { mav = new ModelAndView("ListDocument"); msg =
	 * "บันทึกสำเร็จ"; System.out.println(msg); } else { mav = new
	 * ModelAndView("CreateTravelReport"); msg = "บันทึกไม่สำเร็จ";
	 * System.out.println(msg); }
	 * 
	 * 
	 * //ผลรวมทั้งหมดส่งไปอัพเดทใน procedure int resultUpdatePersonnel = 0; String
	 * statusUpdate = ""; String pid = p.getPersonnelID();
	 * 
	 * resultUpdatePersonnel = manager.isUpdateBudgetTotalInPersonnel(pid,
	 * totalall);
	 * 
	 * if(resultUpdatePersonnel == 1) { statusUpdate = "อัพเดทสำเร็จ";
	 * System.out.println(statusUpdate); }else { statusUpdate = "อัพเดทไม่สำเร็จ";
	 * System.out.println(statusUpdate); }
	 * 
	 * 
	 * 
	 * }else {
	 * 
	 * String m = "ผลรวมของเอกสารเกินงบที่ให้ไว้กรุณาแก้ไขใหม่";
	 * 
	 * mav.addObject("m", m); }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * }catch(SQLException e) { e.printStackTrace(); }
	 * 
	 * //คำนวนเงินรวม
	 * 
	 * 
	 * 
	 * 
	 * return mav; }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @RequestMapping(value = "/doAddTravelReport", method = RequestMethod.POST)
	 * public ModelAndView do_addTravelReport(HttpServletRequest request, Model md,
	 * HttpSession session) { int result = 0; String msg = ""; String bid = (String)
	 * session.getAttribute("bid"); ModelAndView mav = new ModelAndView();
	 * 
	 * try { request.setCharacterEncoding("UTF-8"); } catch
	 * (UnsupportedEncodingException e1) { e1.printStackTrace(); }
	 * 
	 * try { CreateManager manager = new CreateManager();
	 * 
	 * 
	 * String travelReportID = request.getParameter("travelReportID"); String
	 * travelReportDate = request.getParameter("travelReportDate"); String reYear[]
	 * = travelReportDate.split("-" ); int reCal = Integer.parseInt(reYear[0]) -
	 * 543; String reDateYear = reCal + "-" + reYear[1] + "-" + reYear[2];
	 * 
	 * Date date = new Date(); try { SimpleDateFormat dateFormat = new
	 * SimpleDateFormat("yyyy-MM-dd"); date = dateFormat.parse(reDateYear); } catch
	 * (ParseException e) { e.printStackTrace(); }
	 * 
	 * String travelReportText = request.getParameter("travelReportText");
	 * 
	 * TravelReport report = new TravelReport(travelReportID , date,
	 * travelReportText);
	 * 
	 * 
	 * result = manager.isTravelReport(report, reDateYear , bid);
	 * 
	 * if (result == 1) { mav = new ModelAndView("ListDocument"); msg =
	 * "บันทึกสำเร็จ"; System.out.println(msg); } else { mav = new
	 * ModelAndView("CreateTravelReport"); msg = "บันทึกไม่สำเร็จ";
	 * System.out.println(msg); }
	 * 
	 * 
	 * //คำนวนเงินรวม
	 * 
	 * BudgetRequest budget = new BudgetRequest(); budget =
	 * manager.getStatusBudget(bid);
	 * 
	 * TravelRequest travel = new TravelRequest(); RegistrationBudgetRequest reg =
	 * new RegistrationBudgetRequest();
	 * 
	 * String b = budget.getStatus(); System.out.println("B : " + b);
	 * if(b.equals("ทำเอกสารรายงานการเดินทางแล้ว")) {
	 * 
	 * //ผลรวมการเดินทาง travel = manager.getTotalTravel(bid); double traveltotal =
	 * travel.getTotalBudget();
	 * 
	 * //ผลรวมค่าลงทะเบียน reg = manager.getTotalRegis(bid); double requestBudget =
	 * reg.getRequestBudget();
	 * 
	 * double sum = 0; sum = traveltotal + requestBudget;
	 * 
	 * System.out.println("ผลรวมเอกสารขออนุมัติเดินทาง : " + traveltotal);
	 * System.out.println("ผลรวมเอกสารอนุมัติการเดินทาง : " + requestBudget);
	 * System.out.println("ผลรวมสองเอกสาร : " + sum);
	 * 
	 * String year = ""; try { SimpleDateFormat dateFormat = new
	 * SimpleDateFormat("yyyy"); year =
	 * dateFormat.format(dateFormat.parse(travelReportDate).getTime());
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * System.out.println("Year ::: " + year);
	 * 
	 * Personnel p = (Personnel) session.getAttribute("personnel_detail"); String
	 * status = p.getPersonnelTypeName(); System.out.println("Status ::: " +
	 * status);
	 * 
	 * BudgetYear byear = new BudgetYear();
	 * 
	 * //query สถานะและปีมาคำนวน byear = manager.getStatusAndYearBudget(status,
	 * year); System.out.println("สถานะ : " +
	 * byear.getBudgetyeatid().getPersonnelType()); System.out.println("เงิน : " +
	 * byear.getBudgetBath()); //เงินในตาราง budget year
	 * 
	 * //หาผลลัพธ์ double totalall = 0; double getBudgetYear = 0; double
	 * personnelBudget = 0;
	 * 
	 * Personnel per = new Personnel(); per =
	 * manager.getBudgetById(p.getPersonnelID()); //ตัวแปร getBudgetYear =
	 * byear.getBudgetBath(); //3000 personnelBudget = per.getBudget(); //10000
	 * //session ต้องเปลี่ยน session เป็นตัวแปลจริง getBudgetYear = personnelBudget;
	 * //คงเหลือ = 3000 = คงเหลือ
	 * 
	 * if(getBudgetYear > sum) { //1000 > 5000 1000 - 500 totalall = getBudgetYear -
	 * sum; //ผลรวม = คงเหลือ - ผลรวมทั้งหมดของเอกสาร }else { totalall = sum -
	 * getBudgetYear; //ผลรวม = คงเหลือ - ผลรวมทั้งหมดของเอกสาร }
	 * 
	 * System.out.println("getBudgetYear :" + getBudgetYear + " personnelBudget : "
	 * + personnelBudget); System.out.println("Total All :" + totalall);//ผลรวม
	 * 
	 * //ผลรวมทั้งหมดส่งไปอัพเดทใน procedure int resultUpdatePersonnel = 0; String
	 * statusUpdate = ""; String pid = p.getPersonnelID();
	 * 
	 * resultUpdatePersonnel = manager.isUpdateBudgetTotalInPersonnel(pid,
	 * totalall);
	 * 
	 * if(resultUpdatePersonnel == 1) { statusUpdate = "อัพเดทสำเร็จ";
	 * System.out.println(statusUpdate); }else { statusUpdate = "อัพเดทไม่สำเร็จ";
	 * System.out.println(statusUpdate); }
	 * 
	 * 
	 * }
	 * 
	 * 
	 * 
	 * //ปิด
	 * 
	 * 
	 * 
	 * mav.addObject("msg", msg);
	 * 
	 * } catch (SQLException e) {
	 * 
	 * e.printStackTrace(); }
	 * 
	 * ListManager lm = new ListManager(); Personnel personnel = (Personnel)
	 * session.getAttribute("personnel_detail"); try { List<BudgetRequest> br =
	 * lm.getBudgetRequest(personnel.getPersonnelID()); List<String> rdate = new
	 * ArrayList<>(); List<String> ydate = new ArrayList<>(); String DATE_FORMAT =
	 * "dd MMMM yyyy"; String YEAR_FORMAT = "yyyy"; SimpleDateFormat sdf = new
	 * SimpleDateFormat(DATE_FORMAT, new Locale("th", "TH")); SimpleDateFormat syf =
	 * new SimpleDateFormat(YEAR_FORMAT, new Locale("th", "TH"));
	 * 
	 * for(BudgetRequest b : br) { rdate.add(sdf.format(b.getRequestDate()));
	 * ydate.add(syf.format(b.getRequestDate())); }
	 * 
	 * 
	 * 
	 * if(br.size() != 0) { session.setAttribute("budgetRequest", br);
	 * mav.addObject("budgetRequest", br); mav.addObject("rDate", rdate);
	 * mav.addObject("yDate", ydate); } } catch (SQLException e) {
	 * e.printStackTrace(); }
	 * 
	 * return mav; }
	 */
	
	
}
