package com.springmvc.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="Personnel")
public class Personnel {
	
	@Id
	@Column(name="personnelID" , length = 10)
	private String personnelID;
	
	@Column(name="title" , nullable=false , length = 45)
	private String title;
	
	@Column(name="firstname" , nullable=false , length = 45)
	private String firstname;
	
	@Column(name="lastname" , nullable=false , length = 45) 
	private String lastname;
	
	@Column(name="budget" , nullable=false)
	private double budget;
	
	@Column(name="salary" , nullable=false)
	private double salary;
	
	@Column(name="personnelType" , nullable=false)
	private int personnelType;
	
	@Column(name="position" , nullable=false , length = 50)
	private String position;
	
	@Column(name="personnelTypeName" , nullable=false , length = 50)
	private String personnelTypeName;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "Department_departmentID" , nullable=false)
	private Department department;
	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "personnel")
	private List<BudgetRequest> budgetRequest = new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "personnel")
	private List<CommentTravel> commentTravel = new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "personnel")
	private List<CommentRegistrationBudget> commentReg = new ArrayList<>();
	
	
	
	
	public Personnel() {
		super();
	}

	public Personnel(String personnelID, String title, String firstname, String lastname, double budget, double salary,
			int personnelType, String position) {
		super();
		this.personnelID = personnelID;
		this.title = title;
		this.firstname = firstname;
		this.lastname = lastname;
		this.budget = budget;
		this.salary = salary;
		this.personnelType = personnelType;
		this.position = position;
	}

	public String getPersonnelID() {
		return personnelID;
	}

	public void setPersonnelID(String personnelID) {
		this.personnelID = personnelID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public double getBudget() {
		return budget;
	}

	public void setBudget(double budget) {
		this.budget = budget;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getPersonnelType() {
		return personnelType;
	}

	public void setPersonnelType(int personnelType) {
		this.personnelType = personnelType;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	

	public String getPersonnelTypeName() {
		return personnelTypeName;
	}

	public void setPersonnelTypeName(String personnelTypeName) {
		this.personnelTypeName = personnelTypeName;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<BudgetRequest> getBudgetRequest() {
		return budgetRequest;
	}

	public void setBudgetRequest(List<BudgetRequest> budgetRequest) {
		this.budgetRequest = budgetRequest;
	}

	public List<CommentTravel> getCommentTravel() {
		return commentTravel;
	}

	public void setCommentTravel(List<CommentTravel> commentTravel) {
		this.commentTravel = commentTravel;
	}

	public List<CommentRegistrationBudget> getCommentReg() {
		return commentReg;
	}

	public void setCommentReg(List<CommentRegistrationBudget> commentReg) {
		this.commentReg = commentReg;
	}

	
	
	

	
	
	
	
	
	
	

	
	
	
	
	


	
	
	
	
	

}
