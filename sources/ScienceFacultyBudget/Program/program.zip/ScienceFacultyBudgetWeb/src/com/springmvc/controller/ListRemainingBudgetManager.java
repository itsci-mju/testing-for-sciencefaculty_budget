package com.springmvc.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class ListRemainingBudgetManager {
	
	public List<Personnel> getListRemainingBudget()throws SQLException{
		List<Personnel> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select p.personnelID , p.title , p.firstname , p.lastname , p.position , d.departmentName , p.budget from personnel p inner join department d on p.Department_departmentID = d.departmentID group by personnelID";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				Personnel p = new Personnel();
				Department d = new Department();
				p.setPersonnelID(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setFirstname(rs.getString(3));
				p.setLastname(rs.getString(4));
				p.setPosition(rs.getString(5));
				d.setDepartmentName(rs.getString(6));
				p.setBudget(rs.getDouble(7));
				p.setDepartment(d);
				
				list.add(p);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	//ทดสอบ
	public List<Personnel> getPersonnelBySearchFirstName(String firstname)throws SQLException{
		List<Personnel> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , title , firstname , lastname , position , departmentName , budget from personnel p inner join department d on p.Department_departmentID = d.departmentID where p.firstname LIKE '%"+firstname+"%'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				Personnel p = new Personnel();
				Department d = new Department();		
				p.setPersonnelID(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setFirstname(rs.getString(3));
				p.setLastname(rs.getString(4));
				p.setPosition(rs.getString(5));
				d.setDepartmentName(rs.getString(6));
				p.setBudget(rs.getDouble(7));
				p.setDepartment(d);
			
				list.add(p);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	/*
	 * public List<BudgetRequest> getPersonnelBySearchFirstName(String
	 * firstname)throws SQLException{ List<BudgetRequest> list = new ArrayList<>();
	 * ConnectionDB condb = new ConnectionDB(); Connection conn =
	 * condb.getConnection(); try { Statement stmt = conn.createStatement(); String
	 * sql =
	 * "Select budgetRequestID , chooseRequest , requestDate , requestName , status , personnelID , title , firstname , lastname , position , departmentName , budget from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where p.firstname LIKE '%"
	 * +firstname+"%'"; ResultSet rs = stmt.executeQuery(sql);
	 * System.out.println(sql);
	 * 
	 * while(rs.next()) { BudgetRequest budget = new BudgetRequest(); Personnel p =
	 * new Personnel(); Department d = new Department();
	 * budget.setbudgetRequestID(rs.getString(1));
	 * budget.setChooseRequest(rs.getString(2));
	 * budget.setRequestDate(rs.getDate(3)); budget.setRequestName(rs.getString(4));
	 * budget.setStatus(rs.getString(5)); p.setPersonnelID(rs.getString(6));
	 * p.setTitle(rs.getString(7)); p.setFirstname(rs.getString(8));
	 * p.setLastname(rs.getString(9)); p.setPosition(rs.getString(10));
	 * d.setDepartmentName(rs.getString(11)); p.setBudget(rs.getDouble(12));
	 * budget.setPersonnel(p); p.setDepartment(d);
	 * 
	 * 
	 * 
	 * 
	 * list.add(budget); } }catch(SQLException e) { e.printStackTrace(); }
	 * conn.close(); return list; }
	 */
	
	public List<Personnel> getPersonnelBySearchLastName(String lastname)throws SQLException{
		List<Personnel> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , title , firstname , lastname , position , departmentName , budget from personnel p inner join department d on p.Department_departmentID = d.departmentID where p.lastname LIKE '%"+lastname+"%'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				Personnel p = new Personnel();
				Department d = new Department();
				p.setPersonnelID(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setFirstname(rs.getString(3));
				p.setLastname(rs.getString(4));
				p.setPosition(rs.getString(5));
				d.setDepartmentName(rs.getString(6));
				p.setBudget(rs.getDouble(7));				
				p.setDepartment(d);
			
				
				list.add(p);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	public List<Personnel> getPersonnelBySearchFirstLastName(String firstname , String lastname)throws SQLException{
		List<Personnel> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select personnelID , title , firstname , lastname , position , departmentName , budget from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where p.firstname LIKE '%"+firstname+"%' or p.lastname LIKE '%"+lastname+"%'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				Personnel p = new Personnel();
				Department d = new Department();
				p.setPersonnelID(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setFirstname(rs.getString(3));
				p.setLastname(rs.getString(4));
				p.setPosition(rs.getString(5));
				d.setDepartmentName(rs.getString(6));
				p.setBudget(rs.getDouble(7));
				p.setDepartment(d);
						
				
				list.add(p);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	

}
