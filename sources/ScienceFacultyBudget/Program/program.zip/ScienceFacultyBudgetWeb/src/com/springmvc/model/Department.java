package com.springmvc.model;

import java.util.*;

import javax.persistence.*;


@Entity
@Table(name="Department")
public class Department {
	
	@Id
	@Column(name="departmentID")
	private int departmentID;
	
	@Column(name="departmentName" , nullable=false , length = 100)
	private String departmentName;
	
	@Column(name="tel" , nullable=false , length = 4)
	private String tel;
	
	
	@OneToMany(cascade=CascadeType.ALL , mappedBy = "department")
	private List<Personnel> personnel = new ArrayList<>();
	
	
	public Department() {
		super();
	}
	
	

	public Department(int departmentID, String departmentName, String tel) {
		super();
		this.departmentID = departmentID;
		this.departmentName = departmentName;
		this.tel = tel;
		
	}



	public Department(int departmentID, String departmentName) {
		super();
		this.departmentID = departmentID;
		this.departmentName = departmentName;
	}

	public int getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(int departmentID) {
		this.departmentID = departmentID;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public List<Personnel> getPersonnel() {
		return personnel;
	}

	public void setPersonnel(List<Personnel> personnel) {
		this.personnel = personnel;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
	
	
	
	
	

}
