package com.springmvc.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="CommentRegistrationBudget")
public class CommentRegistrationBudget {
	
	@Id
	@Column(name="commentId" , length = 20)
	private String commentId;
	
	@Column(name="commentRegisDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date commentRegisDate;
	
	@Column(name="commentRegisText" , nullable=false , length = 100)
	private String commentRegisText;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "RegistrationBudgetRequest_registrationID" , nullable=false)
	private RegistrationBudgetRequest registrationBudgetRequest;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "Personnel_personnelID" , nullable=false)
	private Personnel personnel;

	public CommentRegistrationBudget() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CommentRegistrationBudget(String commentId ,Date commentRegisDate, String commentRegisText) {
		this.commentId = commentId;
		this.commentRegisDate = commentRegisDate;
		this.commentRegisText = commentRegisText;
	}

	public CommentRegistrationBudget(Date commentRegisDate, String commentRegisText,
			RegistrationBudgetRequest registrationBudgetRequest, Personnel personnel) {
		super();
		this.commentRegisDate = commentRegisDate;
		this.commentRegisText = commentRegisText;
		this.registrationBudgetRequest = registrationBudgetRequest;
		this.personnel = personnel;
	}
	
	

	public String getCommentId() {
		return commentId;
	}

	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}

	public Date getCommentRegisDate() {
		return commentRegisDate;
	}

	public void setCommentRegisDate(Date commentRegisDate) {
		this.commentRegisDate = commentRegisDate;
	}

	public String getCommentRegisText() {
		return commentRegisText;
	}

	public void setCommentRegisText(String commentRegisText) {
		this.commentRegisText = commentRegisText;
	}

	public RegistrationBudgetRequest getRegistrationBudgetRequest() {
		return registrationBudgetRequest;
	}

	public void setRegistrationBudgetRequest(RegistrationBudgetRequest registrationBudgetRequest) {
		this.registrationBudgetRequest = registrationBudgetRequest;
	}

	public Personnel getPersonnel() {
		return personnel;
	}

	public void setPersonnel(Personnel personnel) {
		this.personnel = personnel;
	}
	
	
	
	

}
