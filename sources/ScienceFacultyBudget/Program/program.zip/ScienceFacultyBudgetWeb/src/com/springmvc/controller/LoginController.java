package com.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.BudgetYear;
import com.springmvc.model.BudgetYearId;
import com.springmvc.model.Personnel;
import com.springmvc.model.RegistrationBudgetRequest;


@Controller
public class LoginController {
	
	@RequestMapping(value="/doLoginData", method=RequestMethod.POST)
	public ModelAndView doLoginData(HttpServletRequest request , Model md , HttpSession session,	
		@Valid @ModelAttribute("personnel") Personnel per ,BindingResult br){
		
			if(br.getAllErrors().size() > 0) {
				ModelAndView mav = new ModelAndView("index");
				
				mav.addObject("error_msg",  "กรุณาป้อนชื่อผู้ใช้และรหัสผ่านให้ถูกต้อง");
				return mav;
			}else {
				
				try {
					
				String uname = request.getParameter("username");
				String pwd = request.getParameter("salary");
				
				System.out.println("username1 = " + uname);
				System.out.println("pass1 = " + pwd);
				
				PersonnelManager mg = new PersonnelManager();		
		
				
			
				per = mg.isVerifyLogin(uname);
				
				
				
				
				if(null != per && per.getSalary() == Double.parseDouble(pwd)) {
								
					ModelAndView mav = new ModelAndView("ViewRemainingBudgetPage");		
					Personnel personnelDetail = new Personnel();
					personnelDetail = mg.isRemainingBudget(per.getPersonnelID());
					System.out.println("personnelDetail = " + personnelDetail.getPersonnelID());
					
					
					//quuery ปีงบประมาณ
					
					List<BudgetYear> byear = mg.isBudgetYear();
					
					
					//ปิด
					
					session.setMaxInactiveInterval(60*15);
					session.setAttribute("personnel_detail", personnelDetail); //จำ
					System.out.println("Login");
					mav.addObject("personnel_detail",personnelDetail);
					
					mav.addObject("byear", byear); //ปีงบประมาณ
					
					return mav;				
			
				
			}else {

				ModelAndView mav = new ModelAndView("index");
				mav.addObject("error_msg",  "กรุณาป้อนชื่อผู้ใช้และรหัสผ่านให้ถูกต้อง");
				return mav;
			}
			
		} catch (NumberFormatException e) {			
			e.printStackTrace();
			ModelAndView mav = new ModelAndView("index");
			mav.addObject("error_msg",  "กรุณาป้อนชื่อผู้ใช้และรหัสผ่านให้ถูกต้อง");
			return mav;
		} catch (SQLException e) {			
			e.printStackTrace();
			ModelAndView mav = new ModelAndView("index");
			mav.addObject("error_msg",  "กรุณาป้อนชื่อผู้ใช้และรหัสผ่านให้ถูกต้อง");
			return mav;
		}
		
		}
	}
	
	
	@RequestMapping(value="/doLogoutData", method = RequestMethod.GET)
	public ModelAndView doLogoutData(HttpServletRequest request, Model md, HttpSession session) {				
			
		
		session.removeAttribute("personnel_detail");
		session.setMaxInactiveInterval(0);
		ModelAndView mav = new ModelAndView("index");
		System.out.println("Logout");
		
		return mav;
	}
	
	
	  
	 
	
	
}
