package com.springmvc.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.springmvc.model.*;

import conn.ConnectionDB;

public class ViewManager {
	
	public List<BudgetRequest> getViewBudgetRequest()throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.firstname , p.lastname , p.title , b.status from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID order by b.requestDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel personnel = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setFirstname(rs.getString(5));
				personnel.setLastname(rs.getString(6));
				personnel.setTitle(rs.getString(7));
				budget.setStatus(rs.getString(8));
				budget.setPersonnel(personnel);
				
				
				System.out.println(budget);
				list.add(budget);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	public List<RequestingPermission> getViewRequestingPermission()throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.requestPerID , r.requestPerName , r.requestingPerDate , r.requestingPerText , p.firstname , p.lastname , p.title , b.status from requestingpermission r inner join budgetrequest b on r.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID order by r.requestingPerDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				RequestingPermission permission = new RequestingPermission();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				p.setFirstname(rs.getString(5));
				p.setLastname(rs.getString(6));
				p.setTitle(rs.getString(7));
				budgetRequest.setStatus(rs.getString(8));
				budgetRequest.setPersonnel(p);
				permission.setBudgetRequest(budgetRequest);
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	public List<TravelRequest> getViewTravelRequest()throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select t.travelID , t.allowance , t.endDate , t.grade , t.level , t.location , t.otherBudget , t.payType , t.rentalRoom , t.startDate , t.titleName , t.totalBudget , t.totalDate , t.travelDate , t.travelVehicle , t.vehicleBudget , t.withName , p.firstname , p.lastname , p.title , b.status from travelrequest t inner join budgetrequest b on t.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID order by t.travelDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				TravelRequest travel = new TravelRequest();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));				
				p.setFirstname(rs.getString(18));
				p.setLastname(rs.getString(19));
				p.setTitle(rs.getString(20));
				
				budgetRequest.setStatus(rs.getString(21));
				budgetRequest.setPersonnel(p);
				travel.setBudgetRequest(budgetRequest);
				
				list.add(travel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	public List<RegistrationBudgetRequest> getViewRegistrationBudgetRequest()throws SQLException{
		List<RegistrationBudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.registrationID , r.beforeDate , r.budgetText , r.cost , r.location , r.regisDate , r.regisEndDate , r.regisStartDate , r.requestBudget , r.textTo , r.titleName , r.BudgetRequest_budgetRequestID , p.firstname , p.lastname , p.title , b.status from registrationbudgetrequest r inner join budgetrequest b on r.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID order by r.regisDate DESC";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();				
				reg.setRegistrationID(rs.getString(1));
				reg.setBeforeDate(rs.getDate(2));
				reg.setBudgetText(rs.getString(3));
				reg.setCost(rs.getDouble(4));
				reg.setLocation(rs.getString(5));
				reg.setRegisDate(rs.getDate(6));
				reg.setRegisEndDate(rs.getDate(7));
				reg.setRegisStartDate(rs.getDate(8));
				reg.setRequestBudget(rs.getDouble(9));
				reg.setTextTo(rs.getString(10));
				reg.setTitleName(rs.getString(11));	
				
				p.setFirstname(rs.getString(13));
				p.setLastname(rs.getString(14));
				p.setTitle(rs.getString(15));
				budgetRequest.setStatus(rs.getString(16));
				budgetRequest.setPersonnel(p);
				reg.setBudgetRequest(budgetRequest);
				
				list.add(reg);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	
	
	
	
	public BudgetRequest getViewBudgetRequestID(String bid)throws SQLException{
		BudgetRequest budget = new BudgetRequest();
		Personnel personnel = new Personnel();
		Department d = new Department();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.title ,  p.firstname , p.lastname , p.position , d.departmentName from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where budgetRequestID =  '" + bid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {								
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				personnel.setPosition(rs.getString(8));
				d.setDepartmentName(rs.getString(9));
				personnel.setDepartment(d);
				budget.setPersonnel(personnel);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return budget;		
	} 
	
	
	
	public RequestingPermission getViewRequestingPermissionID(String rid)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		RequestingPermission permission = new RequestingPermission();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select requestPerID , requestPerName , requestingPerDate , requestingPerText , BudgetRequest_budgetRequestID from requestingpermission where requestPerID = '"+ rid +"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return permission;		
	}
	
	
	
	public TravelRequest getViewTravelRequestID(String tid)throws SQLException{
		List<TravelRequest> list = new ArrayList<>();
		TravelRequest travel = new TravelRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select t.travelID , t.allowance , t.endDate , t.grade , t.level , t.location , t.otherBudget , t.payType , t.rentalRoom , t.startDate , t.titleName , t.totalBudget , t.totalDate , t.travelDate , t.travelVehicle , t.vehicleBudget , t.withName , t.BudgetRequest_budgetRequestID , p.title ,  p.firstname , p.lastname , p.position , d.departmentName from travelrequest t inner join budgetrequest b on t.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID inner join department d on p.Department_departmentID = d.departmentID where travelID = '" + tid + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				Department d = new Department();
				BudgetRequest budget = new BudgetRequest();
				Personnel p = new Personnel();
				travel.setTravelID(rs.getString(1));
				travel.setAllowance(rs.getDouble(2));
				travel.setEndDate(rs.getDate(3));
				travel.setGrade(rs.getString(4));
				travel.setLevel(rs.getString(5));
				travel.setLocation(rs.getString(6));
				travel.setOtherBudget(rs.getDouble(7));
				travel.setPayType(rs.getString(8));
				travel.setRentalRoom(rs.getDouble(9));
				travel.setStartDate(rs.getDate(10));
				travel.setTitleName(rs.getString(11));
				travel.setTotalBudget(rs.getDouble(12));
				travel.setTotalDate(rs.getString(13));
				travel.setTravelDate(rs.getDate(14));
				travel.setTravelVehicle(rs.getString(15));
				travel.setVehicleBudget(rs.getDouble(16));
				travel.setWithName(rs.getString(17));				
				p.setTitle(rs.getString(19));
				p.setFirstname(rs.getString(20));
				p.setLastname(rs.getString(21));
				p.setPosition(rs.getString(22));
				d.setDepartmentName(rs.getString(23));
				p.setDepartment(d);
				budget.setPersonnel(p);
				travel.setBudgetRequest(budget);
				
				
				list.add(travel);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return travel;		
	}
	
	
	public RegistrationBudgetRequest getViewRegistrationBudgetRequestID(String regid)throws SQLException{
		List<RegistrationBudgetRequest> list = new ArrayList<>();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select registrationID , beforeDate , budgetText , cost , location , regisDate , regisDate , regisStartDate , requestBudget , textTo , titleName , BudgetRequest_budgetRequestID from registrationbudgetrequest where registrationID = '" + regid + "' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				reg.setRegistrationID(rs.getString(1));
				reg.setBeforeDate(rs.getDate(2));
				reg.setBudgetText(rs.getString(3));
				reg.setCost(rs.getDouble(4));
				reg.setLocation(rs.getString(5));
				reg.setRegisDate(rs.getDate(6));
				reg.setRegisEndDate(rs.getDate(7));
				reg.setRegisStartDate(rs.getDate(8));
				reg.setRequestBudget(rs.getDouble(9));
				reg.setTextTo(rs.getString(10));
				reg.setTitleName(rs.getString(11));
				
				list.add(reg);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return reg;		
	}
	
	
	//แสดงคอมเม้นหน้าเจ้าหน้าที่การเงิน
	
	public CommentTravel getViewCommentTravelByFinance(String tid)throws SQLException{
		CommentTravel cmt = new CommentTravel();
		TravelRequest travel = new TravelRequest();
		Personnel personnel = new Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentTravelDate , commentTravelText , Personnel_personnelID , TravelRequest_travelID , title , firstname , lastname from CommentTravel cmt left join personnel p on cmt.Personnel_personnelID = p.personnelID where TravelRequest_travelID = '" + tid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				cmt.setCommentTravelDate(rs.getDate(1));
				cmt.setCommentTravelText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				travel.setTravelID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				
				
				cmt.setPersonnel(personnel);
				cmt.setTravelRequest(travel);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return cmt;		
	}
	
	public List<CommentTravel> getListCommentTravelByFinance(String tid)throws SQLException{
		List<CommentTravel> list = new ArrayList<>();
		TravelRequest travel = new TravelRequest();
		Personnel personnel = new Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentTravelDate , commentTravelText , Personnel_personnelID , TravelRequest_travelID , title , firstname , lastname from CommentTravel cmt left join personnel p on cmt.Personnel_personnelID = p.personnelID where TravelRequest_travelID = '" + tid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				CommentTravel cmt = new CommentTravel();
				cmt.setCommentTravelDate(rs.getDate(1));
				cmt.setCommentTravelText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				travel.setTravelID(rs.getString(4));
				personnel.setTitle(rs.getString(5));
				personnel.setFirstname(rs.getString(6));
				personnel.setLastname(rs.getString(7));
				
				
				cmt.setPersonnel(personnel);
				cmt.setTravelRequest(travel);
				list.add(cmt);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;		
	}
	
	
	public CommentRegistrationBudget getViewCommentRegisByFinance(String rid)throws SQLException{
		CommentRegistrationBudget cmr = new CommentRegistrationBudget();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		Personnel personnel = new Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentRegisDate, commentRegisText, Personnel_personnelID, RegistrationBudgetRequest_registrationID from CommentRegistrationBudget cmr left join personnel p on cmr.Personnel_personnelID = p.personnelID where RegistrationBudgetRequest_registrationID = '" + rid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				cmr.setCommentRegisDate(rs.getDate(1));
				cmr.setCommentRegisText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				reg.setRegistrationID(rs.getString(4));
				cmr.setPersonnel(personnel);
				cmr.setRegistrationBudgetRequest(reg);

			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return cmr;		
	} 
	
	public List<CommentRegistrationBudget> getListCommentRegisByFinance(String rid)throws SQLException{
		List<CommentRegistrationBudget> list = new ArrayList<>();
		RegistrationBudgetRequest reg = new RegistrationBudgetRequest();
		Personnel personnel = new Personnel();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select commentRegisDate, commentRegisText, Personnel_personnelID, RegistrationBudgetRequest_registrationID from CommentRegistrationBudget cmr left join personnel p on cmr.Personnel_personnelID = p.personnelID where RegistrationBudgetRequest_registrationID = '" + rid + "'";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {	
				CommentRegistrationBudget cmr = new CommentRegistrationBudget();
				cmr.setCommentRegisDate(rs.getDate(1));
				cmr.setCommentRegisText(rs.getString(2));
				personnel.setPersonnelID(rs.getString(3));
				reg.setRegistrationID(rs.getString(4));
				cmr.setPersonnel(personnel);
				cmr.setRegistrationBudgetRequest(reg);
				
				list.add(cmr);
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;	
	} 
	
	
	
	//ค้นหาชื่อ budgetrequest fname
	public List<BudgetRequest> getViewBudgetRequestSearchFname(String fname)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.firstname , p.lastname , p.title , b.status from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID where p.firstname = '"+fname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel personnel = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setFirstname(rs.getString(5));
				personnel.setLastname(rs.getString(6));
				personnel.setTitle(rs.getString(7));
				budget.setStatus(rs.getString(8));
				budget.setPersonnel(personnel);
				
				
				System.out.println(budget);
				list.add(budget);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	//ค้นหาชื่อ budgetrequest lname
	public List<BudgetRequest> getViewBudgetRequestSearchLname(String lname)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.firstname , p.lastname , p.title , b.status from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID where p.lastname = '"+lname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel personnel = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setFirstname(rs.getString(5));
				personnel.setLastname(rs.getString(6));
				personnel.setTitle(rs.getString(7));
				budget.setStatus(rs.getString(8));
				budget.setPersonnel(personnel);
				
				
				System.out.println(budget);
				list.add(budget);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	public List<BudgetRequest> getViewBudgetRequestSearchFullName(String fname , String lname)throws SQLException{
		List<BudgetRequest> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select b.budgetRequestID , b.chooseRequest , b.requestDate , b.requestName , p.firstname , p.lastname , p.title , b.status from budgetrequest b inner join personnel p on b.Personnel_personnelID = p.personnelID where p.firstname = '"+fname+"' and p.lastname = '"+lname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				BudgetRequest budget = new BudgetRequest();
				Personnel personnel = new Personnel();
				budget.setbudgetRequestID(rs.getString(1));
				budget.setChooseRequest(rs.getString(2));
				budget.setRequestDate(rs.getDate(3));
				budget.setRequestName(rs.getString(4));
				personnel.setFirstname(rs.getString(5));
				personnel.setLastname(rs.getString(6));
				personnel.setTitle(rs.getString(7));
				budget.setStatus(rs.getString(8));
				budget.setPersonnel(personnel);
				
				
				System.out.println(budget);
				list.add(budget);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	
	//requestingPermission
	public List<RequestingPermission> getViewRequestingSearchFName(String fname)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.requestPerID , r.requestPerName , r.requestingPerDate , r.requestingPerText , p.firstname , p.lastname , p.title , b.status from requestingpermission r inner join budgetrequest b on r.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID where p.firstname = '"+fname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				RequestingPermission permission = new RequestingPermission();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				p.setFirstname(rs.getString(5));
				p.setLastname(rs.getString(6));
				p.setTitle(rs.getString(7));
				budgetRequest.setStatus(rs.getString(8));
				budgetRequest.setPersonnel(p);
				permission.setBudgetRequest(budgetRequest);
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
	
	public List<RequestingPermission> getViewRequestingSearchLName(String lname)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.requestPerID , r.requestPerName , r.requestingPerDate , r.requestingPerText , p.firstname , p.lastname , p.title , b.status from requestingpermission r inner join budgetrequest b on r.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID where p.lastname = '"+lname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				RequestingPermission permission = new RequestingPermission();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				p.setFirstname(rs.getString(5));
				p.setLastname(rs.getString(6));
				p.setTitle(rs.getString(7));
				budgetRequest.setStatus(rs.getString(8));
				budgetRequest.setPersonnel(p);
				permission.setBudgetRequest(budgetRequest);
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}
		
	public List<RequestingPermission> getViewRequestingSearchFullName(String fname , String lname)throws SQLException{
		List<RequestingPermission> list = new ArrayList<>();
		ConnectionDB condb = new ConnectionDB();
		Connection conn = condb.getConnection();
		
		try {			
			Statement stmt = conn.createStatement();
			String sql = "Select r.requestPerID , r.requestPerName , r.requestingPerDate , r.requestingPerText , p.firstname , p.lastname , p.title , b.status from requestingpermission r inner join budgetrequest b on r.BudgetRequest_budgetRequestID = b.budgetRequestID inner join personnel p on b.Personnel_personnelID = p.personnelID where p.firstname = '"+fname+"' and p.lastname = '"+lname+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println(sql);
			
			while(rs.next()) {				
				RequestingPermission permission = new RequestingPermission();
				BudgetRequest budgetRequest = new BudgetRequest();
				Personnel p = new Personnel();
				permission.setRequestPerID(rs.getString(1));
				permission.setRequestPerName(rs.getString(2));
				permission.setRequestingPerDate(rs.getDate(3));
				permission.setRequestingPerText(rs.getString(4));
				p.setFirstname(rs.getString(5));
				p.setLastname(rs.getString(6));
				p.setTitle(rs.getString(7));
				budgetRequest.setStatus(rs.getString(8));
				budgetRequest.setPersonnel(p);
				permission.setBudgetRequest(budgetRequest);
				
				list.add(permission);
				
			} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return list;
	}

	
	
	

}
