package com.springmvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;


@Entity
@Table(name="TravelReport")
public class TravelReport {
	
	@Id
	@Column(name="travelReportID" , length = 20)
	private String travelReportID;
	
	
	@Column(name="travelReportDate" , nullable=false)
	@Temporal(TemporalType.DATE)
	private Date travelReportDate;
	
	@Column(name="travelReportText"  , columnDefinition = "LONGTEXT" , nullable=false)
	private String travelReportText;
	
	@Column(name="fileName" , nullable=false , length = 50)
	private String fileName;
		
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "BudgetRequest_budgetRequestID" , nullable=false)
	private BudgetRequest budgetRequest;
	
	
	
	

	public TravelReport() {
		super();
	}


	

	public TravelReport(String fileName) {
		super();
		this.fileName = fileName;
	}




	public TravelReport(String travelReportID, Date travelReportDate, String travelReportText) {
		super();
		this.travelReportID = travelReportID;
		this.travelReportDate = travelReportDate;
		this.travelReportText = travelReportText;
	}




	public String getTravelReportID() {
		return travelReportID;
	}




	public Date getTravelReportDate() {
		return travelReportDate;
	}




	public String getTravelReportText() {
		return travelReportText;
	}




	public BudgetRequest getBudgetRequest() {
		return budgetRequest;
	}




	public void setTravelReportID(String travelReportID) {
		this.travelReportID = travelReportID;
	}




	public void setTravelReportDate(Date travelReportDate) {
		this.travelReportDate = travelReportDate;
	}




	public void setTravelReportText(String travelReportText) {
		this.travelReportText = travelReportText;
	}




	public void setBudgetRequest(BudgetRequest budgetRequest) {
		this.budgetRequest = budgetRequest;
	}




	public String getFileName() {
		return fileName;
	}




	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	


	

}
