    var myApp1 = new function () {
        this.printTable1 = function () {
            var h5 = document.getElementById('h5');
			var date = document.getElementById('date');
			var text = document.getElementById('text');
			var table = document.getElementById('table');
			var choose1 = document.getElementById('choose1');
			var choose2 = document.getElementById('choose2');
			var choose3 = document.getElementById('choose3');
			var choose4 = document.getElementById('choose4');




            var win = window.open('', '', 'height=700,width=700');
            win.document.write(h5.outerHTML);
			win.document.write(date.outerHTML);
			win.document.write(text.outerHTML);
			win.document.write(table.outerHTML);
			win.document.write(choose1.outerHTML);
			win.document.write(choose2.outerHTML);
			win.document.write(choose3.outerHTML);
			win.document.write(choose4.outerHTML);
			
            win.document.close();
            win.print();
        }
    }


	var myApp2 = new function () {
        this.printTable2 = function () {
            var h3 = document.getElementById('h3');
			var head1 = document.getElementById('head1');
			var head2 = document.getElementById('head2');
			var head3 = document.getElementById('head3');
			var head4= document.getElementById('head4');
			var body1= document.getElementById('body1');
			



            var win = window.open('', '', 'height=700,width=700');
            win.document.write(h3.outerHTML);
			win.document.write(head1.outerHTML);
			win.document.write(head2.outerHTML);
			win.document.write(head3.outerHTML);
			win.document.write(head4.outerHTML);
			win.document.write(body1.outerHTML);
			
			
            win.document.close();
            win.print();
        }
    }








