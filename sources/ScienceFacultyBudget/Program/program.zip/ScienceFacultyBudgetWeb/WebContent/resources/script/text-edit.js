
						tinymce
								.init({
									selector : 'textarea',
									plugins : 'advlist autolink lists link emoticons template paste textcolor colorpicker textpattern image charmap insertdatetime media nonbreaking save table contextmenu directionality print preview hr anchor pagebreak searchreplace wordcount visualblocks visualchars code fullscreen',
									toolbar : 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table ',
									toolbar_mode : 'floating',
									name : 'detail', 
									tinycomments_mode : 'embedded',
									tinycomments_author : 'Author name',
									image_advtab: true,
									paste_data_images: true,
							          file_picker_callback: function(callback, value, meta) {
							            if (meta.filetype == 'image') {
							              $('#upload').trigger('click');
							              $('#upload').on('change', function() {
							                var file = this.files[0];
							                var reader = new FileReader();
							                reader.onload = function(e) {
							                  callback(e.target.result, {
							                    alt: ''
							                  });
							                };
							                reader.readAsDataURL(file);
							              });
							            }
							          }
								});