	/*function check(BudgetRequest) {
		if(BudgetRequest.requestName.value == ""){
			alert("กรุณากรอกชื่อกิจกรรมที่เข้าร่วม ");
			BudgetRequest.requestName.focus();
			return false ;
		}
		
		var name = /^[A-Za-zก-์0-9]$/ ;
		if(!name.test(BudgetRequest.requestName.value)){
			alert("กรุณากรอกชื่อกิจกรรมเป็นภาษาอังกฤษ ภาษาไทย หรือตัวเลข");
			BudgetRequest.requestName.focus();
			return false ;
		}
		
		if(BudgetRequest.budgetReqtestID.value == ""){
			alert("กรุณากรอกรหัสเอกสาร ");
			BudgetRequest.budgetReqtestID.focus();
			return false ;
		}
		
		var id = /^[ก-์0-9]$/ ;
		if(!id.test(BudgetRequest.budgetReqtestID.value)){
			alert("กรุณากรอกชื่อกิจกรรมเป็นภาษาไทย หรือตัวเลข");
			BudgetRequest.budgetReqtestID.focus();
			return false ;
		}
		
		
	
		}*/