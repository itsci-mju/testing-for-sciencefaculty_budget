function show_alert() {
  alert("บันทึกสำเร็จ กรุณาทำรายการต่อไป");
}

function show_alertDefault() {
  alert("บันทึกสำเร็จ");
}


function show_alertEdit() {
  alert("แก้ไขสำเร็จ");
}


