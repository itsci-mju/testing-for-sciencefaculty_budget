function check() {
	
	var price_check = /^((\d+(\.\d*)?)|(\.\d+))$/;
	if(frm.item_price.value == "" || frm.item_price.value == null){
		alert("กรุณากรอกข้อมูลราคา");
		return false;
	}else{
		if(!frm.item_price.value.match(price_check)){
			alert("กรุณากรอกข้อมูลราคาเป็นตัวเลขเท่านั้น");
			return false;
		}
	}
	
	
	
	}