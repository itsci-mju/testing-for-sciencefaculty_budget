-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: sciencefacultybudget
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BudgetRequest`
--

DROP TABLE IF EXISTS `BudgetRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BudgetRequest` (
  `budgetRequestID` varchar(20) NOT NULL,
  `chooseRequest` varchar(10) NOT NULL,
  `requestDate` date NOT NULL,
  `requestName` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `fileName` varchar(50) NOT NULL,
  `Personnel_personnelID` varchar(10) NOT NULL,
  PRIMARY KEY (`budgetRequestID`),
  KEY `FKocp8gxoitkfvttmk0sc1rpxx6` (`Personnel_personnelID`),
  CONSTRAINT `FKocp8gxoitkfvttmk0sc1rpxx6` FOREIGN KEY (`Personnel_personnelID`) REFERENCES `Personnel` (`personnelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BudgetRequest`
--

LOCK TABLES `BudgetRequest` WRITE;
/*!40000 ALTER TABLE `BudgetRequest` DISABLE KEYS */;
INSERT INTO `BudgetRequest` VALUES ('10','1','2021-12-20','อบรม','ทำเอกสารขออนุมัติค่าลงทะเบียนแล้ว','','6'),('ศธ.๐๕๒๓.๔.๘/๑๐๕','1','2021-12-25','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับวิทยาลัย','ทำเอกสารขออนุมัติค่าลงทะเบียนแล้ว','','1'),('ศธ.๐๕๒๓.๔.๘/๑๑๑','1','2021-12-16','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ ECIT-CON ๒๐๑๙ พร้อมเสนอผลงานทางวิชาการ','ทำเอกสารรายงานการเดินทางแล้ว','ศธ.๐๕๒๓.๔.๘_๑๑๑.pdf','1'),('ศธ.๐๕๒๓.๔.๘/๑๑๒','1','2021-12-16','ขออนุญาติเข้าร่วมงานอบรมวิชาการระดับมหาวิทยาลัย SCI-MJU 2020 พร้อมเสนอผลงานทางวิชาการ','ทำเอกสารขออนุมัติการเดินทางแล้ว','','5'),('ศธ.๐๕๒๓.๔.๘/๑๑๓','1','2021-12-16','ขออนุญาติเข้าร่วมงานอบรมสัมมนา MATH-MJU 2020','ทำเอกสารขออนุมัติการเดินทางแล้ว','','2'),('ศธ.๐๕๒๓.๔.๘/๕๕๕','1','2021-12-24','555','ทำเอกสารรายงานการเดินทางแล้ว','','4'),('อว.๖๙.๕.๓/๓๓๓','2','2021-12-28','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ ECIT-CON ๒๐๑๙ พร้อมเสนอผลงานทางวิชาการ','ทำเอกสารขออนุญาตแล้ว','','4');
/*!40000 ALTER TABLE `BudgetRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BudgetYear`
--

DROP TABLE IF EXISTS `BudgetYear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BudgetYear` (
  `personnelType` varchar(50) NOT NULL,
  `year` varchar(4) NOT NULL,
  `budgetBath` double NOT NULL,
  PRIMARY KEY (`personnelType`,`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BudgetYear`
--

LOCK TABLES `BudgetYear` WRITE;
/*!40000 ALTER TABLE `BudgetYear` DISABLE KEYS */;
INSERT INTO `BudgetYear` VALUES ('สายวิชาการ','2564',3000),('สายสนับสนุน','2564',3000);
/*!40000 ALTER TABLE `BudgetYear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CommentRegistrationBudget`
--

DROP TABLE IF EXISTS `CommentRegistrationBudget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CommentRegistrationBudget` (
  `commentId` varchar(20) NOT NULL,
  `commentRegisDate` date NOT NULL,
  `commentRegisText` varchar(100) NOT NULL,
  `Personnel_personnelID` varchar(10) NOT NULL,
  `RegistrationBudgetRequest_registrationID` varchar(20) NOT NULL,
  PRIMARY KEY (`commentId`),
  KEY `FK9096289nqfle5i7qk58p73kah` (`Personnel_personnelID`),
  KEY `FKinrnth9u1o3g3pt80o9cv08lh` (`RegistrationBudgetRequest_registrationID`),
  CONSTRAINT `FK9096289nqfle5i7qk58p73kah` FOREIGN KEY (`Personnel_personnelID`) REFERENCES `Personnel` (`personnelID`),
  CONSTRAINT `FKinrnth9u1o3g3pt80o9cv08lh` FOREIGN KEY (`RegistrationBudgetRequest_registrationID`) REFERENCES `RegistrationBudgetRequest` (`registrationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CommentRegistrationBudget`
--

LOCK TABLES `CommentRegistrationBudget` WRITE;
/*!40000 ALTER TABLE `CommentRegistrationBudget` DISABLE KEYS */;
INSERT INTO `CommentRegistrationBudget` VALUES ('0_ศธ.๐๕๒๓.๔.๘/๕,๖๗๙','2020-12-28','เทสค่าลงทะเบียน01','3','ศธ.๐๕๒๓.๔.๘/๕,๖๗๙'),('1_ศธ.๐๕๒๓.๔.๘/๕,๖๗๙','2020-12-29','เทสค่าลงทะเบียน02','3','ศธ.๐๕๒๓.๔.๘/๕,๖๗๙'),('2_ศธ.๐๕๒๓.๔.๘/๕,๖๗๙','2020-12-30','เทสค่าลงทะเบียน03','3','ศธ.๐๕๒๓.๔.๘/๕,๖๗๙'),('3_ศธ.๐๕๒๓.๔.๘/๕,๖๗๙','2020-12-28','เทสค่าลงทะเบียน04','3','ศธ.๐๕๒๓.๔.๘/๕,๖๗๙');
/*!40000 ALTER TABLE `CommentRegistrationBudget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CommentTravel`
--

DROP TABLE IF EXISTS `CommentTravel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CommentTravel` (
  `commentId` varchar(20) NOT NULL,
  `commentTravelDate` date NOT NULL,
  `commentTravelText` varchar(100) NOT NULL,
  `Personnel_personnelID` varchar(10) NOT NULL,
  `TravelRequest_travelID` varchar(20) NOT NULL,
  PRIMARY KEY (`commentId`),
  KEY `FKs4bsobg0s6lo81w1o0mvjuf1k` (`Personnel_personnelID`),
  KEY `FK9hsipmnfy5duk4hddeonwcfpl` (`TravelRequest_travelID`),
  CONSTRAINT `FK9hsipmnfy5duk4hddeonwcfpl` FOREIGN KEY (`TravelRequest_travelID`) REFERENCES `TravelRequest` (`travelID`),
  CONSTRAINT `FKs4bsobg0s6lo81w1o0mvjuf1k` FOREIGN KEY (`Personnel_personnelID`) REFERENCES `Personnel` (`personnelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CommentTravel`
--

LOCK TABLES `CommentTravel` WRITE;
/*!40000 ALTER TABLE `CommentTravel` DISABLE KEYS */;
INSERT INTO `CommentTravel` VALUES ('0_อว.๖๙.๔.๘/๓,๔๕๖','2020-12-28','เทส01','3','อว.๖๙.๔.๘/๓,๔๕๖'),('1','2020-12-16','fffff','3','อว.๖๙.๔.๘/๐๑๑'),('1_อว.๖๙.๔.๘/๓,๔๕๖','2020-12-29','เทส02','3','อว.๖๙.๔.๘/๓,๔๕๖'),('2','2020-12-26','แก้ไขเอกสารวันที่กลับให้ถูกต้อง','3','อว.๖๙.๔.๘/๐๑๐'),('2_อว.๖๙.๔.๘/๓,๔๕๖','2020-12-30','เทส03','3','อว.๖๙.๔.๘/๓,๔๕๖'),('3_อว.๖๙.๔.๘/๓,๔๕๖','2020-12-31','เทส04','3','อว.๖๙.๔.๘/๓,๔๕๖'),('อว.๖๙.๔.๘/๐๑๑','2020-12-16','แก้ไขเอกสาร','3','อว.๖๙.๔.๘/๐๑๑');
/*!40000 ALTER TABLE `CommentTravel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Department`
--

DROP TABLE IF EXISTS `Department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Department` (
  `departmentID` int NOT NULL,
  `departmentName` varchar(100) NOT NULL,
  `tel` varchar(4) NOT NULL,
  PRIMARY KEY (`departmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Department`
--

LOCK TABLES `Department` WRITE;
/*!40000 ALTER TABLE `Department` DISABLE KEYS */;
INSERT INTO `Department` VALUES (1,'สาขาเทคโนโลยีสารสนเทศ','3900'),(2,'สาขาวิทยาการคอมพิวเตอร์','3890'),(3,'สาขาเทคโนโลยีชีวภาพ','3870'),(4,'สาขาเคมี','3850'),(5,'สาขาพันธุศาสตร์','3905'),(6,'สาขาคณิตศาสตร์','3880'),(7,'สาขาวัสดุศาสตร์','3830'),(8,'สาขาเคมีอุตสาหกรรมและเทคโนโลยีสิ่งทอ','3910');
/*!40000 ALTER TABLE `Department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Personnel`
--

DROP TABLE IF EXISTS `Personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Personnel` (
  `personnelID` varchar(10) NOT NULL,
  `budget` double NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `personnelType` int NOT NULL,
  `personnelTypeName` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `salary` double NOT NULL,
  `title` varchar(45) NOT NULL,
  `Department_departmentID` int NOT NULL,
  PRIMARY KEY (`personnelID`),
  KEY `FK4v30gsgcymymqrs9f3e3jkqja` (`Department_departmentID`),
  CONSTRAINT `FK4v30gsgcymymqrs9f3e3jkqja` FOREIGN KEY (`Department_departmentID`) REFERENCES `Department` (`departmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Personnel`
--

LOCK TABLES `Personnel` WRITE;
/*!40000 ALTER TABLE `Personnel` DISABLE KEYS */;
INSERT INTO `Personnel` VALUES ('1',3000,'สมชาย','รักดี',1,'สายวิชาการ','บุคลากร',25000,'นาย',1),('2',3000,'ประภาพร','รุ่งเรือง',1,'สายสนับสนุน','บุคลากร',2,'นาง',2),('3',3000,'กานต์มณี','บุญเกิดผล',3,'สายวิชาการ','เจ้าหน้าที่การเงิน',3,'นาง',7),('4',1100,'วรพล','ไพศาลธนาโชต',4,'สายวิชาการ','เจ้าหน้าที่บริหารงานบุคคล',4,'อ.ดร.',5),('5',3000,'รุจิรา','สุขสมบัติ',1,'สายวิชาการ','บุคลากร',5,'นางสาว',8),('6',3000,'เทส','เทส',1,'สายสนับสนุน','บุคลากร',6,'นาย',5),('7',3000,'นพรัตน์','จันทร์ศรี',1,'สายวิชาการ','บุคลากร',25000,'นาย',4);
/*!40000 ALTER TABLE `Personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationBudgetRequest`
--

DROP TABLE IF EXISTS `RegistrationBudgetRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationBudgetRequest` (
  `registrationID` varchar(20) NOT NULL,
  `beforeDate` date NOT NULL,
  `budgetText` varchar(45) NOT NULL,
  `cost` double NOT NULL,
  `location` varchar(50) NOT NULL,
  `regisDate` date NOT NULL,
  `regisEndDate` date NOT NULL,
  `regisStartDate` date NOT NULL,
  `requestBudget` double NOT NULL,
  `textTo` varchar(45) NOT NULL,
  `titleName` varchar(100) NOT NULL,
  `fileName` varchar(50) NOT NULL,
  `BudgetRequest_budgetRequestID` varchar(20) NOT NULL,
  PRIMARY KEY (`registrationID`),
  KEY `FK6gq3qmfiy1cqxvpeunf3gbct8` (`BudgetRequest_budgetRequestID`),
  CONSTRAINT `FK6gq3qmfiy1cqxvpeunf3gbct8` FOREIGN KEY (`BudgetRequest_budgetRequestID`) REFERENCES `BudgetRequest` (`budgetRequestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationBudgetRequest`
--

LOCK TABLES `RegistrationBudgetRequest` WRITE;
/*!40000 ALTER TABLE `RegistrationBudgetRequest` DISABLE KEYS */;
INSERT INTO `RegistrationBudgetRequest` VALUES ('104','2021-12-20','เก้าร้อยบาทถ้วน',1700,'โรงเรียนเชียงใหม่','2021-12-20','2021-12-22','2021-12-21',900,'11','2','','10'),('ศธ.0523.4.8/112','2021-12-16','หนึ่งพันเจ็ดร้อยบาทถ้วน',1700,'โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี','2021-12-16','2021-12-19','2021-12-16',1700,'ศธ.๐๕๒๓.๔.๘/๑๑๑','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ ECIT-CON ๒๐๑๙ พร้อมเสนอผลงานทางวิชาการ','','ศธ.๐๕๒๓.๔.๘/๑๑๑'),('ศธ.๐๕๒๓.๔.๘/๕,๖๗๙','2021-12-25','สี่ร้อยบาทถ้วน',500,'โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี','2021-12-27','2021-01-04','2021-12-31',400,'ศธ.๐๕๒๓.๔.๘/๑๐๖','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับวิทยาลัย','','ศธ.๐๕๒๓.๔.๘/๑๐๕'),('ศธ.๐๕๒๓.๔.๘/๕๕๘','2021-12-24','หกร้อยบาทถ้วน',1000,'โรงแรมดี','2021-12-24','2021-12-31','2021-12-29',600,'ศธ.๐๕๒๓.๔.๘/๕๕๖','556','','ศธ.๐๕๒๓.๔.๘/๕๕๕');
/*!40000 ALTER TABLE `RegistrationBudgetRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RequestingPermission`
--

DROP TABLE IF EXISTS `RequestingPermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RequestingPermission` (
  `requestPerID` varchar(20) NOT NULL,
  `requestPerName` varchar(100) NOT NULL,
  `requestingPerDate` date NOT NULL,
  `requestingPerText` longtext NOT NULL,
  `fileName` varchar(50) NOT NULL,
  `BudgetRequest_budgetRequestID` varchar(20) NOT NULL,
  PRIMARY KEY (`requestPerID`),
  KEY `FKplslj5cl98k93kayrcpd44g8v` (`BudgetRequest_budgetRequestID`),
  CONSTRAINT `FKplslj5cl98k93kayrcpd44g8v` FOREIGN KEY (`BudgetRequest_budgetRequestID`) REFERENCES `BudgetRequest` (`budgetRequestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RequestingPermission`
--

LOCK TABLES `RequestingPermission` WRITE;
/*!40000 ALTER TABLE `RequestingPermission` DISABLE KEYS */;
INSERT INTO `RequestingPermission` VALUES ('11','2','2021-12-20','<p class=\"p1\" style=\"line-height: 2; text-align: justify;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</p>\r\n<p class=\"p1\" style=\"line-height: 2; text-align: justify;\">&nbsp;</p>\r\n<p class=\"p2\" style=\"line-height: 2; text-align: justify;\"><span class=\"Apple-converted-space\">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"s2\">ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></p>','','10'),('ศธ.๐๕๒๓.๔.๘/๑๐๖','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับวิทยาลัย','2021-12-25','<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</span></p>\r\n<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 16pt;\"><span class=\"s2\">&nbsp; &nbsp;ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></span></p>','','ศธ.๐๕๒๓.๔.๘/๑๐๕'),('ศธ.๐๕๒๓.๔.๘/๑๑๑','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ ECIT-CON ๒๐๑๙ พร้อมเสนอผลงานทางวิชาการ','2021-12-16','<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</span></p>\n<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 16pt;\"><span class=\"s2\">&nbsp; &nbsp;ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></span></p>','','ศธ.๐๕๒๓.๔.๘/๑๑๑'),('ศธ.๐๕๒๓.๔.๘/๑๑๒','ขออนุญาติเข้าร่วมงานอบรมวิชาการระดับมหาวิทยาลัย SCI-MJU 2020 พร้อมเสนอผลงานทางวิชาการ','2021-12-16','<p class=\"p1\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</p>\r\n<p class=\"p1\">&nbsp;</p>\r\n<p class=\"p2\"><span class=\"Apple-converted-space\">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"s2\">ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></p>','','ศธ.๐๕๒๓.๔.๘/๑๑๒'),('ศธ.๐๕๒๓.๔.๘/๑๑๓','ขออนุญาติเข้าร่วมงานอบรมสัมมนา MATH-MJU 2020','2021-12-16','<p class=\"p1\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</p>\r\n<p class=\"p1\">&nbsp;</p>\r\n<p class=\"p2\"><span class=\"Apple-converted-space\">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"s2\">ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></p>','','ศธ.๐๕๒๓.๔.๘/๑๑๓'),('ศธ.๐๕๒๓.๔.๘/๕๕๖','556','2021-12-24','<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 14pt;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</span></p>\r\n<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\">&nbsp;</p>\r\n<p class=\"p2\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 14pt;\"><span class=\"Apple-converted-space\">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"s2\">ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></span></p>','','ศธ.๐๕๒๓.๔.๘/๕๕๕'),('อว.๖๙.๕.๓/๓๓๓','333','2021-12-28','<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 14pt;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;ตามที่สมาคมวิศวกรรมไฟฟ้า อิเล็กทรอนิกส์ คอมพิวเตอร์ โทรคมนาคมและเทคโนโลยีสารสนเทศ<span class=\"s1\"> (ECTI) </span>ประเทศไทย ได้กำหนดจัดการประชุมวิชาการนานาชาติ<span class=\"s1\"> \"The </span>๑๖<span class=\"s1\">\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON </span>๒๐๑๙<span class=\"s1\">\" </span>ในระหว่างวันที่ ๑๐<span class=\"s1\">-</span>๑๓ กรกฎาคม ๒๕๖๒ ณ โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี</span></p>\r\n<p class=\"p1\" style=\"line-height: 1.5; text-align: justify;\">&nbsp;</p>\r\n<p class=\"p2\" style=\"line-height: 1.5; text-align: justify;\"><span style=\"font-size: 14pt;\"><span class=\"Apple-converted-space\">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"s2\">ในการนี้</span> <span class=\"s2\">ข้าพเจ้านางสาวพิชชยานิดา</span> <span class=\"s2\">คำวิชัย</span> <span class=\"s2\">พนังงานมหาวิทยาลัย</span> <span class=\"s2\">ตำแหน่ง</span> <span class=\"s2\">อาจารย์</span> <span class=\"s2\">จึงขออนุญาตเข้าร่วมงานประชุมวิชาการระดับนานาชาติ</span> The <span class=\"s2\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON <span class=\"s2\">๒๐๑๙</span>\" <span class=\"s2\">พร้อมเสนอผลงานทางวิชาการในรูปแบบบรรยาย</span> <span class=\"s2\">หัวข้อเรื่อง</span> \"Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict , Chiang Mai , Thailand\" <span class=\"s2\">ระหว่างวันที่</span> <span class=\"s2\">๑๐</span>-<span class=\"s2\">๑๓</span> <span class=\"s2\">กรกฎาคม</span> <span class=\"s2\">๒๕๖๒</span> <span class=\"s2\">ณ</span> <span class=\"s2\">โรงแรมดี</span> <span class=\"s2\">วารี</span> <span class=\"s2\">จอมเทียน</span> <span class=\"s2\">บีช</span> <span class=\"s2\">พัทยา</span> <span class=\"s2\">จังหวัดชลบุรี</span></span></p>','','อว.๖๙.๕.๓/๓๓๓');
/*!40000 ALTER TABLE `RequestingPermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TravelReport`
--

DROP TABLE IF EXISTS `TravelReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TravelReport` (
  `travelReportID` varchar(20) NOT NULL,
  `travelReportDate` date NOT NULL,
  `travelReportText` longtext NOT NULL,
  `fileName` varchar(50) NOT NULL,
  `BudgetRequest_budgetRequestID` varchar(20) NOT NULL,
  PRIMARY KEY (`travelReportID`),
  KEY `FKpgas5t99tatj8ix9kjl2bbgcq` (`BudgetRequest_budgetRequestID`),
  CONSTRAINT `FKpgas5t99tatj8ix9kjl2bbgcq` FOREIGN KEY (`BudgetRequest_budgetRequestID`) REFERENCES `BudgetRequest` (`budgetRequestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TravelReport`
--

LOCK TABLES `TravelReport` WRITE;
/*!40000 ALTER TABLE `TravelReport` DISABLE KEYS */;
INSERT INTO `TravelReport` VALUES ('10','2021-12-16','<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; ตามใบขอออนุมัติเดินทางไปปฏิบัติงาน ที่ อว.69.4.8/010 ลงวันที่ 20 มิถุนายน 2562 อนุมัติให้ข้าพเจ้าพร้อมด้วยเจ้าหน้าที่จำนวน.....-.....คน เดินทางไปปฏิบัติงานเกี่ยวกับ เดินทางไปปฏิบัติงานเกี่ยวกับ การเข้าร่วม<span class=\"s1\">ประชุมวิชาการนานาชาติ </span>\"The <span class=\"s1\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON 2019 (IEEE Conference Record) (ECTI-CON 2019) พร้อมนำเสนอผลงาน ระหว่างวันที่ 10 - 13&nbsp; กรกฎาคม 2562&nbsp; ณ&nbsp; โรงแรมวารี จอมเทียน บีช พัทยา จังหวัดชลบุรี&nbsp; นั้น</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; &nbsp; บัดนี้ข้าพเจ้าพร้อมด้วยเจ้าหน้าที่จำนวน.....-..... คน ได้เดินทางไปปฏิบัติงาน ดังกล่าวข้างต้นแล้ว จึงใครขอเสนอผลการปฏิบัติงานดังต่อไปนี้</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1. ได้เข้าร่วมประชุมวิชาการระดับนานาชาติ ECTI-CON 2019 ระหว่างวันที่ 10 -13 กรกฎาคม 2562 ทำให้ได้รับทราบเกี่ยวกับความก้าวหน้าของงานวิจัยที่เกี่ยวข้อง และการนำมาทำวิจัยต่อไป</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; 2. ได้เข้านำเสนอผลงานภาคบรรยาย เรื่อง Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict, Chiang Mai, Thailand (First author) และ อ้างอิงผลงานใน ECTI-CON 2019 Proceedings , 10 - 13 July 2019 , Pattaya Thailand , Page 54 - 57 เป็นที่เรียบร้อยแล้ว</span></p>','','ศธ.๐๕๒๓.๔.๘/๑๑๑'),('อว.๖๙.๕.๘/๕๕๙','2021-12-24','<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; ตามใบขอออนุมัติเดินทางไปปฏิบัติงาน ที่ อว.69.4.8/010 ลงวันที่ 20 มิถุนายน 2562 อนุมัติให้ข้าพเจ้าพร้อมด้วยเจ้าหน้าที่จำนวน.....-.....คน เดินทางไปปฏิบัติงานเกี่ยวกับ เดินทางไปปฏิบัติงานเกี่ยวกับ การเข้าร่วม<span class=\"s1\">ประชุมวิชาการนานาชาติ </span>\"The <span class=\"s1\">๑๖</span>\" international Conference on Electrical Engineering/Electronics, Computer , Telecommunications and information Technology\" ECTI-CON 2019 (IEEE Conference Record) (ECTI-CON 2019) พร้อมนำเสนอผลงาน ระหว่างวันที่ 10 - 13&nbsp; กรกฎาคม 2562&nbsp; ณ&nbsp; โรงแรมวารี จอมเทียน บีช พัทยา จังหวัดชลบุรี&nbsp; นั้น</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; &nbsp; บัดนี้ข้าพเจ้าพร้อมด้วยเจ้าหน้าที่จำนวน.....-..... คน ได้เดินทางไปปฏิบัติงาน ดังกล่าวข้างต้นแล้ว จึงใครขอเสนอผลการปฏิบัติงานดังต่อไปนี้</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1. ได้เข้าร่วมประชุมวิชาการระดับนานาชาติ ECTI-CON 2019 ระหว่างวันที่ 10 -13 กรกฎาคม 2562 ทำให้ได้รับทราบเกี่ยวกับความก้าวหน้าของงานวิจัยที่เกี่ยวข้อง และการนำมาทำวิจัยต่อไป</span></p>\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 16pt;\">&nbsp; &nbsp; &nbsp; 2. ได้เข้านำเสนอผลงานภาคบรรยาย เรื่อง Implementing Information Technology and Social Media for Promoting Tourism Pongyeang Subdistrict, Chiang Mai, Thailand (First author) และ อ้างอิงผลงานใน ECTI-CON 2019 Proceedings , 10 - 13 July 2019 , Pattaya Thailand , Page 54 - 57 เป็นที่เรียบร้อยแล้ว</span></p>','','ศธ.๐๕๒๓.๔.๘/๕๕๕');
/*!40000 ALTER TABLE `TravelReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TravelRequest`
--

DROP TABLE IF EXISTS `TravelRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TravelRequest` (
  `travelID` varchar(20) NOT NULL,
  `allowance` double NOT NULL,
  `endDate` date NOT NULL,
  `grade` varchar(45) NOT NULL,
  `level` varchar(45) NOT NULL,
  `location` varchar(100) NOT NULL,
  `otherBudget` double NOT NULL,
  `payType` varchar(45) NOT NULL,
  `rentalRoom` double NOT NULL,
  `startDate` date NOT NULL,
  `titleName` varchar(100) NOT NULL,
  `totalBudget` double NOT NULL,
  `totalDate` varchar(45) NOT NULL,
  `travelDate` date NOT NULL,
  `travelVehicle` varchar(45) NOT NULL,
  `vehicleBudget` double NOT NULL,
  `withName` varchar(45) NOT NULL,
  `realBudget` double NOT NULL,
  `fileName` varchar(50) NOT NULL,
  `BudgetRequest_budgetRequestID` varchar(20) NOT NULL,
  PRIMARY KEY (`travelID`),
  KEY `FK3kcj880u13ai64qr83fe8m641` (`BudgetRequest_budgetRequestID`),
  CONSTRAINT `FK3kcj880u13ai64qr83fe8m641` FOREIGN KEY (`BudgetRequest_budgetRequestID`) REFERENCES `BudgetRequest` (`budgetRequestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TravelRequest`
--

LOCK TABLES `TravelRequest` WRITE;
/*!40000 ALTER TABLE `TravelRequest` DISABLE KEYS */;
INSERT INTO `TravelRequest` VALUES ('303',1000,'2021-12-22','-','-','โรงเรียนเชียงใหม่',100,'จะจ่ายเงินส่วนตัวทดรองไปก่อน',100,'2021-12-21','เดินทาง',1300,'1','2021-12-20','เครื่องบินโดยสาร',100,'เพื่อนชาย',0,'','10'),('อว.๖๙.๔.๘/๐๑๐',100,'2021-12-19','-','-','โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี',100,'จะจ่ายเงินส่วนตัวทดรองไปก่อน',900,'2021-12-16','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ',1300,'3','2021-12-16','รถยนต์ส่วนตัว',200,'ภาสกร บวรกิจ',1300,'','ศธ.๐๕๒๓.๔.๘/๑๑๑'),('อว.๖๙.๔.๘/๐๑๑',400,'2021-12-18','-','-','โรงแรมดวงตะวัน',300,'จะจ่ายเงินส่วนตัวทดรองไปก่อน',500,'2021-12-16','ขออนุญาติเข้าร่วมงานอบรมวิชาการระดับมหาวิทยาลัย',1400,'2','2021-12-16','รถยนต์ส่วนตัว',200,'-',0,'','ศธ.๐๕๒๓.๔.๘/๑๑๒'),('อว.๖๙.๔.๘/๐๑๒',300,'2021-12-18','-','-','โรงแรมดวงตะวัน',300,'จะจ่ายเงินส่วนตัวทดรองไปก่อน',400,'2021-12-16','ขออนุญาติเข้าร่วมงานอบรมวิชาการระดับมหาวิทยาลัย',1200,'2','2021-12-16','รถยนต์ส่วนตัว',200,'-',0,'','ศธ.๐๕๒๓.๔.๘/๑๑๓'),('อว.๖๙.๔.๘/๓,๔๕๖',400,'2022-01-04','-','-','โรงแรมดี วารี จอมเทียน บีช พัทยา จังหวัดชลบุรี',600,'จะขอยืมเงินทดรองจ่ายไปก่อน',400,'2021-12-31','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ',1600,'4','2021-12-27','รถโดยสาร',200,'ภาสกร บวรกิจ',0,'','ศธ.๐๕๒๓.๔.๘/๑๐๕'),('อว.๖๙.๔.๘/๕๕๗',1000,'2021-12-31','-','-','โรงแรมดี',100,'จะจ่ายเงินส่วนตัวทดรองไปก่อน',100,'2021-12-29','ขออนุญาติเข้าร่วมงานประชุมวิชาการระดับนานาชาติ',1300,'2','2021-12-24','รถโดยสาร',100,'ภาสกร',1300,'','ศธ.๐๕๒๓.๔.๘/๕๕๕');
/*!40000 ALTER TABLE `TravelRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_remainingbudget`
--

DROP TABLE IF EXISTS `view_remainingbudget`;
/*!50001 DROP VIEW IF EXISTS `view_remainingbudget`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_remainingbudget` AS SELECT 
 1 AS `budgetRequestID`,
 1 AS `chooseRequest`,
 1 AS `requestDate`,
 1 AS `requestName`,
 1 AS `Personnel_personnelID`,
 1 AS `personnelID`,
 1 AS `budget`,
 1 AS `firstname`,
 1 AS `lastname`,
 1 AS `personnelType`,
 1 AS `position`,
 1 AS `salary`,
 1 AS `title`,
 1 AS `Department_departmentID`,
 1 AS `departmentID`,
 1 AS `departmentName`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'sciencefacultybudget'
--
/*!50003 DROP PROCEDURE IF EXISTS `addBudgetRequest_Procudure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addBudgetRequest_Procudure`(In bId varchar(20) ,In bname varchar(255) , In bdate date , In bchoose varchar(20) , In s varchar(100), In pdf varchar(50) , In pId varchar(10))
BEGIN
	insert into budgetrequest 
    values(bId , bChoose , bDate , bName , s , pdf , pId);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addCommentReg_Procudure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addCommentReg_Procudure`(In cid varchar(20) , In cd Date, In ct varchar(50), In pid varchar(10),In rid varchar(20))
BEGIN
	insert into CommentRegistrationBudget
    values(cid , cd , ct , pid , rid);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addCommentTravel_Procudure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addCommentTravel_Procudure`(In cid varchar(20) , In cd Date, In ct varchar(50) , In pid varchar(50) , In tid varchar(20))
BEGIN
    insert into CommentTravel
    values(cid , cd , ct , pid , tid);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addRegistrationBudget_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addRegistrationBudget_Procedure`(In regId varchar(50) , In beforeDate date , In budgetText varchar(100) 
, In cost double  , In location varchar(100) , In regDate date , In eDate date  , In sDate date  , In requestBudget double , In Textto varchar(50) , In titleName varchar(255) , In pdf varchar(50) , In budgetId varchar(50))
BEGIN 
	insert into registrationbudgetrequest 
    values(regId , beforeDate , budgetText  , cost , location , regDate ,  eDate, sDate , requestBudget , Textto , titleName , pdf , budgetId);
	update BudgetRequest set status = 'ทำเอกสารขออนุมัติค่าลงทะเบียนแล้ว' where budgetRequestID = budgetId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addRequestingPermisison_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addRequestingPermisison_Procedure`(In perId varchar(50) , In perName varchar(255) , In perDate date , In perText longtext , In pdf varchar(50) , In budgetID varchar(50))
BEGIN
	insert into requestingpermission 
    values(perId , perName , perDate , perText , pdf , budgetID);
	update BudgetRequest set status = 'ทำเอกสารขออนุญาตแล้ว' where budgetRequestID = budgetID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addTravelReport_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addTravelReport_Procedure`(In rID varchar(50) ,In rDate date , In rText longtext , In budgetId varchar(50) , In pdf varchar(50) , In r Double)
BEGIN
	insert into travelreport 
    values(rID , rDate , rText , pdf , budgetId);
	update BudgetRequest set status = 'ทำเอกสารรายงานการเดินทางแล้ว' where budgetRequestID = budgetId;
    update TravelRequest set realBudget = r where BudgetRequest_budgetRequestID = budgetId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addTravelRequest_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addTravelRequest_Procedure`(In tId varchar(50) , In allowance double , In eDate date , In tGrade varchar(10)
, In tLevel varchar(10) , In tLocation varchar(100)  , In otherBudget double  , In payType varchar(30) , In rentalRoom double  , In sDate date  
, In titleName varchar(255) , In totalBudget double , In tTotalDate varchar(10), In tDate date  , In travelVehicle varchar(100)  
, In vehicleBudget double , In tWith varchar(50) ,  In realBudget double , In pdf varchar(50) , In budgetId varchar(50))
BEGIN
	insert into travelrequest   
    values(tId , allowance , eDate , tGrade , tLevel , tLocation , otherBudget , payType , rentalRoom , sDate , titleName , totalBudget , tTotalDate , tDate , travelVehicle , vehicleBudget , tWith , realBudget , pdf , budgetId);
	update BudgetRequest set status = 'ทำเอกสารขออนุมัติการเดินทางแล้ว' where budgetRequestID = budgetId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cancelBudgetRequest_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cancelBudgetRequest_Procedure`(In st varchar(50) ,In bid varchar(50))
BEGIN
	update budgetrequest
    set status = st
    where budgetRequestID = bId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateBudgetRequest_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateBudgetRequest_Procedure`(In bId varchar(50) ,In bname varchar(255) , In bdate date , In bchoose varchar(20) , In pId varchar(10))
BEGIN
	update budgetrequest
    set chooseRequest = bchoose , requestDate = bdate , requestName = bname , Personnel_personnelID = pId
    where budgetRequestID = bId;
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCommentRegis_Procudure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCommentRegis_Procudure`(In cid varchar(20)  , In cd Date , In ct varchar(50) , In pid varchar(10),In tid varchar(20))
BEGIN
	update CommentRegistrationBudget
    set commentRegisDate = cd , commentRegisText = ct , Personnel_personnelID = pid
    where commentid = cid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCommentTravel_Procudure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCommentTravel_Procudure`(In cid varchar(20)  , In cd Date , In ct varchar(50) , In pid varchar(10),In tid varchar(20))
BEGIN
	update CommentTravel
    set commentTravelDate = cd , commentTravelText = ct , Personnel_personnelID = pid
    where commentid = cid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateRegistrationBudget_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateRegistrationBudget_Procedure`(In regId varchar(50) , In beforeDate date , In budgetText varchar(100) 
, In cost double  , In location varchar(100) , In regDate date , In eDate date  , In sDate date  , In requestBudget double 
, In Textto varchar(50) , In titleName varchar(255)  , In budgetId varchar(50))
BEGIN
	update registrationbudgetrequest
    set beforeDate = beforeDate , budgetText = budgetText  , cost=cost , location=location , regisDate=regDate ,  regisEndDate=eDate, regisStartDate=sDate , requestBudget=requestBudget , textTo=Textto , titleName=titleName , BudgetRequest_budgetRequestID=budgetId
    where registrationID = regId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateRequestingPermission_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateRequestingPermission_Procedure`(In perId varchar(50) , In perName varchar(255) , In perDate date , In perText longtext , In budgetID varchar(50))
BEGIN
	update RequestingPermission
    set requestPerName = perName, requestingPerDate = perDate , requestingPerText = perText
    where requestPerID = perId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateTravelReport_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateTravelReport_Procedure`(In rID varchar(50) , rDate date , In rText longtext , In budgetId varchar(50))
BEGIN
	update travelreport
    set travelReportDate = rDate , travelReportText=rText , BudgetRequest_budgetRequestID=budgetId
    where travelReportID = rID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateTravelRequest_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateTravelRequest_Procedure`(In tId varchar(50) , In allowance double , In eDate date , In tGrade varchar(10)
, In tLevel varchar(10) , In tLocation varchar(100)  , In otherBudget double  , In payType varchar(30) , In rentalRoom double  , In sDate date  
, In titleName varchar(255) , In totalBudget double , In tTotalDate varchar(10), In tDate date  , In travelVehicle varchar(100)  
, In vehicleBudget double , In tWith varchar(50) ,In budgetId varchar(50))
BEGIN
	update travelrequest
    set allowance = allowance , endDate = eDate , grade = tGrade , level = tLevel , location = tLocation , otherBudget = otherBudget , payType = payType , rentalRoom = rentalRoom , startDate = sDate 
    , titleName = titleName , totalBudget = totalBudget , totalDate = tTotalDate , travelDate = tDate , travelVehicle = travelVehicle , vehicleBudget = vehicleBudget , withName = tWith , BudgetRequest_budgetRequestID = budgetId
    where travelID = tId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_budget` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_budget`(In pid varchar(10) , In bg double)
BEGIN
	update personnel
    set budget = bg
    where personnelID = pid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `uploadfile_Procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `uploadfile_Procedure`(In filename varchar(50) , In brname varchar(50) , In bpname varchar(50) , In tname varchar(50) , In regname varchar(50) , In reportname varchar(50))
BEGIN
	insert into ListFile
    values(filename , brname , bpname , tname , regname , reportname);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_BudgetRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upload_BudgetRequest`(in v_file varchar(255),in v_budgetRequest varchar(255))
BEGIN
	update BudgetRequest
    set fileName = v_file
    where budgetRequestID = v_budgetRequest;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_RegistrationBudget` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upload_RegistrationBudget`(in v_name varchar(255), in reg_id varchar(225))
BEGIN
	update RegistrationBudgetRequest
    set fileName = v_name
    where registrationID = reg_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_reqestingPermission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upload_reqestingPermission`(in v_file varchar(255), in r_id varchar(225))
BEGIN
	update RequestingPermission
    set fileName = v_file
    where requestPerID = r_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_travelReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upload_travelReport`(in v_name varchar(255), in report_id varchar(225))
BEGIN
	update TravelReport
    set fileName = v_name
    where travelReportID = report_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_travelRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upload_travelRequest`(in v_file varchar(255), in t_id varchar(225))
BEGIN
	update TravelRequest
    set fileName = v_file
    where travelID = t_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `view_remainingbudget`
--

/*!50001 DROP VIEW IF EXISTS `view_remainingbudget`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_remainingbudget` AS select `b`.`budgetRequestID` AS `budgetRequestID`,`b`.`chooseRequest` AS `chooseRequest`,`b`.`requestDate` AS `requestDate`,`b`.`requestName` AS `requestName`,`b`.`Personnel_personnelID` AS `Personnel_personnelID`,`p`.`personnelID` AS `personnelID`,`p`.`budget` AS `budget`,`p`.`firstname` AS `firstname`,`p`.`lastname` AS `lastname`,`p`.`personnelType` AS `personnelType`,`p`.`position` AS `position`,`p`.`salary` AS `salary`,`p`.`title` AS `title`,`p`.`Department_departmentID` AS `Department_departmentID`,`d`.`departmentID` AS `departmentID`,`d`.`departmentName` AS `departmentName` from ((`budgetrequest` `b` join `personnel` `p` on((`b`.`Personnel_personnelID` = `p`.`personnelID`))) join `department` `d` on((`p`.`Department_departmentID` = `d`.`departmentID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-31  9:50:19
